const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();

function safeReadRuntimeAssetsJson() {
  try {
    const projectRoot = path.resolve(__dirname, '..', '..');
    const jsonPath = path.join(projectRoot, 'runtime-assets.json');
    if (!fs.existsSync(jsonPath)) return null;
    const raw = fs.readFileSync(jsonPath, 'utf8');
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function resolveLocalAssetPath(assetKey) {
  try {
    const projectRoot = path.resolve(__dirname, '..', '..');
    const runtimeRoot = path.join(projectRoot, 'backend', 'runtime-seed', 'windows-x64');
    if (!fs.existsSync(runtimeRoot)) return null;

    const normalizedKey = String(assetKey || '').trim();
    if (!normalizedKey) return null;

    const direct = path.join(runtimeRoot, normalizedKey);
    if (fs.existsSync(direct)) return direct;

    const lowered = normalizedKey.toLowerCase();
    for (const entry of fs.readdirSync(runtimeRoot, { withFileTypes: true })) {
      if (entry.name.toLowerCase() === lowered) {
        return path.join(runtimeRoot, entry.name);
      }
    }
    return null;
  } catch {
    return null;
  }
}

router.get('/status', (req, res) => {
  try {
    const manifest = safeReadRuntimeAssetsJson();
    if (!manifest) {
      return res.json({
        ok: true,
        source: 'missing',
        version: null,
        assets: {},
      });
    }

    const assetMap = manifest.assets && typeof manifest.assets === 'object' && !Array.isArray(manifest.assets)
      ? manifest.assets
      : null;
    const assetList = Array.isArray(manifest.assets)
      ? manifest.assets
      : assetMap
        ? Object.entries(assetMap).map(([key, value]) => ({ key, ...value }))
        : [];

    const assetEntries = assetList.map((asset) => {
      const assetKey = String(asset?.key || '').trim();
      const localPath = assetKey ? resolveLocalAssetPath(assetKey) : null;
      let localSize = 0;
      if (localPath) {
        try {
          localSize = fs.statSync(localPath).size;
        } catch {
          localSize = 0;
        }
      }
      return {
        key: assetKey || null,
        label: asset?.label || assetKey || null,
        urls: Array.isArray(asset?.urls) ? asset.urls : [],
        expectedBytes: asset?.expectedBytes ?? null,
        minBytes: asset?.minBytes ?? null,
        localPath: localPath || null,
        localSize,
      };
    });

    res.json({
      ok: true,
      source: 'local-manifest',
      version: manifest?.version ?? null,
      updatedAt: manifest?.updatedAt ?? null,
      mirrorRepo: manifest?.mirrorRepo ?? null,
      assets: assetEntries,
    });
  } catch (error) {
    res.status(500).json({ error: error?.message || 'Unable to load runtime assets status.' });
  }
});

module.exports = router;
