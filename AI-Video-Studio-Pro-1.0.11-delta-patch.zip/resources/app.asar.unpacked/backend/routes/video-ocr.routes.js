const express = require('express');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFile } = require('child_process');
const util = require('util');
const execFileAsync = util.promisify(execFile);

const {
  DEFAULT_ROI,
  normalizeOcrLanguage,
  transcribeVideoWithOcr,
} = require('../services/video-ocr.service');
const { createPaddleOcrWorker } = require('../services/paddle-ocr-worker.service');
const { createPaddleOcrRuntime, getPaddlePythonExe, getPaddleEnv,
  isPaddleOcrAvailable } = require('../services/paddle-ocr-runtime.service');
const {
  isVietnameseOcrLanguage, isVietnameseOcrAvailable,
  createVietnameseOcrWorker, prepareVietnameseOcr,
} = require('../services/vietnamese-ocr-worker.service');
const {
  requireOcrSubtitleResult,
} = require('../utils/subtitle-scan-validation');

function buildPaddleWorkerFactory() {
  const pythonPath = getPaddlePythonExe();
  const scriptPath = path.join(__dirname, '..', 'scripts', 'paddle_ocr_bridge.py');
  if (!fs.existsSync(pythonPath) || !fs.existsSync(scriptPath)) return null;

  return async (language) => {
    return createPaddleOcrWorker({ pythonPath, scriptPath,
      language: language === 'eng' ? 'eng-strict' : language, env: getPaddleEnv() });
  };
}

function chooseAdaptiveOcrFps({ width = 0, height = 0, duration = 0 } = {}) {
  const pixels = Math.max(0, Number(width) || 0) * Math.max(0, Number(height) || 0);
  const seconds = Math.max(0, Number(duration) || 0);
  const cpuCount = Math.max(1, os.cpus()?.length || 1);
  const memoryGb = Math.max(1, os.totalmem() / (1024 ** 3));

  // Public-safe defaults: preserve more samples for small/short clips while
  // bounding 4K and low-memory jobs so they keep making progress.
  if (cpuCount <= 4 || memoryGb <= 8) return 1;
  if (pixels >= 6_000_000 && seconds >= 10 * 60) return 1;
  if (pixels >= 6_000_000 || seconds >= 30 * 60) return 1.25;
  if (pixels >= 2_000_000 || seconds >= 10 * 60) return 1.5;
  return 2;
}

/**
 * HTTP surface for local video OCR.
 *
 * backend/services/video-ocr.service.js already implements the whole pipeline
 * (frame extraction, tesseract worker, chunk merging, SRT writing) and reports
 * progress through an onProgress callback, but no route ever called it, so the
 * OCR panel in the UI could not start a scan.
 *
 * The scan is long-running, so the panel starts it in the background and polls
 * video-ocr-status. Job state therefore lives here, in this module, keyed by job
 * id, with exactly one active scan: the UI drives a single preview at a time and
 * a second concurrent tesseract worker would fight over CPU and temp files.
 */

function createVideoOcrRouter(helpers = {}) {
  const {
    buildFileUrl = (filePath) => `/outputs/${path.basename(filePath)}`,
    ffmpegPath = 'ffmpeg',
    outputsDir = path.join(os.tmpdir(), 'video-studio-ocr'),
    multerUpload = null,
    reserveUsage = null,
  } = helpers;

  const router = express.Router();
  const paddleRuntime = createPaddleOcrRuntime({
    ensureVenv: helpers.ensureOcrVenv,
    installPackages: helpers.installOcrPackages,
    ensurePrerequisites: helpers.ensureOcrPrerequisites,
  });
  let vietnameseDownload = { isDownloading: false, downloadError: '', downloadStep: '' };

  // jobId -> { controller, status, result, error, startedAt }
  const jobs = new Map();
  let activeJobId = '';
  let jobCounter = 0;

  const idleStatus = () => ({
    active: false,
    progress: 0,
    currentFrame: 0,
    totalFrames: 0,
    currentChunk: 0,
    chunkCount: 0,
    processedSeconds: 0,
    durationSeconds: 0,
    step: '',
    currentText: '',
  });

  // Drop finished jobs so a long editing session does not accumulate them.
  const pruneJobs = () => {
    const cutoff = Date.now() - 10 * 60 * 1000;
    for (const [id, job] of jobs) {
      if (!job.status.active && (job.finishedAt || 0) < cutoff) jobs.delete(id);
    }
  };

  // The client may only point at a real local file. Remote URLs are rejected on
  // purpose: subtitle scanning is a local operation and must never turn into an
  // outbound fetch of the user's media.
  const resolveLocalVideo = (candidate) => {
    const raw = String(candidate || '').trim();
    if (!raw) return { error: 'A videoPath or videoFile is required.' };
    if (/^(https?:|ftp:|data:)/i.test(raw)) {
      return { error: 'Only local video files can be scanned.' };
    }
    let resolved;
    try {
      resolved = path.resolve(raw);
    } catch {
      return { error: 'The video path is not valid.' };
    }
    let stat;
    try {
      stat = fs.statSync(resolved);
    } catch {
      return { error: `Video file not found: ${resolved}` };
    }
    if (!stat.isFile()) return { error: 'The video path is not a file.' };
    return { path: resolved };
  };

  /**
   * Registers a job and returns a `run` thunk.
   *
   * The caller must not invoke `run` until the HTTP response has actually been
   * flushed. transcribeVideoWithOcr() has a long synchronous prologue (Tesseract
   * worker + language data), and res.json() only queues the socket write: a
   * setImmediate or a plain call blocks the event loop long enough that the
   * client waits ~37s for an "accepted" reply and never shows a progress bar.
   * Handing the work to the caller lets it pass res.json's completion callback.
   */
  const runScan = (options, lifecycle = {}) => {
    // Check before reserving a slot, and recheck concurrency after probing.
    // Missing models must not leave a phantom active job.
    if (activeJobId) throw new Error('A video OCR scan is already running.');
    const useVietnamese = isVietnameseOcrLanguage(options.language);
    const wantsPaddle = !useVietnamese && (options.ocrEngine === 'paddle' || !options.ocrEngine);
    if (useVietnamese && !isVietnameseOcrAvailable()) {
      throw new Error('Vietnamese OCR model is not ready. Select VI and initialize the OCR model in Settings.');
    }
    if (wantsPaddle && !isPaddleOcrAvailable()) {
      throw new Error('Neural Vision AI model is not ready. Please initialize the OCR model before scanning.');
    }
    const usePaddle = wantsPaddle;
    const workerFactory = useVietnamese
      ? () => createVietnameseOcrWorker()
      : usePaddle ? buildPaddleWorkerFactory() : null;
    const jobId = `ocr-${Date.now().toString(36)}-${++jobCounter}`;
    const controller = new AbortController();
    const job = {
      controller,
      status: { ...idleStatus(), active: true, step: 'starting', progress: 1 },
      result: null,
      error: '',
      startedAt: Date.now(),
      finishedAt: 0,
    };
    jobs.set(jobId, job);
    activeJobId = jobId;
    pruneJobs();

    const srtOutputPath = path.join(
      outputsDir,
      `${path.basename(options.videoPath, path.extname(options.videoPath)) || 'scan'}.${jobId}.ocr.srt`,
    );

    // Fire and forget: the caller polls the status route. Errors are recorded on
    // the job so the poll surfaces them instead of an unhandled rejection.
    const run = () => {
      (async () => {
        try {
        if (controller.signal.aborted) throw Object.assign(new Error('Video OCR cancelled.'), { cancelled: true });
        await lifecycle?.beforeStart?.();
        fs.mkdirSync(outputsDir, { recursive: true });
        const result = await transcribeVideoWithOcr({
          videoPath: options.videoPath,
          roi: options.roi,
          language: options.language,
          fps: options.fps,
          videoWidth: options.videoWidth,
          videoHeight: options.videoHeight,
          videoDuration: options.videoDuration,
          srtOutputPath,
          ffmpegPath,
          signal: controller.signal,
          createOcrWorker: options.createOcrWorker || workerFactory,
          requestedOcrEngine: useVietnamese ? 'tesseract-vie-lstm' : usePaddle ? 'paddle' : (options.ocrEngine || 'tesseract'),
          onProgress: (update) => {
            job.status = { ...job.status, ...(update || {}), active: true };
          },
        });
        const validatedSubtitles = requireOcrSubtitleResult(result);
        await lifecycle?.onComplete?.();
        job.result = {
          ...(result || {}),
          srtPath: srtOutputPath,
          srtName: path.basename(srtOutputPath),
          srtUrl: fs.existsSync(srtOutputPath) ? buildFileUrl(srtOutputPath) : null,
          videoPath: options.videoPath,
          videoName: path.basename(options.videoPath),
          subtitles: validatedSubtitles,
          transcriptText: result?.transcriptText || '',
          segmentsCount: validatedSubtitles.length,
          ocrEngine: result?.ocrEngine || (usePaddle ? 'paddle' : (options.ocrEngine || 'tesseract')),
        };
        job.status = { ...job.status, active: false, progress: 100, step: 'completed' };
      } catch (error) {
        job.result = null;
        try { await lifecycle?.onFailure?.(); } catch (usageError) { job.error = usageError.message; }
        // An abort is a user-requested cancel, not a failure. Without this the
        // abort error would overwrite the 'cancelled' step the cancel handler
        // just set, and the UI would report a failed scan for work it stopped.
        if (controller.signal.aborted || error?.cancelled) {
          job.error = '';
          job.status = { ...job.status, active: false, step: 'cancelled' };
        } else {
          job.error = String(error?.message || error || 'Video OCR failed.');
          job.status = { ...job.status, active: false, step: 'error' };
        }
      } finally {
        job.finishedAt = Date.now();
        if (activeJobId === jobId) activeJobId = '';
      }
      })();
    };

    return { jobId, run };
  };

  const readJobStatus = (jobId) => {
    const job = jobs.get(String(jobId || activeJobId || ''));
    if (!job) return null;
    return {
      jobId,
      active: Boolean(job.status.active),
      status: job.status,
      error: job.error,
      result: job.result,
    };
  };

  // The scan crops to the ROI using the frame size, so a missing width/height
  // makes ffmpeg fail with "Error reinitializing filters", which tells the user
  // nothing. Probe the real dimensions instead, once per file.
  const dimensionCache = new Map();
  const probeVideoDimensions = async (videoPath) => {
    if (dimensionCache.has(videoPath)) return dimensionCache.get(videoPath);
    let result = { width: 0, height: 0, duration: 0 };
    try {
      const ffprobePath = (() => {
        const configured = String(ffmpegPath || 'ffmpeg');
        const base = path.basename(configured).toLowerCase();
        if (base === 'ffmpeg.exe') return path.join(path.dirname(configured), 'ffprobe.exe');
        if (base === 'ffmpeg') return path.join(path.dirname(configured), 'ffprobe');
        return process.platform === 'win32' ? 'ffprobe.exe' : 'ffprobe';
      })();
      try {
        const probe = await execFileAsync(
          ffprobePath,
          [
            '-v', 'error',
            '-select_streams', 'v:0',
            '-show_entries', 'stream=width,height:format=duration',
            '-of', 'json',
            videoPath,
          ],
          { encoding: 'utf8', windowsHide: true, timeout: 10000 },
        );
        const metadata = JSON.parse(String(probe.stdout || '{}'));
        const stream = Array.isArray(metadata.streams) ? metadata.streams[0] || {} : {};
        result = {
          width: Number(stream.width) || 0,
          height: Number(stream.height) || 0,
          duration: Number(metadata?.format?.duration) || 0,
        };
        if (result.width && result.height) {
          dimensionCache.set(videoPath, result);
          return result;
        }
      } catch {
        // Older portable FFmpeg bundles may not include ffprobe; retain the
        // stderr metadata fallback below for those installations.
      }
      let info = '';
      try {
        const probe = await execFileAsync(ffmpegPath, ['-i', videoPath], {
          encoding: 'utf8',
          windowsHide: true,
          timeout: 5000,
        });
        info = `${probe.stderr || ''}${probe.stdout || ''}`;
      } catch (err) {
        info = `${err.stderr || ''}${err.stdout || ''}`;
      }
      const size = /\b(\d{2,5})x(\d{2,5})\b/.exec(info);
      if (size) {
        const durationMatch = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec(info);
        result = {
          width: Number(size[1]) || 0,
          height: Number(size[2]) || 0,
          duration: durationMatch
            ? Number(durationMatch[1]) * 3600 +
              Number(durationMatch[2]) * 60 +
              Number(durationMatch[3])
            : 0,
        };
      }
    } catch {
      /* keep the zeroed result; the scan reports its own failure */
    }
    dimensionCache.set(videoPath, result);
    return result;
  };

  /**
   * Send JSON, then run `start` only once the response has reached the client.
   *
   * res.end's callback fires on 'finish' (data handed to the socket), not on a
   * completed write, so starting heavy synchronous work there still blocks the
   * event loop long enough to delay the reply. Poll writableLength until the
   * kernel buffer is empty, with a bounded number of attempts.
   */
  const respondThenStart = (res, payload, start) => {
    res.set('Content-Type', 'application/json');
    res.end(JSON.stringify(payload), () => {
      const socket = res.socket;
      if (!socket || socket.destroyed) { start(); return; }
      let attempts = 0;
      const tryStart = () => {
        if (!socket || socket.destroyed || socket.writableLength === 0 || ++attempts > 200) {
          start();
          return;
        }
        setTimeout(tryStart, 10);
      };
      tryStart();
    });
  };

  const startHandler = async (req, res) => {
    pruneJobs();
    const body = req.body || {};

    // A running job must be cancelled before another can take the worker.
    if (activeJobId) {
      res.status(409).json({
        success: false,
        error: 'A video OCR scan is already running.',
        jobId: activeJobId,
      });
      return;
    }

    const uploaded = req.file || (req.files && req.files.videoFile) || null;
    let videoPath;
    if (uploaded?.path) {
      videoPath = uploaded.path;
    } else {
      const resolved = resolveLocalVideo(body.videoPath || body.videoFilePath || body.path || body.filePath);
      if (resolved.error) {
        res.status(400).json({ success: false, error: resolved.error });
        return;
      }
      videoPath = resolved.path;
    }

    let rawRoi = body.roi;
    if (typeof rawRoi === 'string') {
      try {
        rawRoi = JSON.parse(rawRoi);
      } catch {}
    }
    const roi = rawRoi && typeof rawRoi === 'object' ? rawRoi : DEFAULT_ROI;
    const language = normalizeOcrLanguage(body.language || 'multilingual');
    if (isVietnameseOcrLanguage(language) && !language.split('+').every(token => ['vie', 'eng'].includes(token))) {
      res.status(400).json({ success: false, error: 'Vietnamese OCR supports VI + English. Scan other source languages separately.' });
      return;
    }
    const requestedFps = Number(body.fps);
    const background =
      body.background === true || String(body.background || '').toLowerCase() === 'true';
    const ocrEngine = body.ocrEngine || body.settings?.ocrEngine || 'paddle';

    // Fall back to the file's real geometry so a client that omits the size still
    // gets a valid crop instead of an opaque ffmpeg filter error.
    let videoWidth = Number(body.videoWidth) || 0;
    let videoHeight = Number(body.videoHeight) || 0;
    let videoDuration = Number(body.videoDuration) || 0;
    if (!videoWidth || !videoHeight) {
      const probed = await probeVideoDimensions(videoPath);
      videoWidth = videoWidth || probed.width;
      videoHeight = videoHeight || probed.height;
      if (!videoDuration) videoDuration = probed.duration;
    }
    const fps = Number.isFinite(requestedFps) && requestedFps > 0
      ? Math.min(4, Math.max(0.5, requestedFps))
      : chooseAdaptiveOcrFps({
          width: videoWidth,
          height: videoHeight,
          duration: videoDuration,
        });

    let lifecycle;
    try {
      lifecycle = typeof reserveUsage === 'function' ? await reserveUsage(req) : null;
    } catch (error) {
      try { await lifecycle?.onFailure?.(); } catch {}
      res.status(Number(error?.statusCode || error?.status) || 403).json({
        success: false,
        code: error?.code || 'DAILY_QUOTA_EXCEEDED',
        error: String(error?.message || error || 'Daily Video OCR quota exceeded.'),
      });
      return;
    }

    try {
      const { jobId, run } = runScan({
        videoPath,
        roi,
        language,
        fps,
        videoWidth,
        videoHeight,
        videoDuration,
        ocrEngine,
      }, lifecycle);

      if (!background) {
        // Synchronous mode still records a job so video-ocr-status stays coherent.
        run();
        const job = jobs.get(jobId);
        // Wait for the detached scan to settle so the caller gets the subtitles.
        while (job.status.active) {
          await new Promise((r) => setTimeout(r, 200));
        }
        res.json({
          success: !job.error,
          jobId,
          ...(job.result || {}),
          ...(job.error ? { error: job.error } : {}),
        });
        return;
      }

      // res.end's callback runs once the response is flushed to the socket, so
      // the Tesseract/Paddle warm-up cannot delay the "accepted" reply the UI waits on.
      // res.json() takes no callback — it would be dropped and the job would
      // never start, leaving every poll stuck on "running" forever.
      respondThenStart(res, { success: true, accepted: true, jobId }, run);
    } catch (error) {
      try { await lifecycle?.onFailure?.(); } catch {}
      res.status(Number(error?.statusCode || error?.status) || 500).json({
        success: false,
        code: error?.code,
        error: String(error?.message || error || 'Video OCR failed.'),
      });
    }
  };

  if (multerUpload) {
    router.post('/transcribe-video-ocr', multerUpload.single('videoFile'), startHandler);
  } else {
    router.post('/transcribe-video-ocr', startHandler);
  }

  // The UI polls this through waitForBackgroundScan(), which reads `state` and
  // only unwraps `result` once state is "completed". Returning the fields flat,
  // or without a state, makes the panel poll forever.
  const stateOf = (job) => {
    if (!job) return 'idle';
    if (job.active) return 'running';
    if (job.status?.step === 'cancelled') return 'cancelled';
    if (job.error) return 'failed';
    return job.result ? 'completed' : 'failed';
  };

  router.get('/local-runtime/video-ocr-status', (req, res) => {
    const jobId = String(req.query.jobId || activeJobId || '');
    const found = readJobStatus(jobId);
    if (!found) {
      res.json({ state: 'idle', jobId: '', ...idleStatus(), error: '' });
      return;
    }
    const state = stateOf(found);
    res.json({
      state,
      jobId: found.jobId,
      ...found.status,
      error: found.error || '',
      // `result` is only meaningful once finished; waitForBackgroundScan rejects
      // a completion without it.
      result: state === 'completed' ? found.result || {} : null,
      // Convenience mirrors for callers that poll this route directly.
      ...(found.result
        ? { subtitles: found.result.subtitles, srtUrl: found.result.srtUrl }
        : {}),
    });
  });

  router.post('/local-runtime/cancel-video-ocr', (req, res) => {
    const jobId = String(req.body?.jobId || activeJobId || '');
    const job = jobs.get(jobId);
    if (!job || !job.status.active) {
      res.json({ success: true, cancelled: false, error: '' });
      return;
    }
    job.controller.abort();
    job.status = { ...job.status, active: false, step: 'cancelled' };
    res.json({ success: true, cancelled: true });
  });

  // Only advertise the engine that passed the real local preparation probe.
  const ocrEngineStatus = (language = 'multilingual') => {
    const paddleAvailable = isPaddleOcrAvailable();
    const vietnameseAvailable = isVietnameseOcrAvailable();
    const useVietnamese = isVietnameseOcrLanguage(language);
    const available = useVietnamese ? vietnameseAvailable : paddleAvailable;
    const engine = available ? (useVietnamese ? 'tesseract-vie-lstm' : 'paddle') : 'none';

    return {
      success: true,
      available,
      isReady: available,
      installed: available,
      engine,
      requiresDownload: !available,
      downloadProgress: available ? 100 : 0,
      paddleAvailable,
      vietnameseAvailable,
      tesseractAvailable: vietnameseAvailable,
      language,
      ...(useVietnamese ? vietnameseDownload : paddleRuntime.status()),
    };
  };

  router.get('/local-runtime/ocr-model-status', (req, res) => {
    res.json({ success: true, ...ocrEngineStatus(normalizeOcrLanguage(req.query.language || 'multilingual')) });
  });

  // Preparing Paddle instantiates both models.  Only write the ready marker
  // after that process exits successfully; a stale package directory must not
  // be presented as a working OCR engine.
  router.post('/local-runtime/download-ocr-model', async (req, res) => {
    const requestedLanguage = normalizeOcrLanguage(req.body?.language || 'multilingual');
    if (isVietnameseOcrLanguage(requestedLanguage)) {
      if (!vietnameseDownload.isDownloading && !isVietnameseOcrAvailable()) {
        vietnameseDownload = { isDownloading: true, downloadError: '', downloadStep: 'Preparing Vietnamese OCR' };
        prepareVietnameseOcr().catch(error => {
          vietnameseDownload.downloadError = String(error?.message || 'Vietnamese OCR preparation failed.');
        }).finally(() => { vietnameseDownload.isDownloading = false; vietnameseDownload.downloadStep = ''; });
      }
      res.status(vietnameseDownload.isDownloading ? 202 : 200).json(ocrEngineStatus(requestedLanguage));
      return;
    }
    paddleRuntime.start();
    res.status(paddleRuntime.status().isDownloading ? 202 : 200).json(ocrEngineStatus(requestedLanguage));
  });

  return router;
}

module.exports = createVideoOcrRouter;
