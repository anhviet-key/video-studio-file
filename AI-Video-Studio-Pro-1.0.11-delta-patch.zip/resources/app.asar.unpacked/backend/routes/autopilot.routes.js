const express = require('express');
const queueManager = require('../utils/queue_manager');

module.exports = function (helpers) {
  const router = express.Router();
  router.use(async (req, res, next) => {
    try {
      if (req.method !== 'GET') await helpers.requireTrustedJobRequest?.(req);
      next();
    } catch (error) { res.status(error.statusCode || 403).json({ code: error.code, error: error.message }); }
  });
  const {
    asyncHandler,
    hasAnyAiProvider,
    normalizeAutoDeliveryConfig,
    normalizeAppUserId,
    getYouTubeUserRecordForUpload,
    getRemoteYouTubeAccessToken,
    canUploadWithChannel,
    getYouTubeBrowserAccountsStatus = null,
    getTikTokAccountConfig = () => ({}),
    getFacebookPageConfig = () => ({}),
    validateFacebookPageConnection = null,
    getRequestAccessPlanId = () => 'basic',
    authorizeJobRequest = null,
    normalizeAutoStartTime,
    getEffectiveAutoBatchCount,
    normalizeAutoTopicScripts,
    normalizeAutoTopicFileMap,
    normalizeAutoTopicThumbMap,
    normalizeAutoTopicTextMap,
    normalizeThumbnailConfig,
    getAutoTopicRequest,
    getResolvedAutoTopicWordCount,
    formatAutoTopicLabel,
    getAutoLanguageLabel,
    AUTO_STAGE_LABELS,
    startQueueExecutorLoop
  } = helpers;

  // ── Helpers ───────────────────────────────────────────────────────────

  async function checkJobAccess(req, res, job) {
    const config = job.config || {};
    const hasSocial = (job.publishTargets || []).some(target => ['youtube', 'tiktok', 'facebook'].includes(target?.platform)) ||
      (config.autoDownloadOnly !== true && config.deliveryMode !== 'local' && (config.targetPlatforms || []).length > 0);
    if (hasSocial && !queueManager.isLicenseTierAtLeast(getRequestAccessPlanId(req), 'plus')) {
      res.status(403).json({ code: 'FEATURE_LOCKED', error: 'Social publishing requires an active Plus, Pro or Lifetime license.' });
      return false;
    }
    try {
      if (authorizeJobRequest) await authorizeJobRequest(req, job);
      return true;
    } catch (error) {
      res.status(error.statusCode || 403).json({ code: error.code || 'FEATURE_LOCKED', error: error.message });
      return false;
    }
  }

  function buildSlotConfig(normalizedConfig, slotIndex) {
    const topicRequest = getAutoTopicRequest(normalizedConfig, slotIndex);
    return {
      ...normalizedConfig,
      topicSourceIndex: slotIndex,
      batchCount: 1,
      topicList: topicRequest.rawLine || topicRequest.topic || '',
      topicScripts: normalizedConfig.topicScripts?.[String(slotIndex)]
        ? { '0': normalizedConfig.topicScripts[String(slotIndex)] }
        : {},
      topicMediaMap: normalizedConfig.topicMediaMap?.[String(slotIndex)]
        ? { '0': normalizedConfig.topicMediaMap[String(slotIndex)] }
        : {},
      topicThumbMap: normalizedConfig.topicThumbMap?.[String(slotIndex)]
        ? { '0': normalizedConfig.topicThumbMap[String(slotIndex)] }
        : {},
      topicThumbTextMap: normalizedConfig.topicThumbTextMap?.[String(slotIndex)]
        ? { '0': normalizedConfig.topicThumbTextMap[String(slotIndex)] }
        : {},
    };
  }

  function addMinutesToTimeString(baseStartTime, slotIndex, intervalMin) {
    const parts = String(baseStartTime || '12:00').split(':').map(Number);
    const totalMinutes =
      ((parts[0] || 0) * 60 + (parts[1] || 0)) +
      slotIndex * (Number(intervalMin) || 30);
    const h = Math.floor(totalMinutes / 60) % 24;
    const m = totalMinutes % 60;
    return `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
  }

  function computeScheduledAt(baseStartTime, slotIndex, intervalMin) {
    const parts = String(baseStartTime || '12:00').split(':').map(Number);
    const now = new Date();
    const baseDate = new Date(
      now.getFullYear(),
      now.getMonth(),
      now.getDate(),
      Math.max(0, Math.min(23, parts[0] || 0)),
      Math.max(0, Math.min(59, parts[1] || 0)),
      0,
      0,
    );
    if (baseDate.getTime() + 60 * 1000 <= now.getTime()) {
      baseDate.setDate(baseDate.getDate() + 1);
    }
    baseDate.setMinutes(
      baseDate.getMinutes() + slotIndex * (Number(intervalMin) || 30),
    );
    return baseDate.toISOString();
  }

  function avoidSocialScheduleCollision(scheduledAt, publishTargets = []) {
    if (!scheduledAt) return { scheduledAt, shiftedMinutes: 0 };
    const platforms = new Set(publishTargets.map((target) => target.platform));
    let candidate = Date.parse(scheduledAt);
    if (!Number.isFinite(candidate)) return { scheduledAt, shiftedMinutes: 0 };
    const existing = queueManager.getQueueStatus().activeQueue || [];
    let shiftedMinutes = 0;
    let collision = false;
    for (let attempt = 0; attempt < 24; attempt += 1) {
      collision = existing.some((job) => {
        const jobTime = Date.parse(job.scheduledAt || job.config?.scheduledAt || '');
        const jobPlatforms = job.publishTargets || [];
        return Number.isFinite(jobTime) &&
          Math.abs(jobTime - candidate) < 15 * 60 * 1000 &&
          jobPlatforms.some((target) => platforms.has(target.platform));
      });
      if (!collision) break;
      candidate += 15 * 60 * 1000;
      shiftedMinutes += 15;
    }
    const result = { scheduledAt: new Date(candidate).toISOString(), shiftedMinutes };
    if (collision) {
      result.scheduleWarning = '[AutoPilot] Schedule overflow: could not find free slot after 24 shifts (6h window). Video may overlap with existing schedule.';
      console.warn(result.scheduleWarning);
    }
    return result;
  }

  function hasManualScriptForEverySlot(config = {}) {
    const totalSlots = Math.max(1, getEffectiveAutoBatchCount(config) || 1);
    const scripts = normalizeAutoTopicScripts(config?.topicScripts);
    for (let index = 0; index < totalSlots; index += 1) {
      if (!String(scripts[String(index)] || '').trim()) return false;
    }
    return true;
  }

  function hasRequiredMediaForEverySlot(config = {}) {
    const totalSlots = Math.max(1, getEffectiveAutoBatchCount(config) || 1);
    const mediaMap = normalizeAutoTopicFileMap(config?.topicMediaMap);
    for (let index = 0; index < totalSlots; index += 1) {
      const items = Array.isArray(mediaMap[String(index)])
        ? mediaMap[String(index)]
        : [];
      if (items.length === 0) return false;
    }
    return true;
  }

  function hasRequiredThumbsForEverySlot(config = {}) {
    const totalSlots = Math.max(1, getEffectiveAutoBatchCount(config) || 1);
    const thumbMap = normalizeAutoTopicThumbMap(config?.topicThumbMap);
    for (let index = 0; index < totalSlots; index += 1) {
      if (!String(thumbMap[String(index)] || '').trim()) return false;
    }
    return true;
  }

  function normalizeTargetPlatform(value = 'youtube') {
    const platform = String(value || '').trim().toLowerCase();
    return ['youtube', 'tiktok', 'facebook'].includes(platform)
      ? platform
      : 'youtube';
  }

  async function validateUploadTarget(
    deliveryConfig,
    normalizedAppUserId,
    channelId,
    normalizedLicenseTier,
  ) {
    const targetPlatform = normalizeTargetPlatform(
      deliveryConfig.targetPlatform,
    );
    if (deliveryConfig.autoDownloadOnly) {
      return {
        targetPlatform,
        normalizedChannelId: '',
        accountName: 'Local download',
      };
    }
    if (!queueManager.isLicenseTierAtLeast(normalizedLicenseTier, 'plus')) {
      return {
        error:
          'AUTO-PILOT social upload is available from the Plus plan. Use local download only or upgrade your license.',
        status: 403,
      };
    }

    if (targetPlatform === 'tiktok') {
      const account = await getTikTokAccountConfig(normalizedAppUserId) || {};
      const hasApiAccessToken = Boolean(String(account.accessToken || '').trim());
      const hasBrowserSession = account.browserSession === true;
      if (!account.connected || (!hasApiAccessToken && !hasBrowserSession)) {
        return {
          error:
            'A connected TikTok Creator account is required. Log in with TikTok, add a valid access token, or use local download.',
          status: 400,
        };
      }
      return {
        targetPlatform,
        normalizedChannelId: '',
        accountName:
          String(account.displayName || account.handle || '').trim() ||
          'TikTok Creator',
        accountHandle: String(account.handle || '').trim(),
      };
    }

    if (targetPlatform === 'facebook') {
      const page = getFacebookPageConfig(normalizedAppUserId) || {};
      if (
        !page.connected ||
        !String(page.pageId || '').trim() ||
        !String(page.pageAccessToken || page.accessToken || '').trim()
      ) {
        return {
          error:
            'A connected Facebook Page is required. Add a valid Page ID and Page access token in the Facebook API tab or use local download.',
          status: 400,
        };
      }
      if (typeof validateFacebookPageConnection === 'function') {
        const validation = await validateFacebookPageConnection(page);
        if (!validation?.valid) {
          return {
            error: `${validation?.error || 'Facebook Page access could not be verified.'} Reconnect Facebook before starting AUTO-PILOT.`,
            status: 400,
          };
        }
      }
      return {
        targetPlatform,
        normalizedChannelId: String(page.pageId).trim(),
        accountName: String(page.pageName || '').trim() || 'Facebook Page',
      };
    }

    let normalizedChannelId = String(channelId || '').trim();
    if (typeof getYouTubeBrowserAccountsStatus === 'function') {
      let browserStatus = null;
      try {
        browserStatus = await getYouTubeBrowserAccountsStatus();
      } catch {
        browserStatus = null;
      }
      const browserAccounts = Array.isArray(browserStatus?.accounts)
        ? browserStatus.accounts
        : [];
      const browserAccount =
        browserAccounts.find((account) => {
          const identifiers = [
            account?.browserAccountId,
            account?.channelId,
            account?.handle,
          ]
            .map((value) => String(value || '').trim().toLowerCase())
            .filter(Boolean);
          return (
            normalizedChannelId &&
            identifiers.includes(normalizedChannelId.toLowerCase())
          );
        }) ||
        browserAccounts.find((account) => account?.activeAccount) ||
        browserStatus?.account ||
        null;
      const browserAccountId = String(
        browserAccount?.browserAccountId ||
          browserAccount?.channelId ||
          browserAccount?.handle ||
          '',
      ).trim();
      if (
        browserAccountId &&
        (browserAccount?.connected !== false ||
          browserAccount?.uploadMode === 'electron-browser')
      ) {
        return {
          targetPlatform,
          normalizedChannelId: browserAccountId,
          accountName:
            String(
              browserAccount?.title ||
                browserAccount?.displayName ||
                browserAccount?.accountName ||
                browserAccount?.handle ||
                '',
            ).trim() || 'YouTube',
          uploadMode: 'electron-browser',
        };
      }
    }
    const userRecord = await getYouTubeUserRecordForUpload(normalizedAppUserId);
    if (
      !normalizedChannelId &&
      Array.isArray(userRecord?.channels) &&
      userRecord.channels.length > 0
    ) {
      normalizedChannelId = String(userRecord.activeId || (userRecord.channels.length === 1 ? userRecord.channels[0].id : '') || '').trim();
    }
    if (!normalizedChannelId) {
      return {
        error:
          'A YouTube upload channel is required. Select a channel or use the local download schedule.',
        status: 400,
      };
    }
    const uploadChannel = userRecord?.channels?.find(
      (channel) => channel.id === normalizedChannelId,
    );
    if (!normalizedAppUserId || !canUploadWithChannel(uploadChannel)) {
      return {
        error:
          'The selected YouTube channel is not authorized. Reconnect the channel in the YouTube API tab.',
        status: 400,
      };
    }
    if (uploadChannel.remoteManaged) {
      try {
        const tokenPayload = await getRemoteYouTubeAccessToken(
          normalizedAppUserId,
          normalizedChannelId,
        );
        if (!tokenPayload?.accessToken) {
          return {
            error:
              'YouTube upload permission could not be confirmed. Reconnect the selected channel in the YouTube API tab.',
            status: 400,
          };
        }
      } catch (error) {
        return {
          error:
            error?.message ||
            'Unable to verify YouTube upload permission. Reconnect the selected channel and try again.',
          status: 502,
        };
      }
    }
    return {
      targetPlatform,
      normalizedChannelId,
      accountName: String(uploadChannel?.title || '').trim() || 'YouTube',
    };
  }

  async function validateUploadTargets(
    deliveryConfig,
    normalizedAppUserId,
    normalizedTikTokAppUserId,
    channelId,
    normalizedLicenseTier,
  ) {
    if (deliveryConfig.autoDownloadOnly) {
      return {
        targets: [{ platform: 'local', channelId: '', accountName: 'Local download' }],
      };
    }
    const platforms = Array.isArray(deliveryConfig.targetPlatforms)
      ? deliveryConfig.targetPlatforms
      : [deliveryConfig.targetPlatform];
    const targets = [];
    for (const platform of platforms) {
      const result = await validateUploadTarget(
        { ...deliveryConfig, targetPlatform: platform },
        platform === 'tiktok'
          ? normalizedTikTokAppUserId || normalizedAppUserId
          : normalizedAppUserId,
        platform === 'youtube' ? channelId : '',
        normalizedLicenseTier,
      );
      if (result.error) return result;
      targets.push({
        platform,
        channelId: result.normalizedChannelId || '',
        accountName: result.accountName || platform,
        ...(result.uploadMode ? { uploadMode: result.uploadMode } : {}),
        ...(result.accountHandle ? { accountHandle: result.accountHandle } : {}),
      });
    }
    return { targets };
  }

  function validateSlotResources(config = {}) {
    const missingScripts = !hasManualScriptForEverySlot(config);
    if (missingScripts) {
      return {
        error:
          'No AI provider is configured and one or more topic scripts are missing. Add an AI provider or fill every slot before starting AUTO-PILOT.',
      };
    }
    return null;
  }

  function getPublishPreflight(config = {}, publishTargets = []) {
    const limits = {
      youtube: { title: 100, caption: 5000, hashtags: 500 },
      tiktok: { title: 150, caption: 2200, hashtags: 400 },
      facebook: { title: 255, caption: 5000, hashtags: 500 },
    };
    const warnings = [];
    const blockingErrors = [];
    publishTargets.forEach(({ platform }) => {
      const post = config.brandRules?.platformRules?.[platform] || {};
      const platformLimits = limits[platform];
      if (!platformLimits) return;
      [
        ['cta', 'CTA', platformLimits.caption],
        ['hashtags', 'hashtags', platformLimits.hashtags],
      ].forEach(([field, label, limit]) => {
        const length = String(post[field] || '').trim().length;
        if (length > limit) {
          blockingErrors.push(`${platform} ${label} exceeds ${limit} characters.`);
        }
      });
      const globalCtaLength = String(config.brandRules?.globalCta || '').trim().length;
      const globalHashtagLength = String(config.brandRules?.globalHashtags || '').trim().length;
      if (globalCtaLength > platformLimits.caption) {
        blockingErrors.push(`${platform} brand CTA exceeds ${platformLimits.caption} characters.`);
      }
      if (globalHashtagLength > platformLimits.hashtags) {
        blockingErrors.push(`${platform} brand hashtags exceed ${platformLimits.hashtags} characters.`);
      }
      if (platform === 'tiktok' && config.tiktokAiTag === false) {
        warnings.push('TikTok AI disclosure is disabled. Confirm the content does not require the AI-generated-content label before publishing.');
      }
      if (platform === 'facebook' && String(config.facebookFormat || 'reels').toLowerCase() !== 'reels') {
        blockingErrors.push('Facebook publishing currently supports Reels only.');
      }
      if (platform === 'facebook' && String(config.facebookPrivacy || 'public').toLowerCase() !== 'public') {
        blockingErrors.push('Facebook Page Reels private publishing is not supported. Choose local export for a private preview.');
      }
    });
    return { warnings, blockingErrors };
  }

  function getSlotResourceWarnings(config = {}) {
    const missingMedia = !hasRequiredMediaForEverySlot(config);
    const missingThumbs = !hasRequiredThumbsForEverySlot(config);
    if (!missingMedia && !missingThumbs) return [];
    return [
      ...(missingMedia ? ['one or more media slots are empty'] : []),
      ...(missingThumbs ? ['one or more thumbnail slots are empty'] : []),
    ];
  }

  async function createAutoJobs({
    config,
    channelId,
    channelName,
    normalizedAppUserId,
    normalizedTikTokAppUserId,
    normalizedLicenseTier,
    runImmediately = false,
  }) {
    const deliveryConfig = normalizeAutoDeliveryConfig(config);
    const channelResult = await validateUploadTargets(
      deliveryConfig,
      normalizedAppUserId,
      normalizedTikTokAppUserId,
      channelId,
      normalizedLicenseTier,
    );
    if (channelResult.error) {
      return { error: channelResult.error, status: channelResult.status || 400 };
    }
    const publishTargets = channelResult.targets || [];
    const preflight = getPublishPreflight(config, publishTargets);
    if (preflight.blockingErrors.length > 0) {
      return { error: preflight.blockingErrors.join(' '), status: 400 };
    }
    const primaryTarget =
      publishTargets.find((target) => target.platform === deliveryConfig.targetPlatform) ||
      publishTargets[0] || { channelId: '', accountName: 'Social upload' };

    const normalizedConfig = {
      ...(config || {}),
      ...deliveryConfig,
      runImmediately,
      startTime: normalizeAutoStartTime(config?.startTime),
      batchCount: Math.max(1, getEffectiveAutoBatchCount(config) || 1),
      topicScripts: normalizeAutoTopicScripts(config?.topicScripts),
      topicMediaMap: normalizeAutoTopicFileMap(config?.topicMediaMap),
      topicThumbMap: normalizeAutoTopicThumbMap(config?.topicThumbMap),
      topicThumbTextMap: normalizeAutoTopicTextMap(config?.topicThumbTextMap),
      thumbnailConfig: normalizeThumbnailConfig(config?.thumbnailConfig),
    };

    const totalSlots = Math.max(1, normalizedConfig.batchCount || 1);
    const langLabel = getAutoLanguageLabel(normalizedConfig?.langA);
    const resolvedChannelId = deliveryConfig.autoDownloadOnly
      ? null
      : primaryTarget.channelId;
    const resolvedChannelName = deliveryConfig.autoDownloadOnly
      ? channelName || 'Local download'
      : channelName || primaryTarget.accountName;
    const createdJobIds = [];
    const scheduleWarnings = [];

    for (let i = 0; i < totalSlots; i++) {
      const topicRequest = getAutoTopicRequest(normalizedConfig, i);
      const targetWords = getResolvedAutoTopicWordCount(
        normalizedConfig,
        i,
        topicRequest.wordCount,
      );
      const topicLabel = formatAutoTopicLabel(
        { ...topicRequest, wordCount: targetWords },
        langLabel,
        config?.topic,
      );
      const slotConfig = {
        ...buildSlotConfig(normalizedConfig, i),
        runImmediately,
        startTime: runImmediately
          ? 'Run Now'
          : addMinutesToTimeString(
              normalizedConfig.startTime,
              i,
              normalizedConfig.intervalMin,
            ),
        scheduledAt: runImmediately
          ? undefined
          : computeScheduledAt(
              normalizedConfig.startTime,
              i,
              normalizedConfig.intervalMin,
            ),
      };
      if (normalizedConfig.smartSchedule && slotConfig.scheduledAt) {
        const adjusted = avoidSocialScheduleCollision(slotConfig.scheduledAt, publishTargets);
        slotConfig.scheduledAt = adjusted.scheduledAt;
        if (adjusted.scheduleWarning) {
          scheduleWarnings.push(adjusted.scheduleWarning);
        } else if (adjusted.shiftedMinutes > 0) {
          scheduleWarnings.push(`Slot ${i + 1} shifted by ${adjusted.shiftedMinutes} minutes to avoid a social publishing collision.`);
        }
      }

      const jobId = queueManager.createJobId();
      queueManager.addJob({
        id: jobId,
        config: slotConfig,
        appUserId: normalizedAppUserId,
        tiktokAppUserId: normalizedTikTokAppUserId || normalizedAppUserId,
        channelId: resolvedChannelId,
        channelName: resolvedChannelName,
        publishTargets,
        publishResults: Object.fromEntries(
          publishTargets
            .filter((target) => target.platform !== 'local')
            .map((target) => [target.platform, {
              status: 'pending',
              accountName: target.accountName,
              idempotencyKey: `${jobId}:${target.platform}:${Date.now()}`,
            }]),
        ),
        time: slotConfig.startTime || 'Run Now',
        scheduledAt: slotConfig.scheduledAt,
        topic: topicLabel,
        targetWords,
        status: slotConfig.requireApproval ? 'awaiting_approval' : 'pending',
        generatedCount: 0,
        stage: 'queued',
        stageLabel: AUTO_STAGE_LABELS.queued,
        step: 'Queued...',
        slotIndex: i,
        totalSlots,
      });
      createdJobIds.push(jobId);
    }

    return { createdJobIds, scheduleWarnings, preflightWarnings: preflight.warnings };
  }

  // ── Routes ────────────────────────────────────────────────────────────

  router.get('/auto-status', (req, res) => {
    res.json(queueManager.getQueueStatus());
  });

  router.get('/social-analytics', (req, res) => {
    const history = queueManager.getQueueStatus().history || [];
    const platforms = { youtube: { published: 0, failed: 0 }, tiktok: { published: 0, failed: 0 }, facebook: { published: 0, failed: 0 } };
    history.forEach((job) => {
      Object.entries(job.publishResults || {}).forEach(([platform, result]) => {
        if (!platforms[platform]) return;
        if (result?.status === 'published') platforms[platform].published += 1;
        if (result?.status === 'failed') platforms[platform].failed += 1;
      });
    });
    res.json({
      success: true,
      period: 'all_local_history',
      platforms,
      note: 'Publication reliability is available now. Views, reach, engagement and followers require the relevant platform analytics scopes and are intentionally not estimated.',
    });
  });

  // ── RUN NOW ───────────────────────────────────────────────────────────
  router.post(
    '/start-auto',
    asyncHandler(async (req, res) => {
      const { config, channelId, channelName, time, topic, appUserId, tiktokAppUserId } =
        req.body;
      const normalizedLicenseTier = queueManager.setLicenseTier(
        getRequestAccessPlanId(req),
      );
      const hasAiProvider = hasAnyAiProvider({
        settings: config?.settings,
        apiKey: config?.geminiApiKey,
      });
      const resourceError = validateSlotResources(config);
      if (!hasAiProvider && resourceError) {
        return res.status(400).json({ error: resourceError.error });
      }

      const normalizedAppUserId = normalizeAppUserId(appUserId);
      const normalizedTikTokAppUserId = normalizeAppUserId(tiktokAppUserId) || normalizedAppUserId;
      const result = await createAutoJobs({
        config,
        channelId,
        channelName,
        normalizedAppUserId,
        normalizedTikTokAppUserId,
        normalizedLicenseTier,
        runImmediately: true,
      });
      if (result.error) {
        return res.status(result.status || 400).json({ error: result.error });
      }

      const warnings = getSlotResourceWarnings(config);
      startQueueExecutorLoop();
      res.json({
        success: true,
        message: 'Started',
        createdJobIds: result.createdJobIds,
        warnings: [...warnings, ...(result.scheduleWarnings || []), ...(result.preflightWarnings || [])].length > 0 ? [...warnings, ...(result.scheduleWarnings || []), ...(result.preflightWarnings || [])] : undefined,
        ...((result.scheduleWarnings || []).some(w => w.includes('Schedule overflow')) ? { scheduleWarning: '[AutoPilot] Schedule overflow: could not find free slot after 24 shifts (6h window). Video may overlap with existing schedule.' } : {}),
        ...queueManager.getQueueStatus(),
      });
    }),
  );

  // ── SCHEDULE / ADD TO QUEUE ───────────────────────────────────────────
  router.post(
    '/add-to-queue',
    asyncHandler(async (req, res) => {
      const { config, channelId, channelName, time, topic, appUserId, tiktokAppUserId } =
        req.body;
      const normalizedLicenseTier = queueManager.setLicenseTier(
        getRequestAccessPlanId(req),
      );
      const hasAiProvider = hasAnyAiProvider({
        settings: config?.settings,
        apiKey: config?.geminiApiKey,
      });
      const resourceError = validateSlotResources(config);
      if (!hasAiProvider && resourceError) {
        return res.status(400).json({ error: resourceError.error });
      }

      const normalizedAppUserId = normalizeAppUserId(appUserId);
      const normalizedTikTokAppUserId = normalizeAppUserId(tiktokAppUserId) || normalizedAppUserId;
      const result = await createAutoJobs({
        config,
        channelId,
        channelName,
        normalizedAppUserId,
        normalizedTikTokAppUserId,
        normalizedLicenseTier,
        runImmediately: false,
      });
      if (result.error) {
        return res.status(result.status || 400).json({ error: result.error });
      }

      const warnings = getSlotResourceWarnings(config);
      startQueueExecutorLoop();
      res.json({
        success: true,
        message: 'Added to Queue',
        createdJobIds: result.createdJobIds,
        warnings: [...warnings, ...(result.scheduleWarnings || []), ...(result.preflightWarnings || [])].length > 0 ? [...warnings, ...(result.scheduleWarnings || []), ...(result.preflightWarnings || [])] : undefined,
        ...((result.scheduleWarnings || []).some(w => w.includes('Schedule overflow')) ? { scheduleWarning: '[AutoPilot] Schedule overflow: could not find free slot after 24 shifts (6h window). Video may overlap with existing schedule.' } : {}),
        ...queueManager.getQueueStatus(),
      });
    }),
  );

  // ── CONTROL ───────────────────────────────────────────────────────────

  router.post('/stop-auto', (req, res) => {
    try {
      queueManager.stopAll({ clearHistory: req.body?.clearHistory === true });
      res.json({ success: true, ...queueManager.getQueueStatus() });
    } catch (error) {
      res.status(error.statusCode || 500).json({ success: false, code: error.code, error: error.message });
    }
  });

  router.post('/hardware-profile', (req, res) => {
    const { profile } = req.body;
    queueManager.setLicenseTier(getRequestAccessPlanId(req));
    if (!profile) {
      res.json({ success: true, ...queueManager.getQueueStatus() });
      return;
    }
    if (queueManager.setHardwareProfile(profile)) {
      res.json({ success: true, ...queueManager.getQueueStatus() });
      return;
    }
    res.status(400).json({
      error: 'Invalid hardware profile. Must be low, medium, or high.',
    });
  });

  router.delete('/queue/:id', (req, res) => {
    try {
      const result = queueManager.removeJob(req.params.id);
      if (result?.error) {
        res.status(result.error === 'Job not found.' ? 404 : 409).json({ error: result.error });
        return;
      }
      res.json({ success: true, ...queueManager.getQueueStatus() });
    } catch (error) {
      res.status(error.statusCode || 500).json({ success: false, code: error.code, error: error.message });
    }
  });

  router.post('/queue/:id/run-now', asyncHandler(async (req, res) => {
    const existing = queueManager.jobQueue.find(job => job.id === Number(req.params.id));
    if (!existing) return res.status(404).json({ error: 'Job not found' });
    if (!(await checkJobAccess(req, res, existing))) return;
    const success = queueManager.runJobNow(req.params.id);
    if (success) {
      startQueueExecutorLoop();
      res.json({ success: true, ...queueManager.getQueueStatus() });
    } else {
      res.status(404).json({ error: 'Job not found' });
    }
  }));

  router.post('/queue/:id/cancel', (req, res) => {
    const job = queueManager.cancelJob(req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }
    res.json({
      success: true,
      job,
      ...queueManager.getQueueStatus(),
    });
  });

  router.post('/queue/:id/approve', asyncHandler(async (req, res) => {
    const existing = queueManager.jobQueue.find(job => job.id === Number(req.params.id));
    if (!existing) return res.status(404).json({ error: 'Job awaiting approval was not found.' });
    if (!(await checkJobAccess(req, res, existing))) return;
    const job = queueManager.approveJob(req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Job awaiting approval was not found.' });
      return;
    }
    startQueueExecutorLoop();
    res.json({ success: true, job, ...queueManager.getQueueStatus() });
  }));

  router.patch('/queue/:id', asyncHandler(async (req, res) => {
    const allowed = new Set(['topic', 'script', 'scheduledAt', 'manualMetadata', 'targetPlatforms', 'deliveryMode', 'autoDownloadOnly']);
    if (!req.body || typeof req.body !== 'object' || Array.isArray(req.body) || Object.keys(req.body).some(key => !allowed.has(key))) {
      return res.status(400).json({ code: 'INVALID_JOB_EDIT', error: 'Only editable post fields are accepted. Publish targets and account identifiers are server-managed.' });
    }
    const changes = { ...req.body };
    if ((changes.targetPlatforms !== undefined && (!Array.isArray(changes.targetPlatforms) || changes.targetPlatforms.some(platform => !['youtube', 'tiktok', 'facebook'].includes(platform)))) ||
        (changes.autoDownloadOnly !== undefined && typeof changes.autoDownloadOnly !== 'boolean') ||
        (changes.deliveryMode !== undefined && !['local', 'youtube', 'tiktok', 'facebook'].includes(changes.deliveryMode)) ||
        (changes.scheduledAt && !Number.isFinite(Date.parse(changes.scheduledAt)))) {
      return res.status(400).json({ code: 'INVALID_JOB_EDIT', error: 'Invalid publishing target, delivery mode or scheduled date.' });
    }
    if ((changes.deliveryMode !== undefined || changes.autoDownloadOnly !== undefined) && !Array.isArray(changes.targetPlatforms)) {
      return res.status(400).json({ code: 'INVALID_JOB_EDIT', error: 'Delivery changes must include targetPlatforms for authorization.' });
    }
    if (changes.manualMetadata !== undefined) {
      if (!changes.manualMetadata || typeof changes.manualMetadata !== 'object' || Array.isArray(changes.manualMetadata) ||
          Object.keys(changes.manualMetadata).some(key => !['title', 'description', 'hashtags'].includes(key))) {
        return res.status(400).json({ code: 'INVALID_JOB_EDIT', error: 'Invalid post metadata.' });
      }
    }
    const existingJob = queueManager.getQueueStatus().queue.find(
      (candidate) => candidate.id === Number(req.params.id),
    );
    if (!existingJob) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }

    if (Array.isArray(changes.targetPlatforms)) {
      const requestedPlatforms = Array.from(new Set(
        changes.targetPlatforms
          .map((platform) => String(platform || '').trim().toLowerCase())
          .filter((platform) => ['youtube', 'tiktok', 'facebook'].includes(platform)),
      ));
      const localOnly = changes.autoDownloadOnly === true || changes.deliveryMode === 'local' || requestedPlatforms.length === 0;
      let publishTargets = [];
      let channelId = null;
      let channelName = 'Local download';
      if (!localOnly) {
        const deliveryConfig = normalizeAutoDeliveryConfig({
          ...(existingJob.config || {}),
          autoDownloadOnly: false,
          deliveryMode: requestedPlatforms[0],
          targetPlatform: requestedPlatforms[0],
          targetPlatforms: requestedPlatforms,
        });
        const validated = await validateUploadTargets(
          deliveryConfig,
          existingJob.appUserId,
          existingJob.tiktokAppUserId || existingJob.appUserId,
          existingJob.publishTargets?.find((target) => target.platform === 'youtube')?.channelId || existingJob.channelId,
          getRequestAccessPlanId(req),
        );
        if (validated.error) {
          res.status(validated.status || 400).json({ error: validated.error });
          return;
        }
        publishTargets = validated.targets || [];
        channelId = publishTargets.find((target) => target.platform === 'youtube')?.channelId || null;
        channelName = publishTargets[0]?.accountName || 'Social upload';
      }
      changes.publishTargets = publishTargets;
      changes.channelId = channelId;
      changes.channelName = channelName;
      changes.autoDownloadOnly = localOnly;
      changes.deliveryMode = localOnly ? 'local' : requestedPlatforms[0];
    }

    const candidate = { ...existingJob, config: { ...existingJob.config, ...changes,
      topicScripts: changes.script !== undefined ? { ...existingJob.config?.topicScripts, '0': changes.script } : existingJob.config?.topicScripts,
    }, publishTargets: changes.publishTargets || existingJob.publishTargets };
    if (!(await checkJobAccess(req, res, candidate))) return;
    const result = queueManager.updateScheduledJob(req.params.id, changes);
    if (result.error) {
      res.status(400).json({ error: result.error });
      return;
    }
    res.json({ success: true, job: result.job, ...queueManager.getQueueStatus() });
  }));

  router.post('/queue/:id/retry-failed-platforms', asyncHandler(async (req, res) => {
    const existing = queueManager.completedJobs.find(job => job.id === Number(req.params.id));
    if (!existing) return res.status(404).json({ error: 'Job not found' });
    if (!(await checkJobAccess(req, res, existing))) return;
    const result = queueManager.retryFailedPlatforms(req.params.id);
    if (result.error) {
      res.status(400).json({ error: result.error });
      return;
    }
    startQueueExecutorLoop();
    res.json({ success: true, job: result.job, ...queueManager.getQueueStatus() });
  }));

  return router;
};
