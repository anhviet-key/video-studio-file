const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  getEdgeTtsRuntimeStatus,
  getEdgeTtsVoices,
  synthesizeEdgeTTS,
} = require('../services/edge-tts.service');

module.exports = function (helpers = {}) {
  const router = express.Router();
  const { CACHE_DIR, buildFileUrl } = helpers;

  const edgeCacheDir = path.join(CACHE_DIR || path.join(__dirname, '..', '..', 'storage', 'cache'), 'edge_tts');
  fs.promises.mkdir(edgeCacheDir, { recursive: true }).catch(() => {});

  router.get('/status', (req, res) => {
    const runtimeStatus = getEdgeTtsRuntimeStatus();
    res.json({
      success: true,
      plugin: 'Microsoft Edge-TTS Free',
      version: '1.0.0',
      author: 'Microsoft / Community',
      enabled: runtimeStatus.available,
      available: runtimeStatus.available,
      status: runtimeStatus.available ? 'ready' : 'unavailable',
      error: runtimeStatus.error,
    });
  });

  router.get('/voices', async (req, res) => {
    try {
      const voices = await getEdgeTtsVoices();
      res.json({
        success: true,
        voices,
        total: voices.length,
        available: getEdgeTtsRuntimeStatus().available,
        status: getEdgeTtsRuntimeStatus().available ? 'ready' : 'unavailable',
        error: getEdgeTtsRuntimeStatus().error,
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.post('/generate', async (req, res) => {
    try {
      const text = String(req.body?.text || '').trim();
      const voice = String(req.body?.voice || req.body?.speaker || 'vi-VN-HoaiMyNeural').trim();
      const rate = String(req.body?.rate || '+0%').trim();
      const pitch = String(req.body?.pitch || '+0Hz').trim();

      if (!text) {
        return res.status(400).json({ error: 'Text parameter is required.' });
      }

      const result = await synthesizeEdgeTTS({ text, voice, rate, pitch });

      const hash = crypto.createHash('md5').update(`${voice}:${text}:${rate}:${pitch}`).digest('hex');
      const filename = `edge_${voice}_${hash}.mp3`;
      await fs.promises.mkdir(edgeCacheDir, { recursive: true }).catch(() => {});
      const filePath = path.join(edgeCacheDir, filename);

      const tempPath = filePath + '.tmp.' + Date.now();
      try {
        await fs.promises.writeFile(tempPath, result.audioBuffer);
        await fs.promises.rename(tempPath, filePath);
      } catch (err) {
        await fs.promises.unlink(tempPath).catch(() => {});
        throw err;
      }

      let audioUrl = '';
      if (typeof buildFileUrl === 'function') {
        audioUrl = buildFileUrl(filePath);
      } else {
        audioUrl = `/api/local-file?path=${encodeURIComponent(filePath)}`;
      }

      return res.json({
        success: true,
        audioUrl,
        audioPath: filePath,
        provider: result.provider,
        speaker: result.speaker,
        sizeBytes: result.audioBuffer.length,
      });
    } catch (err) {
      console.error('[EDGE TTS ROUTE ERROR]', err.message);
      return res.status(err.code === 'EDGE_TTS_RUNTIME_UNAVAILABLE' ? 503 : 500).json({
        code: err.code || 'EDGE_TTS_SYNTHESIS_FAILED',
        error: err.message || 'Failed to synthesize Edge-TTS audio.',
      });
    }
  });

  return router;
};
