const express = require('express');

/**
 * HTTP surface for the Electron browser sign-in flow.
 *
 * The service layer already implements every step (open an isolated window, wait
 * for the platform to report a signed-in account, persist the session, expose the
 * stored accounts, and publish through that same session). None of it was
 * reachable over HTTP: server.js never mounted these routes, so the settings UI
 * called /api/{youtube,tiktok}/browser-* and got 404 for all of them.
 *
 * One factory serves both platforms because the service modules expose an
 * identical function surface, and the UI expects an identical payload shape.
 */

function pickErrorMessage(error, fallback) {
  const message = String(error?.message || error || '').trim();
  return message || fallback;
}

function createBrowserLoginRouter({
  platform = 'youtube',
  service = {},
  unavailableMessage = 'The embedded browser is not available in this session.',
} = {}) {
  const router = express.Router();
  const {
    cancelLoginSession,
    disconnectAccount,
    getAccountStatus,
    getAccountsStatus,
    getBrowserRuntimeStatus,
    refreshAccountProfile,
    saveSessionFromCookie,
    selectBrowserAccount,
    startLoginSession,
  } = service;

  const requireService = (name, fn) => {
    if (typeof fn !== 'function') {
      throw new Error(
        `createBrowserLoginRouter(${platform}) requires service.${name} to be a function.`,
      );
    }
    return fn;
  };

  // Fail loudly at mount time rather than 500ing on first click.
  const start = requireService('startLoginSession', startLoginSession);
  const cancel = requireService('cancelLoginSession', cancelLoginSession);
  const runtimeStatus = requireService('getBrowserRuntimeStatus', getBrowserRuntimeStatus);
  const accountsStatus = requireService('getAccountsStatus', getAccountsStatus);
  const accountStatus = requireService('getAccountStatus', getAccountStatus);
  const fromCookie = requireService('saveSessionFromCookie', saveSessionFromCookie);
  const select = requireService('selectBrowserAccount', selectBrowserAccount);
  const refresh = requireService('refreshAccountProfile', refreshAccountProfile);
  const disconnect = requireService('disconnectAccount', disconnectAccount);

  // Wraps a service call so a rejected promise becomes a useful 502 instead of an
  // unhandled rejection, while keeping the route bodies declarative.
  const handle = (fn) => async (req, res) => {
    try {
      const payload = await fn(req);
      if (res.headersSent) return;
      res.json(payload && typeof payload === 'object' ? payload : { success: true });
    } catch (error) {
      if (res.headersSent) return;
      res.status(502).json({
        success: false,
        error: pickErrorMessage(error, unavailableMessage),
      });
    }
  };

  // Read-only status routes answer 200 even when the browser bridge is missing.
  // The settings UI fetches runtime and accounts in one Promise.all, so failing
  // the second request would discard the first one's actionable "open this in the
  // desktop app" warning and show a raw error instead.
  const handleStatus = (build) => async (req, res) => {
    try {
      res.json(await build());
    } catch (error) {
      res.json({ ...buildUnavailable(), error: pickErrorMessage(error, unavailableMessage) });
    }
  };
  const buildUnavailable = () => ({
    ready: false,
    warning: unavailableMessage,
  });

  router.get(
    '/browser-runtime',
    handleStatus(async () => {
      const status = await runtimeStatus();
      return {
        ...(status && typeof status === 'object' ? status : {}),
        ready: Boolean(status?.ready),
        warning: String(status?.warning || ''),
      };
    }),
  );

  router.get(
    '/browser-accounts',
    handleStatus(async () => {
      const status = await accountsStatus();
      return {
        ...buildUnavailable(),
        ready: true,
        warning: '',
        connected: Boolean(status?.connected),
        account: status?.account || null,
        accounts: Array.isArray(status?.accounts) ? status.accounts : [],
      };
    }),
  );

  router.get(
    '/account',
    handleStatus(async () => {
      const status = await accountStatus();
      return {
        ...buildUnavailable(),
        ready: true,
        warning: '',
        connected: Boolean(status?.connected),
        account: status?.account || null,
        accounts: Array.isArray(status?.accounts) ? status.accounts : [],
      };
    }),
  );

  router.post(
    '/browser-login',
    handle(async (req) => {
      const body = req.body || {};
      const result = await start({
        newAccount: body.newAccount !== false,
        forceReauth: Boolean(body.forceReauth),
        accountId: body.accountId || undefined,
      });
      const accounts = Array.isArray(result?.accounts) ? result.accounts : [];
      return {
        success: true,
        accounts,
        connected: Boolean(result?.connected || accounts.some((a) => a?.connected)),
      };
    }),
  );

  router.post(
    '/browser-login-cancel',
    handle(async () => {
      const result = await cancel();
      return { success: true, ...(result && typeof result === 'object' ? result : {}) };
    }),
  );

  router.post(
    '/session-cookie',
    handle(async (req) => {
      const cookie = String(req.body?.cookie || '').trim();
      if (!cookie) {
        return { success: false, error: 'A session cookie is required.' };
      }
      const result = await fromCookie(cookie);
      const accounts = Array.isArray(result?.accounts) ? result.accounts : [];
      return {
        success: result?.success !== false,
        accounts,
        error: result?.error,
      };
    }),
  );

  router.post(
    '/browser-select-account',
    handle(async (req) => {
      const identifier = String(req.body?.identifier || '').trim();
      if (!identifier) {
        return { success: false, error: 'An account identifier is required.' };
      }
      const result = await select(identifier);
      return {
        success: true,
        accounts: Array.isArray(result?.accounts) ? result.accounts : [],
      };
    }),
  );

  router.post(
    '/browser-profile-refresh',
    handle(async (req) => {
      const identifier = String(req.body?.identifier || '').trim();
      if (!identifier) {
        return { success: false, error: 'An account identifier is required.' };
      }
      // Node/Electron may expose an IncomingMessage signal that is already
      // aborted after the request body has been consumed. Passing that signal
      // into the browser bridge cancels a valid profile refresh immediately.
      // The bridge has its own bounded timeout, so do not reuse the HTTP body
      // lifecycle as the operation cancellation signal here.
      const result = await refresh(identifier);
      return {
        success: true,
        accounts: Array.isArray(result?.accounts) ? result.accounts : [],
      };
    }),
  );

  router.post(
    '/browser-disconnect',
    handle(async (req) => {
      const identifier = String(req.body?.identifier || '').trim();
      if (!identifier) {
        return { success: false, error: 'An account identifier is required.' };
      }
      const result = await disconnect(identifier);
      return {
        success: true,
        accounts: Array.isArray(result?.accounts) ? result.accounts : [],
      };
    }),
  );

  return router;
}

module.exports = createBrowserLoginRouter;
