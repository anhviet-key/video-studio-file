const express = require('express');
module.exports = function createLicenseRouter({ getCurrentEntitlement } = {}) {
  const router = express.Router();
  router.get('/status', async (req, res) => {
    try {
      const context = getCurrentEntitlement ? await getCurrentEntitlement(req) : { planId: 'basic', isLicensed: false };
      res.json({ tier: context.planId, ...context });
    } catch (error) { res.status(error.statusCode || 503).json({ code: error.code, error: error.message }); }
  });
  return router;
};
