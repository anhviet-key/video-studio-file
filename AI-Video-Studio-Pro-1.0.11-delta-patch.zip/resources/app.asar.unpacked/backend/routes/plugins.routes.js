const path = require('path');
const fs = require('fs');
const express = require('express');
const multer = require('multer');
const {
  getInstalledPlugins,
  saveInstalledPlugins,
  togglePlugin,
  deletePlugin,
  updatePluginConfig,
  importPluginFromManifest,
  installPluginPackage,
  exportPluginAsPackage,
  createPluginPackageTemplate,
} = require('../services/plugin-manager.service');

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 50 * 1024 * 1024 }, // 50MB max plugin package
});

module.exports = function (helpers = {}) {
  const router = express.Router();
  const { APP_STORAGE_DIR } = helpers;

  router.get('/', (req, res) => {
    try {
      const plugins = getInstalledPlugins(APP_STORAGE_DIR);
      res.json({ success: true, plugins });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  router.put('/:id/toggle', (req, res) => {
    try {
      const pluginId = req.params.id;
      const desiredState = typeof req.body?.enabled === 'boolean' ? req.body.enabled : undefined;
      const result = togglePlugin(APP_STORAGE_DIR, pluginId, desiredState);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  router.put('/:id/config', (req, res) => {
    try {
      const pluginId = req.params.id;
      const newConfig = req.body || {};
      const result = updatePluginConfig(APP_STORAGE_DIR, pluginId, newConfig);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  /**
   * DELETE /api/plugins/:id
   * Removes an installed custom plugin package.
   */
  router.delete('/:id', (req, res) => {
    try {
      const pluginId = req.params.id;
      const result = deletePlugin(APP_STORAGE_DIR, pluginId);
      res.json(result);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  /**
   * POST /api/plugins/import
   * Imports a plugin from raw JSON manifest.
   */
  router.post('/import', (req, res) => {
    try {
      const manifest = req.body;
      if (!manifest || typeof manifest !== 'object') {
        return res.status(400).json({ error: 'Nội dung file Plugin không hợp lệ.' });
      }
      const plugin = importPluginFromManifest(APP_STORAGE_DIR, manifest);
      res.json({ success: true, message: 'Đã cài đặt plugin thành công!', plugin });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  /**
   * POST /api/plugins/:id/add-voice
   * Adds a custom Voice ID to the plugin's voice list.
   */
  router.post('/:id/add-voice', (req, res) => {
    try {
      const pluginId = req.params.id;
      const { name, speaker, gender, lang, description } = req.body || {};
      if (!speaker || !speaker.trim()) {
        return res.status(400).json({ error: 'Vui lòng nhập Voice ID của ElevenLabs.' });
      }

      const list = getInstalledPlugins(APP_STORAGE_DIR);
      const target = list.find((p) => p.id === pluginId);
      if (!target) {
        return res.status(404).json({ error: `Plugin "${pluginId}" không tồn tại.` });
      }

      const newVoice = {
        id: `eleven_${speaker.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_')}`,
        speaker: speaker.trim(),
        name: String(name || `Voice ${speaker.trim().slice(0, 6)}`).trim(),
        gender: gender || 'male',
        category: 'Custom Voice ID',
        accent: 'custom',
        lang: lang || 'vi',
        langCode: lang === 'en-us' ? 'a' : (lang === 'vi' ? 'v' : lang || 'v'),
        description: description || 'Giọng đọc tùy chỉnh do người dùng thêm vào.',
        avatar: gender === 'female' ? '👩' : '👨',
      };

      target.voices = Array.isArray(target.voices) ? target.voices : [];
      const existingIdx = target.voices.findIndex((v) => v.speaker === newVoice.speaker);
      if (existingIdx >= 0) {
        target.voices[existingIdx] = newVoice;
      } else {
        target.voices.unshift(newVoice);
      }

      saveInstalledPlugins(APP_STORAGE_DIR, list);
      return res.json({ success: true, message: 'Đã thêm giọng đọc mới thành công!', voice: newVoice, voices: target.voices });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  });

  /**
   * DELETE /api/plugins/:id/voices/:voiceId
   * Deletes a custom added voice from the plugin's voice list.
   */
  router.delete('/:id/voices/:voiceId', (req, res) => {
    try {
      const { id, voiceId } = req.params;
      const list = getInstalledPlugins(APP_STORAGE_DIR);
      const target = list.find((p) => p.id === id);
      if (!target) {
        return res.status(404).json({ error: `Plugin "${id}" không tồn tại.` });
      }

      const initialLen = (target.voices || []).length;
      target.voices = (target.voices || []).filter(
        (v) => v.id !== voiceId && v.speaker !== voiceId && `eleven_${v.speaker}` !== voiceId
      );

      if (target.voices.length === initialLen) {
        return res.status(404).json({ error: 'Không tìm thấy giọng đọc cần xóa.' });
      }

      saveInstalledPlugins(APP_STORAGE_DIR, list);
      return res.json({
        success: true,
        message: 'Đã xóa giọng đọc thành công!',
        voices: target.voices,
      });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  });

  /**
   * POST /api/plugins/:id/test-keys
   * Tests all API Keys in the Multi-Key Pool and returns health & quota details.
   */
  router.post('/:id/test-keys', async (req, res) => {
    try {
      const pluginId = req.params.id;
      const list = getInstalledPlugins(APP_STORAGE_DIR);
      const target = list.find((p) => p.id === pluginId);
      if (!target) {
        return res.status(404).json({ error: `Plugin "${pluginId}" không tồn tại.` });
      }

      const path = require('path');
      const fs = require('fs');
      const pluginDir = path.join(APP_STORAGE_DIR, 'plugins', pluginId);
      const pluginEntry = path.join(pluginDir, 'index.js');
      let testFn;
      if (fs.existsSync(pluginEntry)) {
        testFn = require(pluginEntry).testKeyPool;
      } else {
        testFn = require('../../tools/plugins/elevenlabs-tts/index.js').testKeyPool;
      }

      if (typeof testFn !== 'function') {
        return res.status(400).json({ error: 'Plugin này không hỗ trợ tính năng kiểm tra Key Pool.' });
      }

      const inputConfig = {
        ...(target.config || {}),
        ...(req.body || {}),
      };

      const result = await testFn(inputConfig);
      return res.json(result);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  });

  /**
   * POST /api/plugins/:id/sync-voices
   * Synchronizes all voices from user's ElevenLabs account via API Key Pool.
   */
  router.post('/:id/sync-voices', async (req, res) => {
    try {
      const pluginId = req.params.id;
      const list = getInstalledPlugins(APP_STORAGE_DIR);
      const target = list.find((p) => p.id === pluginId);
      if (!target) {
        return res.status(404).json({ error: `Plugin "${pluginId}" không tồn tại.` });
      }

      const inputConfig = {
        ...(target.config || {}),
        ...(req.body || {}),
      };

      const path = require('path');
      const fs = require('fs');
      const pluginDir = path.join(APP_STORAGE_DIR, 'plugins', pluginId);
      const pluginEntry = path.join(pluginDir, 'index.js');
      let fetchFn;
      if (fs.existsSync(pluginEntry)) {
        fetchFn = require(pluginEntry).fetchAllVoicesFromApi;
      } else {
        fetchFn = require('../../tools/plugins/elevenlabs-tts/index.js').fetchAllVoicesFromApi;
      }

      if (typeof fetchFn !== 'function') {
        return res.status(400).json({ error: 'Plugin không hỗ trợ tính năng đồng bộ giọng đọc tự động.' });
      }

      const accountVoices = await fetchFn(inputConfig);
      if (!accountVoices || accountVoices.length === 0) {
        return res.status(400).json({ error: 'Không tìm thấy giọng đọc nào hoặc các API Key trong pool đều không hợp lệ.' });
      }

      const existingMap = new Map();
      (target.voices || []).forEach((v) => existingMap.set(v.speaker, v));
      accountVoices.forEach((v) => existingMap.set(v.speaker, v));

      target.voices = Array.from(existingMap.values());
      saveInstalledPlugins(APP_STORAGE_DIR, list);

      return res.json({
        success: true,
        message: `Đã đồng bộ thành công ${accountVoices.length} giọng đọc từ ElevenLabs API!`,
        totalVoices: target.voices.length,
        voices: target.voices,
      });
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }
  });

  /**
   * POST /api/plugins/install-package
   * Uploads and unpacks a full ZIP / .plugin.zip package bundle containing plugin.json, index.js, assets.
   */
  router.post('/install-package', upload.single('package'), (req, res) => {
    try {
      if (!req.file || !req.file.buffer) {
        return res.status(400).json({ error: 'Vui lòng chọn tệp package (.zip / .plugin.zip / .avplugin).' });
      }

      const result = installPluginPackage(APP_STORAGE_DIR, req.file.buffer);
      res.json({
        success: true,
        message: `Đã cài đặt và giải nén gói plugin "${result.plugin.name}" thành công!`,
        plugin: result.plugin,
        extractedFiles: result.extractedFiles,
      });
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  /**
   * GET /api/plugins/:id/export
   * Exports an installed plugin as a downloadable .plugin.zip package.
   */
  router.get('/:id/export', (req, res) => {
    try {
      const pluginId = req.params.id;
      const zipBuffer = exportPluginAsPackage(APP_STORAGE_DIR, pluginId);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="${pluginId}.plugin.zip"`);
      res.send(zipBuffer);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  /**
   * GET /api/plugins/templates/:type
   * Downloads a starter plugin template ZIP package.
   */
  router.get('/templates/:type', (req, res) => {
    try {
      const type = req.params.type || 'tts';
      const zipBuffer = createPluginPackageTemplate(type);
      res.setHeader('Content-Type', 'application/zip');
      res.setHeader('Content-Disposition', `attachment; filename="starter-${type}-plugin.zip"`);
      res.send(zipBuffer);
    } catch (err) {
      res.status(400).json({ error: err.message });
    }
  });

  /**
   * GET /api/plugins/voices
   * Aggregates voice options from ALL enabled TTS plugins (both built-in and packaged).
   * Returns voices in the standard frontend catalog format: { value, label, langCode, source, ... }
   */
  router.get('/voices', async (req, res) => {
    try {
      const plugins = getInstalledPlugins(APP_STORAGE_DIR);
      const allPluginVoices = [];

      for (const plugin of plugins) {
        if (!plugin.enabled || plugin.type !== 'tts') continue;

        if (plugin.id === 'capcut-tts') {
          const { getCapcutVoicesForCatalog } = require('../services/capcut-tts.service');
          const voices = getCapcutVoicesForCatalog();
          allPluginVoices.push(...voices);
        } else if (plugin.id === 'edge-tts') {
          const { getEdgeTtsRuntimeStatus, getEdgeTtsVoices } = require('../services/edge-tts.service');
          const runtimeStatus = getEdgeTtsRuntimeStatus();
          if (!runtimeStatus.available) continue;
          const edgeVoices = await getEdgeTtsVoices();
          const mapped = edgeVoices.map((v) => {
            const cleanName = String(v.name || '')
              .replace(/\s*\(Nữ chuẩn Bắc\)/gi, ' (Nữ Bắc)')
              .replace(/\s*\(Nam truyền cảm\)/gi, ' (Nam Nam)')
              .trim();
            return {
              value: `edge_${v.speaker}`,
              label: `[Edge] ${cleanName}`,
              langCode: v.lang === 'vi' ? 'v' : (v.lang.startsWith('en') ? 'a' : v.lang),
              source: 'edge-tts',
              description: v.description,
              gender: v.gender,
              speaker: v.speaker,
              avatar: v.avatar,
              pluginId: 'edge-tts',
              pluginName: 'Microsoft Edge-TTS Free',
            };
          });
          allPluginVoices.push(...mapped);
        } else if (Array.isArray(plugin.voices) && plugin.voices.length > 0) {
          // Custom packaged plugin with voices in plugin.json
          const customVoices = plugin.voices.map((v) => {
            let mappedLang = v.langCode;
            if (!mappedLang) {
              const rawLang = String(v.lang || '').toLowerCase();
              if (rawLang === 'vi' || rawLang === 'vn' || rawLang === 'v') mappedLang = 'v';
              else if (rawLang.startsWith('en-us') || rawLang === 'en' || rawLang === 'a') mappedLang = 'a';
              else if (rawLang.startsWith('en-gb') || rawLang === 'b') mappedLang = 'b';
              else if (rawLang.startsWith('ja') || rawLang === 'j') mappedLang = 'j';
              else if (rawLang.startsWith('ko') || rawLang === 'k') mappedLang = 'k';
              else if (rawLang.startsWith('zh') || rawLang === 'c' || rawLang === 'z') mappedLang = 'c';
              else if (rawLang.startsWith('fr') || rawLang === 'f') mappedLang = 'f';
              else if (rawLang.startsWith('de') || rawLang === 'd') mappedLang = 'd';
              else if (rawLang.startsWith('es') || rawLang === 'e') mappedLang = 'e';
              else if (rawLang.startsWith('it') || rawLang === 'i') mappedLang = 'i';
              else if (rawLang.startsWith('pt') || rawLang === 'p') mappedLang = 'p';
              else if (rawLang.startsWith('hi') || rawLang === 'h') mappedLang = 'h';
              else mappedLang = rawLang || 'v';
            }

            const cleanName = String(v.name || v.id || '').trim();
            const prefix = `[${plugin.name.split(' ')[0]}]`;

            return {
              value: v.id || `plugin_${plugin.id}_${v.speaker || v.name}`,
              label: `${prefix} ${cleanName}`,
              langCode: mappedLang,
              source: `plugin-${plugin.id}`,
              description: v.description || `Giọng đọc từ plugin ${plugin.name}`,
              gender: v.gender || 'neutral',
              speaker: v.speaker || v.id,
              avatar: v.avatar || '🎙️',
              pluginId: plugin.id,
              pluginName: plugin.name,
            };
          });
          allPluginVoices.push(...customVoices);
        }
      }

      res.json({ success: true, voices: allPluginVoices });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  /**
   * POST /api/plugins/synthesize
   * Dynamically synthesizes speech using the specified plugin engine (e.g. elevenlabs-tts).
   */
  router.post('/synthesize', async (req, res) => {
    try {
      const { text, voice, speaker, pluginId, config } = req.body || {};
      if (!text || !text.trim()) {
        return res.status(400).json({ error: 'Vui lòng nhập văn bản cần đọc thử.' });
      }

      const targetPluginId = pluginId || 'elevenlabs-tts';
      const plugins = getInstalledPlugins(APP_STORAGE_DIR);
      const plugin = plugins.find((p) => p.id === targetPluginId);

      if (!plugin) {
        return res.status(404).json({ error: `Plugin "${targetPluginId}" không tồn tại.` });
      }
      if (!plugin.enabled) {
        return res.status(400).json({ error: `Plugin "${plugin.name}" đang bị tắt. Vui lòng bật plugin để sử dụng.` });
      }

      let result;

      if (targetPluginId === 'capcut-tts') {
        const { synthesizeCapCutTTS, resolveCapcutSpeaker } = require('../services/capcut-tts.service');
        const resolvedSpeaker = resolveCapcutSpeaker(speaker || voice || 'capcut_vi_female_1');
        const capcutRes = await synthesizeCapCutTTS({
          text: text.trim(),
          speaker: resolvedSpeaker,
        });
        result = {
          audioBuffer: Buffer.isBuffer(capcutRes) ? capcutRes : (capcutRes?.audioBuffer || Buffer.from([])),
          format: capcutRes?.format || 'mp3',
          provider: 'capcut',
        };
      } else if (targetPluginId === 'edge-tts') {
        const { synthesizeEdgeTTS } = require('../services/edge-tts.service');
        const effectiveConfig = {
          ...(plugin.config || {}),
          ...(config || {}),
        };
        const edgeSpeaker = String(speaker || voice || 'vi-VN-HoaiMyNeural').replace(/^edge_/i, '');
        const edgeRes = await synthesizeEdgeTTS({
          text: text.trim(),
          voice: edgeSpeaker,
          pitch: effectiveConfig.pitch ? `${effectiveConfig.pitch > 0 ? '+' : ''}${effectiveConfig.pitch}Hz` : '+0Hz',
          rate: effectiveConfig.speed ? `${effectiveConfig.speed > 0 ? '+' : ''}${effectiveConfig.speed}%` : '+0%',
        });
        result = {
          audioBuffer: Buffer.isBuffer(edgeRes) ? edgeRes : (edgeRes?.audioBuffer || Buffer.from([])),
          format: edgeRes?.format || 'mp3',
          provider: 'edge-tts',
        };
      } else {
        const path = require('path');
        const fs = require('fs');
        const pluginDir = path.join(APP_STORAGE_DIR, 'plugins', targetPluginId);
        const pluginEntry = path.join(pluginDir, 'index.js');

        let engine;
        if (fs.existsSync(pluginEntry)) {
          delete require.cache[require.resolve(pluginEntry)];
          engine = require(pluginEntry);
        } else {
          const altEntry = path.join(__dirname, '..', '..', 'tools', 'plugins', targetPluginId, 'index.js');
          if (fs.existsSync(altEntry)) {
            delete require.cache[require.resolve(altEntry)];
            engine = require(altEntry);
          }
        }

        if (!engine || typeof engine.synthesize !== 'function') {
          return res.status(400).json({
            error: `Plugin "${plugin.name}" không có hàm synthesize() hợp lệ.`,
          });
        }

        const effectiveConfig = {
          ...(plugin.config || {}),
          ...(config || {}),
        };

        result = await engine.synthesize({
          text: text.trim(),
          voice: voice || speaker,
          speaker: speaker || voice,
          config: effectiveConfig,
        });
      }

      if (!result || !result.audioBuffer || result.audioBuffer.length === 0) {
        return res.status(500).json({ error: 'Plugin không trả về dữ liệu âm thanh hợp lệ.' });
      }

      const crypto = require('crypto');
      const filename = `plugin_${targetPluginId}_${crypto.randomBytes(8).toString('hex')}.${result.format || 'mp3'}`;

      // 1. Save to APP_STORAGE_DIR/outputs so express.static(OUTPUT_DIR) serves it
      const storageOutputDir = path.join(APP_STORAGE_DIR, 'outputs');
      if (!fs.existsSync(storageOutputDir)) {
        fs.mkdirSync(storageOutputDir, { recursive: true });
      }
      fs.writeFileSync(path.join(storageOutputDir, filename), result.audioBuffer);

      // 2. Also save to local backend/outputs as fallback
      const localOutputDir = path.join(__dirname, '..', 'outputs');
      if (!fs.existsSync(localOutputDir)) {
        fs.mkdirSync(localOutputDir, { recursive: true });
      }
      fs.writeFileSync(path.join(localOutputDir, filename), result.audioBuffer);

      return res.json({
        success: true,
        audioUrl: `/outputs/${filename}`,
        filename,
        provider: result.provider,
        sizeBytes: result.audioBuffer.length,
      });
    } catch (err) {
      console.error('[PLUGIN SYNTHESIZE ERROR]', err.message);
      return res.status(400).json({
        error: err.message || 'Lỗi khi tổng hợp âm thanh từ plugin.',
      });
    }
  });

  /**
   * POST /api/plugins/execute
   * Generic execution endpoint for non-TTS plugins (media, script, seo, etc.).
   * Dynamically loads the plugin's index.js and calls engine.execute(params).
   */
  router.post('/execute', async (req, res) => {
    try {
      const { pluginId, action, config, ...restParams } = req.body || {};
      if (!pluginId) {
        return res.status(400).json({ error: 'Vui lòng chỉ định pluginId.' });
      }

      const plugins = getInstalledPlugins(APP_STORAGE_DIR);
      const plugin = plugins.find((p) => p.id === pluginId);

      if (!plugin) {
        return res.status(404).json({ error: `Plugin "${pluginId}" không tồn tại.` });
      }
      if (!plugin.enabled) {
        return res.status(400).json({ error: `Plugin "${plugin.name}" đang bị tắt. Vui lòng bật plugin để sử dụng.` });
      }

      const path = require('path');
      const fs = require('fs');
      const pluginDir = path.join(APP_STORAGE_DIR, 'plugins', pluginId);
      const pluginEntry = path.join(pluginDir, 'index.js');

      let engine;
      if (fs.existsSync(pluginEntry)) {
        delete require.cache[require.resolve(pluginEntry)];
        engine = require(pluginEntry);
      } else {
        const altEntry = path.join(__dirname, '..', '..', 'tools', 'plugins', pluginId, 'index.js');
        if (fs.existsSync(altEntry)) {
          delete require.cache[require.resolve(altEntry)];
          engine = require(altEntry);
        }
      }

      if (!engine || typeof engine.execute !== 'function') {
        return res.status(400).json({
          error: `Plugin "${plugin.name}" không có hàm execute() hợp lệ.`,
        });
      }

      const effectiveConfig = {
        ...(plugin.config || {}),
        ...(config || {}),
      };

      const result = await engine.execute({
        action: action || 'default',
        config: effectiveConfig,
        ...restParams,
      });

      return res.json({
        success: true,
        pluginId,
        action: action || 'default',
        ...result,
      });
    } catch (err) {
      console.error('[PLUGIN EXECUTE ERROR]', err.message);
      return res.status(400).json({
        error: err.message || 'Lỗi khi thực thi plugin.',
      });
    }
  });

  return router;
};
