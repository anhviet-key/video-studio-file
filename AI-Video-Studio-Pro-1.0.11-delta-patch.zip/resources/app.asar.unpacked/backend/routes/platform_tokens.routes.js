const express = require('express');
const crypto = require('crypto');

const MAX_TIKTOK_AVATAR_DATA_URL_CHARS = 4 * 1024 * 1024;

function safeTikTokAvatarUrl(value = '') {
  const avatarUrl = String(value || '').trim();
  if (/^data:image\/(?:png|jpe?g|webp);base64,/i.test(avatarUrl)) {
    return avatarUrl.length <= MAX_TIKTOK_AVATAR_DATA_URL_CHARS ? avatarUrl : '';
  }
  return /^https:\/\//i.test(avatarUrl) ? avatarUrl.slice(0, 4096) : '';
}

function normalizeTikTokHandle(value = '') {
  const text = String(value || '').trim().replace(/^@+/, '');
  return text ? `@${text.slice(0, 64)}` : '';
}

function safeTikTokAccount(account = {}) {
  const expiresAt = Number(account?.expiresAt) || null;
  const isExpired = Boolean(expiresAt && expiresAt < Date.now());
  return {
    connected: Boolean(
      account?.connected &&
        (account?.accessToken ||
          account?.uploadMode === 'electron-browser' ||
          account?.browserAccountId) &&
        !isExpired,
    ),
    openId: String(account?.openId || account?.id || '').trim().slice(0, 128),
    browserAccountId: String(account?.browserAccountId || '').trim().slice(0, 128),
    uploadMode: String(account?.uploadMode || '').trim().slice(0, 40),
    activeAccount: Boolean(account?.activeAccount),
    handle: normalizeTikTokHandle(account?.handle),
    displayName: String(account?.displayName || '').trim().slice(0, 120),
    avatarUrl: safeTikTokAvatarUrl(account?.avatarUrl),
    privacyLevelOptions: Array.isArray(account?.privacyLevelOptions)
      ? account.privacyLevelOptions.map(String).filter(Boolean).slice(0, 10)
      : [],
    maxVideoPostDurationSec:
      Number(account?.maxVideoPostDurationSec) > 0
        ? Number(account.maxVideoPostDurationSec)
        : null,
    expiresAt,
    isExpired,
    hasRefreshToken: Boolean(account?.refreshToken),
    updatedAt: account?.updatedAt || null,
  };
}

function safeFacebookPage(page = {}) {
  return {
    connected: Boolean(page?.connected && page?.pageId && page?.pageAccessToken),
    pageName: String(page?.pageName || '').trim().slice(0, 120),
    pageId: String(page?.pageId || '').trim().slice(0, 64),
    avatarUrl: String(page?.avatarUrl || '').trim().slice(0, 2048),
    updatedAt: page?.updatedAt || null,
  };
}

function safeYouTubeAccount(account = {}) {
  const expiresAt = Number(account?.expiresAt) || null;
  return {
    connected: Boolean(account?.connected && account?.accessToken),
    channelId: String(account?.channelId || '').trim().slice(0, 128),
    title: String(account?.title || '').trim().slice(0, 160),
    description: String(account?.description || '').trim().slice(0, 500),
    thumbnailUrl: String(account?.thumbnailUrl || '').trim().slice(0, 2048),
    expiresAt,
    isExpired: Boolean(expiresAt && expiresAt < Date.now()),
    hasRefreshToken: Boolean(account?.refreshToken),
    updatedAt: account?.updatedAt || null,
  };
}

async function readJsonResponse(response, platformName) {
  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = {};
  }
  if (!response.ok) {
    const detail =
      payload?.error?.message ||
      payload?.error_description ||
      payload?.error?.code ||
      payload?.message ||
      text ||
      `${response.status}`;
    throw new Error(`${platformName} rejected credentials: ${detail}`);
  }
  return payload;
}

function base64UrlEncode(buffer) {
  return buffer
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');
}

function generatePKCE() {
  // TikTok Desktop Login Kit requires a verifier made up of URL-safe,
  // unreserved characters (43-128 characters), and its S256 challenge must
  // be the SHA-256 digest encoded as hexadecimal (not base64url/RFC 7636).
  const codeVerifier = crypto.randomBytes(48).toString('base64url');
  const codeChallenge = crypto
    .createHash('sha256')
    .update(codeVerifier)
    .digest('hex');
  return { codeVerifier, codeChallenge };
}

function buildTikTokAuthorizeUrl({
  clientKey,
  redirectUri,
  state,
  codeChallenge,
  scope = 'video.upload,video.publish,user.info.basic',
}) {
  const url = new URL('https://www.tiktok.com/v2/auth/authorize/');
  url.searchParams.set('client_key', clientKey);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope', scope);
  url.searchParams.set('redirect_uri', redirectUri);
  url.searchParams.set('state', state);
  if (codeChallenge) {
    url.searchParams.set('code_challenge', codeChallenge);
    url.searchParams.set('code_challenge_method', 'S256');
  }
  return url.toString();
}

function getTikTokClientConfig() {
  const clientKey = String(
    process.env.TIKTOK_CLIENT_KEY ||
      process.env.VITE_TIKTOK_CLIENT_KEY ||
      '',
  ).trim();
  const clientSecret = String(
    process.env.TIKTOK_CLIENT_SECRET ||
      process.env.VITE_TIKTOK_CLIENT_SECRET ||
      '',
  ).trim();
  const redirectUri = String(
    process.env.TIKTOK_REDIRECT_URI ||
      process.env.VITE_TIKTOK_REDIRECT_URI ||
      'http://localhost:3330/api/tiktok/oauth/callback',
  ).trim();
  const scope = String(
    process.env.TIKTOK_OAUTH_SCOPE ||
      process.env.VITE_TIKTOK_OAUTH_SCOPE ||
      'video.upload,video.publish,user.info.basic',
  ).trim();
  return { clientKey, clientSecret, redirectUri, scope };
}

function getRemoteTikTokOAuthUrl() {
  return String(
    process.env.TIKTOK_OAUTH_SERVER_URL ||
      process.env.LICENSE_SERVER_URL ||
      process.env.VITE_LICENSE_SERVER_URL ||
      '',
  ).trim().replace(/\/+$/, '');
}

async function readRemoteJson(url, options = {}, fetchImpl = fetch) {
  const response = await fetchImpl(url, {
    ...options,
    headers: { Accept: 'application/json', ...(options.headers || {}) },
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) {
    throw new Error(payload?.error || payload?.message || `Remote TikTok service failed (${response.status}).`);
  }
  return payload;
}

async function refreshTikTokAccessToken({ storage, fetchImpl = fetch }) {
  const currentAccount = storage?.get?.('tiktok_account') || {};
  const refreshToken = String(currentAccount.refreshToken || '').trim();
  if (!refreshToken) {
    throw new Error(
      'No TikTok refresh token available. Re-authentication via OAuth is required.',
    );
  }

  const { clientKey, clientSecret } = getTikTokClientConfig();
  if (!clientKey || !clientSecret) {
    throw new Error(
      'TikTok OAuth credentials (TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET) are missing.',
    );
  }

  const tokenResponse = await fetchImpl(
    'https://open.tiktokapis.com/v2/oauth/token/',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: new URLSearchParams({
        client_key: clientKey,
        client_secret: clientSecret,
        grant_type: 'refresh_token',
        refresh_token: refreshToken,
      }),
    },
  );

  const tokenPayload = await readJsonResponse(tokenResponse, 'TikTok Refresh');
  const newAccessToken = String(tokenPayload?.access_token || '').trim();
  const newRefreshToken = String(
    tokenPayload?.refresh_token || refreshToken,
  ).trim();
  const expiresInSec = Number(tokenPayload?.expires_in) || 86400;
  const refreshExpiresInSec =
    Number(tokenPayload?.refresh_expires_in) || 31536000;

  if (!newAccessToken) {
    throw new Error(
      'TikTok token refresh did not return a valid access token.',
    );
  }

  const updatedAccount = {
    ...currentAccount,
    accessToken: newAccessToken,
    refreshToken: newRefreshToken,
    expiresAt: Date.now() + expiresInSec * 1000,
    refreshTokenExpiresAt: Date.now() + refreshExpiresInSec * 1000,
    connected: true,
    updatedAt: new Date().toISOString(),
  };

  storage?.set?.('tiktok_account', updatedAccount);
  return updatedAccount;
}

function normalizeTikTokOAuthState(rawState = '') {
  const value = String(rawState || '').trim();
  if (!value) return null;
  // New requests only expose an opaque CSRF token. Keep accepting the prior
  // format briefly so an authorization started before an app update can finish.
  if (/^[a-f0-9]{48}$/i.test(value)) {
    return { platform: 'tiktok', token: value, embeddedVerifier: null };
  }
  const parts = value.split('|');
  if (parts.length < 2) return null;
  const [platform, token, embeddedVerifier] = parts;
  if (platform !== 'tiktok' || !token || token.length < 8) return null;
  return { platform, token, embeddedVerifier: embeddedVerifier || null };
}

function createTikTokOAuthState(storage, payload = {}) {
  const token = crypto.randomBytes(24).toString('hex');
  const expiresAt = Date.now() + 10 * 60 * 1000;
  try {
    const record = {
      platform: 'tiktok',
      createdAt: Date.now(),
      expiresAt,
      ...payload,
    };
    let data = {};
    const raw = storage.get?.('tiktok_oauth_states');
    if (raw && typeof raw === 'object') data = raw;
    data[token] = record;
    storage.set?.('tiktok_oauth_states', data);
  } catch {
    // ignore storage failure
  }
  return token;
}

async function consumeTikTokOAuthState(storage, token) {
  try {
    const raw = storage.get?.('tiktok_oauth_states');
    if (!raw || typeof raw !== 'object' || !raw[token]) return false;
    const record = raw[token];
    if (record.expiresAt < Date.now()) return false;
    delete raw[token];
    storage.set?.('tiktok_oauth_states', raw);
    return true;
  } catch {
    return false;
  }
}

function getTikTokAccountsList(storage) {
  let list = storage.get?.('tiktok_accounts');
  if (!Array.isArray(list)) {
    list = [];
    const single = storage.get?.('tiktok_account');
    if (single && single.connected && single.accessToken) {
      list.push(single);
    }
  }
  return list;
}

function saveTikTokAccountToList(storage, accountData) {
  let list = getTikTokAccountsList(storage);
  const handleKey = accountData.handle || accountData.displayName || 'tiktok_' + Date.now();
  accountData.handle = accountData.handle || handleKey;

  const existingIdx = list.findIndex(
    (acc) =>
      acc.handle &&
      accountData.handle &&
      acc.handle.toLowerCase() === accountData.handle.toLowerCase(),
  );

  if (existingIdx >= 0) {
    list[existingIdx] = { ...list[existingIdx], ...accountData };
  } else {
    list.push(accountData);
  }

  storage.set?.('tiktok_accounts', list);
  storage.set?.('tiktok_account', accountData);
  return accountData;
}

module.exports = function createPlatformTokensRouter({
  storage,
  asyncHandler,
  fetchImpl = fetch,
  tiktokBrowser = null,
  youtubeBrowser = null,
}) {
  const router = express.Router();
  const remoteTikTokOAuthUrl = getRemoteTikTokOAuthUrl();

  function getRemoteTikTokAppUserId(req) {
    return String(req.query?.appUserId || req.body?.appUserId || 'default_user')
      .trim()
      .toLowerCase()
      .replace(/[^a-z0-9_-]/g, '')
      .slice(0, 80) || 'default_user';
  }

  async function getRemoteTikTokAccounts(appUserId) {
    const payload = await readRemoteJson(
      `${remoteTikTokOAuthUrl}/api/tiktok/accounts?appUserId=${encodeURIComponent(appUserId)}`,
      {},
      fetchImpl,
    );
    const accounts = Array.isArray(payload.accounts) ? payload.accounts : [];
    return accounts.map((account) => ({
      ...account,
      connected: true,
      accessToken: 'remote-managed',
      openId: account.openId || account.id || '',
      handle: account.handle || account.displayName || '',
    }));
  }

  async function getBrowserTikTokStatus() {
    if (!tiktokBrowser?.getTikTokAccountsStatus) return null;
    try {
      return await tiktokBrowser.getTikTokAccountsStatus();
    } catch (error) {
      if (process.env.IS_ELECTRON === 'true') throw error;
      return null;
    }
  }

  function normalizeBrowserTikTokStatus(status = {}) {
    const accounts = Array.isArray(status.accounts)
      ? status.accounts.map(safeTikTokAccount)
      : [];
    const active =
      accounts.find((account) => account.activeAccount) ||
      safeTikTokAccount(status.account || {});
    return { account: active, accounts };
  }

  router.get(
    '/tiktok/account',
    asyncHandler(async (req, res) => {
      const browserStatus = await getBrowserTikTokStatus();
      if (browserStatus?.accounts?.length) {
        const normalized = normalizeBrowserTikTokStatus(browserStatus);
        return res.json({
          success: true,
          account: normalized.account,
          accounts: normalized.accounts,
          mode: 'electron-browser',
        });
      }
      if (remoteTikTokOAuthUrl) {
        const accounts = await getRemoteTikTokAccounts(getRemoteTikTokAppUserId(req));
        const active = accounts.find((account) => account.activeAccount) || accounts[0] || {};
        return res.json({
          success: true,
          account: safeTikTokAccount(active),
          accounts: accounts.map(safeTikTokAccount),
          mode: 'centralized',
        });
      }
      const activeAccount = storage.get?.('tiktok_account') || {};
      const accountsList = getTikTokAccountsList(storage);
      res.json({
        success: true,
        account: safeTikTokAccount(activeAccount),
        accounts: accountsList.map(safeTikTokAccount),
      });
    }),
  );

  router.put(
    '/tiktok/account/active',
    asyncHandler(async (req, res) => {
      const browserStatus = await getBrowserTikTokStatus();
      const browserIdentifier = String(
        req.body?.browserAccountId || req.body?.handle || '',
      ).trim();
      const matchingBrowserAccount = browserStatus?.accounts?.find(
        (account) =>
          String(account.browserAccountId || '').toLowerCase() ===
            browserIdentifier.toLowerCase() ||
          normalizeTikTokHandle(account.handle).toLowerCase() ===
            normalizeTikTokHandle(browserIdentifier).toLowerCase(),
      );
      if (matchingBrowserAccount && tiktokBrowser?.selectTikTokBrowserAccount) {
        const updated = await tiktokBrowser.selectTikTokBrowserAccount(
          matchingBrowserAccount.browserAccountId || matchingBrowserAccount.handle,
        );
        const normalized = normalizeBrowserTikTokStatus(updated);
        return res.json({
          success: true,
          account: normalized.account,
          accounts: normalized.accounts,
          mode: 'electron-browser',
        });
      }
      if (remoteTikTokOAuthUrl) {
        const appUserId = getRemoteTikTokAppUserId(req);
        const targetHandle = normalizeTikTokHandle(req.body?.handle);
        const accounts = await getRemoteTikTokAccounts(appUserId);
        const account = accounts.find(
          (item) => normalizeTikTokHandle(item.handle).toLowerCase() === targetHandle.toLowerCase(),
        );
        if (!account?.openId) return res.status(404).json({ error: 'TikTok account not found.' });
        await readRemoteJson(`${remoteTikTokOAuthUrl}/api/tiktok/active/${encodeURIComponent(account.openId)}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ appUserId }),
        }, fetchImpl);
        const updatedAccounts = await getRemoteTikTokAccounts(appUserId);
        const active = updatedAccounts.find((item) => item.activeAccount) || updatedAccounts[0] || {};
        return res.json({ success: true, account: safeTikTokAccount(active), accounts: updatedAccounts.map(safeTikTokAccount) });
      }
      const targetHandle = normalizeTikTokHandle(req.body?.handle);
      const accountsList = getTikTokAccountsList(storage);
      const targetAccount = accountsList.find(
        (acc) =>
          normalizeTikTokHandle(acc.handle).toLowerCase() ===
          targetHandle.toLowerCase(),
      );

      if (!targetAccount) {
        return res.status(404).json({
          error: `TikTok account with handle "${targetHandle}" not found.`,
        });
      }

      storage.set?.('tiktok_account', targetAccount);
      res.json({
        success: true,
        account: safeTikTokAccount(targetAccount),
        accounts: accountsList.map(safeTikTokAccount),
      });
    }),
  );

  router.delete(
    '/tiktok/account',
    asyncHandler(async (req, res) => {
      const browserStatus = await getBrowserTikTokStatus();
      const browserIdentifier = String(
        req.query?.browserAccountId ||
          req.body?.browserAccountId ||
          req.query?.handle ||
          req.body?.handle ||
          '',
      ).trim();
      const matchingBrowserAccount = browserIdentifier
        ? browserStatus?.accounts?.find(
            (account) =>
              String(account.browserAccountId || '').toLowerCase() ===
                browserIdentifier.toLowerCase() ||
              normalizeTikTokHandle(account.handle).toLowerCase() ===
                normalizeTikTokHandle(browserIdentifier).toLowerCase(),
          )
        : browserStatus?.accounts?.length
          ? browserStatus.accounts
          : null;
      if (matchingBrowserAccount && tiktokBrowser?.disconnectTikTokAccount) {
        const updated = await tiktokBrowser.disconnectTikTokAccount(
          browserIdentifier || '',
        );
        const normalized = normalizeBrowserTikTokStatus(updated);
        return res.json({
          success: true,
          account: normalized.account,
          accounts: normalized.accounts,
          mode: 'electron-browser',
        });
      }
      if (remoteTikTokOAuthUrl) {
        const appUserId = getRemoteTikTokAppUserId(req);
        const targetHandle = normalizeTikTokHandle(req.query?.handle || req.body?.handle);
        const accounts = await getRemoteTikTokAccounts(appUserId);
        const targets = targetHandle
          ? accounts.filter((item) => normalizeTikTokHandle(item.handle).toLowerCase() === targetHandle.toLowerCase())
          : accounts;
        await Promise.all(targets.filter((item) => item.openId).map((item) =>
          readRemoteJson(`${remoteTikTokOAuthUrl}/api/tiktok/accounts/${encodeURIComponent(item.openId)}?appUserId=${encodeURIComponent(appUserId)}`, { method: 'DELETE' }, fetchImpl),
        ));
        const updatedAccounts = await getRemoteTikTokAccounts(appUserId);
        const active = updatedAccounts.find((item) => item.activeAccount) || updatedAccounts[0] || {};
        return res.json({ success: true, account: safeTikTokAccount(active), accounts: updatedAccounts.map(safeTikTokAccount) });
      }
      const targetHandle = normalizeTikTokHandle(
        req.query?.handle || req.body?.handle,
      );
      let accountsList = getTikTokAccountsList(storage);

      if (targetHandle) {
        accountsList = accountsList.filter(
          (acc) =>
            normalizeTikTokHandle(acc.handle).toLowerCase() !==
            targetHandle.toLowerCase(),
        );
        storage.set?.('tiktok_accounts', accountsList);

        const currentActive = storage.get?.('tiktok_account') || {};
        if (
          normalizeTikTokHandle(currentActive.handle).toLowerCase() ===
          targetHandle.toLowerCase()
        ) {
          const nextActive = accountsList[0] || {};
          storage.set?.('tiktok_account', nextActive);
        }
      } else {
        storage.set?.('tiktok_accounts', []);
        storage.set?.('tiktok_account', {});
      }

      const activeAccount = storage.get?.('tiktok_account') || {};
      res.json({
        success: true,
        account: safeTikTokAccount(activeAccount),
        accounts: accountsList.map(safeTikTokAccount),
      });
    }),
  );

  router.post(
    '/tiktok/account',
    asyncHandler(async (req, res) => {
      const accessToken = String(req.body?.accessToken || '').trim();
      if (!accessToken) {
        return res.status(400).json({
          error: 'TikTok access token is required.',
        });
      }

      const verifyResponse = await fetchImpl(
        'https://open.tiktokapis.com/v2/post/publish/creator_info/query/',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: JSON.stringify({}),
        },
      );
      const verified = await readJsonResponse(verifyResponse, 'TikTok');
      if (verified?.error?.code && verified.error.code !== 'ok') {
        throw new Error(
          `TikTok rejected the credentials: ${
            verified.error.message || verified.error.code
          }`,
        );
      }

      const creator = verified?.data || {};
      let userDetail = {};
      try {
        const userRes = await fetchImpl(
          'https://open.tiktokapis.com/v2/user/info/?fields=open_id,union_id,avatar_url,avatar_url_100,avatar_large_url,display_name,username',
          {
            headers: {
              Authorization: `Bearer ${accessToken}`,
            },
          },
        );
        if (userRes.ok) {
          const uJson = await userRes.json();
          userDetail = uJson?.data?.user || {};
        }
      } catch (e) {
        // ignore
      }

      const requestedHandle = normalizeTikTokHandle(userDetail.username || req.body?.handle);
      const accountData = {
        accessToken,
        connected: true,
        handle: requestedHandle,
        displayName: String(userDetail.display_name || creator.creator_nickname || '').trim(),
        avatarUrl: String(userDetail.avatar_url_100 || userDetail.avatar_url || userDetail.avatar_large_url || creator.creator_avatar_url || '').trim(),
        privacyLevelOptions: Array.isArray(creator.privacy_level_options)
          ? creator.privacy_level_options
          : [],
        maxVideoPostDurationSec:
          Number(creator.max_video_post_duration_sec) || null,
        updatedAt: new Date().toISOString(),
      };
      saveTikTokAccountToList(storage, accountData);
      res.json({
        success: true,
        account: safeTikTokAccount(accountData),
        accounts: getTikTokAccountsList(storage).map(safeTikTokAccount),
      });
    }),
  );

  router.get('/tiktok/oauth/start', asyncHandler(async (req, res) => {
    if (remoteTikTokOAuthUrl) {
      const appUserId = getRemoteTikTokAppUserId(req);
      const authorizeUrl = new URL(`${remoteTikTokOAuthUrl}/api/auth/tiktok`);
      authorizeUrl.searchParams.set('appUserId', appUserId);
      if (req.query.json === 'true') return res.json({ success: true, authorizeUrl: authorizeUrl.toString(), mode: 'centralized' });
      return res.redirect(authorizeUrl.toString());
    }
    let { clientKey, clientSecret, redirectUri, scope } =
      getTikTokClientConfig();
    if (req.query.redirect_uri) {
      redirectUri = String(req.query.redirect_uri).trim();
    }
    if (!clientKey || !clientSecret || !redirectUri) {
      return res.status(500).json({
        error:
          'TikTok OAuth is not configured. Set TIKTOK_CLIENT_KEY, TIKTOK_CLIENT_SECRET and TIKTOK_REDIRECT_URI.',
      });
    }

    const { codeVerifier, codeChallenge } = generatePKCE();
    const stateToken = await new Promise((resolve) => {
      resolve(createTikTokOAuthState(storage, {
        codeVerifier,
      }));
    });
    const state = stateToken;

    const authorizeUrl = buildTikTokAuthorizeUrl({
      clientKey,
      redirectUri,
      state,
      codeChallenge,
      scope,
    });

    if (req.query.json === 'true' || (req.headers.accept && req.headers.accept.includes('application/json') && !req.headers.accept.includes('text/html'))) {
      return res.json({ success: true, authorizeUrl });
    }
    return res.redirect(authorizeUrl);
  }));

  router.get('/tiktok/oauth/callback', asyncHandler(async (req, res) => {
    const code = String(req.query.code || '').trim();
    const state = String(req.query.state || '').trim();
    if (!code) {
      return res
        .status(400)
        .json({ error: 'TikTok did not return an authorization code.' });
    }

    const parsedState = normalizeTikTokOAuthState(state);
    if (!parsedState) {
      return res.status(400).json({ error: 'Invalid TikTok OAuth state.' });
    }

    const { token: stateToken, embeddedVerifier } = parsedState;
    const states = storage.get?.('tiktok_oauth_states');
    const stateRecord =
      states && typeof states === 'object' ? states[stateToken] : null;

    if (!stateRecord || stateRecord.expiresAt < Date.now()) {
      return res.status(400).json({ error: 'TikTok OAuth state has expired or is invalid.' });
    }

    const defaultConfig = getTikTokClientConfig();
    const { clientKey, clientSecret, redirectUri } = defaultConfig;
    const codeVerifier =
      embeddedVerifier ||
      stateRecord?.codeVerifier ||
      '';

    if (!clientKey || !clientSecret || !redirectUri) {
      return res.status(500).json({ error: 'TikTok OAuth config is incomplete.' });
    }

    const buildTokenParams = (includePkce = true) => {
      const params = new URLSearchParams({
        client_key: clientKey,
        client_secret: clientSecret,
        code,
        grant_type: 'authorization_code',
        redirect_uri: redirectUri,
      });
      if (includePkce && codeVerifier) {
        params.set('code_verifier', codeVerifier);
      }
      return params;
    };

    // An authorization code is single-use, so invalidate the state before
    // exchanging it. Do not log codes, verifiers, credentials, or tokens.
    if (!(await consumeTikTokOAuthState(storage, stateToken))) {
      return res.status(400).json({ error: 'TikTok OAuth state has already been used.' });
    }

    let tokenPayload = {};
    let accessToken = '';
    let refreshToken = '';
    let expiresInSec = 86400;
    let refreshExpiresInSec = 31536000;

    try {
      const tokenResponse = await fetchImpl(
        'https://open.tiktokapis.com/v2/oauth/token/',
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: buildTokenParams(true),
        },
      );
      const rawText = await tokenResponse.text();
      try {
        tokenPayload = rawText ? JSON.parse(rawText) : {};
      } catch {
        tokenPayload = {};
      }

      if (!tokenResponse.ok) {
        const detail =
          tokenPayload?.error?.message ||
          tokenPayload?.error_description ||
          tokenPayload?.error?.code ||
          tokenPayload?.message ||
          rawText ||
          `${tokenResponse.status}`;
        throw new Error(`TikTok rejected credentials: ${detail}`);
      }
      if (tokenPayload?.error?.code && tokenPayload.error.code !== 'ok' && tokenPayload.error.code !== 0) {
        throw new Error(
          `TikTok rejected authorization: ${
            tokenPayload.error.message || tokenPayload.error_description || tokenPayload.error.code
          }`,
        );
      }

      accessToken = String(
        tokenPayload?.access_token ||
          tokenPayload?.data?.access_token ||
          tokenPayload?.data?.token ||
          '',
      ).trim();

      refreshToken = String(
        tokenPayload?.refresh_token ||
          tokenPayload?.data?.refresh_token ||
          '',
      ).trim();

      expiresInSec =
        Number(tokenPayload?.expires_in || tokenPayload?.data?.expires_in) ||
        86400;

      refreshExpiresInSec =
        Number(
          tokenPayload?.refresh_expires_in ||
            tokenPayload?.data?.refresh_expires_in,
        ) || 31536000;

      if (!accessToken) {
        const errorDetail =
          tokenPayload?.error?.message ||
          tokenPayload?.error_description ||
          tokenPayload?.message ||
          (Object.keys(tokenPayload).length > 0 ? JSON.stringify(tokenPayload) : '');
        throw new Error(
          errorDetail
            ? `TikTok OAuth error: ${errorDetail}`
            : 'TikTok did not return an access token.',
        );
      }
    } catch (tokenErr) {
      const errorMsg = String(tokenErr?.message || tokenErr || 'TikTok authentication failed');
      console.error('[TIKTOK OAUTH ERROR]', errorMsg);
      const errorHtml = `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <title>TikTok Connection Error</title>
            <style>
              body { font-family: system-ui, -apple-system, sans-serif; background: #0b0f19; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; text-align: center; }
              .card { background: #1f1418; border: 1px solid #ef4444; padding: 2rem; border-radius: 1rem; box-shadow: 0 10px 25px rgba(0,0,0,0.5); max-width: 480px; }
              h2 { color: #f87171; margin-top: 0; }
              p { color: #cbd5e1; font-size: 0.9rem; }
              .btn { margin-top: 1rem; background: #ef4444; color: #fff; border: none; padding: 0.5rem 1rem; border-radius: 0.5rem; cursor: pointer; font-weight: bold; }
            </style>
          </head>
          <body>
            <div class="card">
              <h2>Connection Failed</h2>
              <p>${errorMsg}</p>
              <button class="btn" onclick="window.close()">Close Window</button>
            </div>
            <script>
              try {
                if (window.opener) {
                  window.opener.postMessage({ platform: 'tiktok', status: 'error', error: ${JSON.stringify(errorMsg)} }, '*');
                }
              } catch (e) {}
            </script>
          </body>
        </html>
      `;
      res.set('Content-Type', 'text/html');
      return res.status(400).send(errorHtml);
    }

    let creatorInfo = {};
    try {
      const creatorRes = await fetchImpl(
        'https://open.tiktokapis.com/v2/post/publish/creator_info/query/',
        {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${accessToken}`,
            'Content-Type': 'application/json; charset=UTF-8',
          },
          body: JSON.stringify({}),
        },
      );
      if (creatorRes.ok) {
        const cJson = await creatorRes.json();
        creatorInfo = cJson?.data || {};
      }
    } catch (e) {
      // ignore
    }

    let userDetail = {};
    try {
      const userRes = await fetchImpl(
        'https://open.tiktokapis.com/v2/user/info/?fields=open_id,union_id,avatar_url,avatar_url_100,avatar_large_url,display_name,username',
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );
      if (userRes.ok) {
        const uJson = await userRes.json();
        userDetail = uJson?.data?.user || {};
      }
    } catch (e) {
      // ignore
    }

    const resolvedDisplayName = String(
      userDetail.display_name || creatorInfo.creator_nickname || 'TikTok Creator',
    ).trim();

    const resolvedHandle = normalizeTikTokHandle(
      userDetail.username ||
        userDetail.display_name ||
        creatorInfo.creator_nickname ||
        'creator',
    );

    const resolvedAvatarUrl = String(
      userDetail.avatar_url_100 ||
        userDetail.avatar_url ||
        userDetail.avatar_large_url ||
        creatorInfo.creator_avatar_url ||
        '',
    ).trim();

    const accountData = {
      accessToken,
      refreshToken,
      connected: true,
      handle: resolvedHandle,
      displayName: resolvedDisplayName,
      avatarUrl: resolvedAvatarUrl,
      privacyLevelOptions: Array.isArray(creatorInfo.privacy_level_options)
        ? creatorInfo.privacy_level_options
        : [],
      maxVideoPostDurationSec:
        Number(creatorInfo.max_video_post_duration_sec) || null,
      expiresAt: Date.now() + expiresInSec * 1000,
      refreshTokenExpiresAt: Date.now() + refreshExpiresInSec * 1000,
      updatedAt: new Date().toISOString(),
    };

    saveTikTokAccountToList(storage, accountData);

    const script = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>TikTok Connected</title>
          <style>
            body { font-family: system-ui, -apple-system, sans-serif; background: #0b0f19; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; text-align: center; }
            .card { background: #141a29; border: 1px solid #1e293b; padding: 2rem; border-radius: 1rem; box-shadow: 0 10px 25px rgba(0,0,0,0.5); }
            h2 { color: #34d399; margin-top: 0; }
            p { color: #94a3b8; font-size: 0.9rem; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>TikTok Connected Successfully!</h2>
            <p>Account <strong>${resolvedDisplayName}</strong> (${resolvedHandle}) has been connected.</p>
            <p>Closing window...</p>
          </div>
          <script>
            try {
              if (window.opener) {
                window.opener.postMessage({ platform: 'tiktok', status: 'connected' }, '*');
              }
            } catch (e) {
              console.error('postMessage failed:', e);
            }
            window.close();
          </script>
        </body>
      </html>
    `;
    res.set('Content-Type', 'text/html');
    res.send(script);
  }));

  router.post(
    '/facebook/account',
    asyncHandler(async (req, res) => {
      const pageId = String(req.body?.pageId || '').trim();
      const pageAccessToken = String(req.body?.pageAccessToken || '').trim();
      if (!pageId || !pageAccessToken) {
        return res.status(400).json({
          error: 'Facebook Page ID and Page Access Token are required.',
        });
      }

      const pageInfoUrl = new URL('https://graph.facebook.com/v23.0/me');
      pageInfoUrl.searchParams.set('fields', 'id,name,picture');
      pageInfoUrl.searchParams.set('access_token', pageAccessToken);

      const pageResponse = await fetchImpl(pageInfoUrl.toString());
      const pagePayload = await readJsonResponse(pageResponse, 'Facebook Page');
      const pageName = String(pagePayload?.name || '').trim();
      const avatarUrl = String(
        pagePayload?.picture?.data?.url || pagePayload?.picture || '',
      ).trim();

      const accountData = {
        pageId,
        pageAccessToken,
        connected: true,
        pageName,
        avatarUrl,
        updatedAt: new Date().toISOString(),
      };

      storage.set?.('facebook_page', accountData);
      res.json({
        success: true,
        page: safeFacebookPage(accountData),
      });
    }),
  );

  router.post(
    '/facebook/page',
    asyncHandler(async (req, res) => {
      const pageId = String(req.body?.pageId || '').trim();
      const pageAccessToken = String(req.body?.pageAccessToken || '').trim();
      if (!pageId || !pageAccessToken) {
        return res.status(400).json({
          error: 'Facebook Page ID and Page Access Token are required.',
        });
      }

      const pageInfoUrl = new URL('https://graph.facebook.com/v23.0/me');
      pageInfoUrl.searchParams.set('fields', 'id,name,picture');
      pageInfoUrl.searchParams.set('access_token', pageAccessToken);

      const pageResponse = await fetchImpl(pageInfoUrl.toString());
      const pagePayload = await readJsonResponse(pageResponse, 'Facebook Page');
      const pageName = String(pagePayload?.name || '').trim();
      const avatarUrl = String(
        pagePayload?.picture?.data?.url || pagePayload?.picture || '',
      ).trim();

      const accountData = {
        pageId,
        pageAccessToken,
        connected: true,
        pageName,
        avatarUrl,
        updatedAt: new Date().toISOString(),
      };

      storage.set?.('facebook_page', accountData);
      res.json({
        success: true,
        page: safeFacebookPage(accountData),
      });
    }),
  );

  router.get('/facebook/account', asyncHandler(async (req, res) => {
    const stored = storage.get?.('facebook_page') || {};
    res.json({
      success: true,
      page: safeFacebookPage(stored),
    });
  }));

  router.get('/facebook/page', asyncHandler(async (req, res) => {
    const stored = storage.get?.('facebook_page') || {};
    res.json({
      success: true,
      page: safeFacebookPage(stored),
    });
  }));

  router.delete('/facebook/account', asyncHandler(async (req, res) => {
    storage.set?.('facebook_page', {});
    res.json({ success: true, page: safeFacebookPage({}) });
  }));

  router.delete('/facebook/page', asyncHandler(async (req, res) => {
    storage.set?.('facebook_page', {});
    res.json({ success: true, page: safeFacebookPage({}) });
  }));

  async function getBrowserYouTubeStatus() {
    if (!youtubeBrowser?.getYouTubeAccountsStatus) return null;
    try {
      return await youtubeBrowser.getYouTubeAccountsStatus();
    } catch (error) {
      if (process.env.IS_ELECTRON === 'true') throw error;
      return null;
    }
  }

  function normalizeBrowserYouTubeStatus(status = {}) {
    const accounts = Array.isArray(status.accounts)
      ? status.accounts
      : [];
    const active =
      accounts.find((account) => account.activeAccount) ||
      status.account ||
      accounts[0] ||
      {};
    return { account: active, accounts };
  }

  router.get('/youtube/account', asyncHandler(async (req, res) => {
    const browserStatus = await getBrowserYouTubeStatus();
    if (browserStatus?.accounts?.length) {
      const normalized = normalizeBrowserYouTubeStatus(browserStatus);
      return res.json({
        success: true,
        account: normalized.account,
        accounts: normalized.accounts,
        mode: 'electron-browser',
      });
    }
    const stored = storage.get?.('youtube_channel') || {};
    res.json({
      success: true,
      account: safeYouTubeAccount(stored),
      accounts: stored.channelId ? [safeYouTubeAccount(stored)] : [],
      mode: 'official-api',
    });
  }));

  router.put(
    '/youtube/account/active',
    asyncHandler(async (req, res) => {
      const browserStatus = await getBrowserYouTubeStatus();
      const browserIdentifier = String(
        req.body?.browserAccountId || req.body?.channelId || req.body?.handle || '',
      ).trim();
      const matchingBrowserAccount = browserStatus?.accounts?.find(
        (account) =>
          String(account.browserAccountId || '').toLowerCase() === browserIdentifier.toLowerCase() ||
          String(account.channelId || '').toLowerCase() === browserIdentifier.toLowerCase() ||
          String(account.handle || '').toLowerCase() === browserIdentifier.toLowerCase(),
      );
      if (matchingBrowserAccount && youtubeBrowser?.selectYouTubeBrowserAccount) {
        const updated = await youtubeBrowser.selectYouTubeBrowserAccount(
          matchingBrowserAccount.browserAccountId || matchingBrowserAccount.channelId || matchingBrowserAccount.handle,
        );
        const normalized = normalizeBrowserYouTubeStatus(updated);
        return res.json({
          success: true,
          account: normalized.account,
          accounts: normalized.accounts,
          mode: 'electron-browser',
        });
      }
      res.json({ success: true });
    }),
  );

  router.post('/youtube/account', asyncHandler(async (req, res) => {
    const accessToken = String(req.body?.accessToken || '').trim();
    const refreshToken = String(req.body?.refreshToken || '').trim();
    const expiresInSec = Number(req.body?.expiresInSec) || 3600;
    if (!accessToken) {
      return res.status(400).json({
        error: 'YouTube access token is required.',
      });
    }

    let channelInfo = {};
    try {
      const channelRes = await fetchImpl(
        'https://www.googleapis.com/youtube/v3/channels?part=snippet,contentDetails,statistics&mine=true',
        {
          headers: {
            Authorization: `Bearer ${accessToken}`,
          },
        },
      );
      if (channelRes.ok) {
        const channelPayload = await channelRes.json();
        const item = channelPayload?.items?.[0] || {};
        channelInfo = {
          channelId: String(item.id || '').trim(),
          title: String(item.snippet?.title || '').trim(),
          description: String(item.snippet?.description || '').trim(),
          thumbnailUrl: String(
            item.snippet?.thumbnails?.default?.url || '',
          ).trim(),
        };
      }
    } catch (e) {
      // ignore
    }

    const accountData = {
      connected: true,
      ...channelInfo,
      accessToken,
      refreshToken,
      expiresAt: Date.now() + expiresInSec * 1000,
      updatedAt: new Date().toISOString(),
    };

    storage.set?.('youtube_channel', accountData);
    res.json({
      success: true,
      account: safeYouTubeAccount(accountData),
    });
  }));

  router.delete('/youtube/account', asyncHandler(async (req, res) => {
    const browserStatus = await getBrowserYouTubeStatus();
    const browserIdentifier = String(
      req.query?.browserAccountId ||
        req.body?.browserAccountId ||
        req.query?.channelId ||
        req.body?.channelId ||
        req.query?.handle ||
        req.body?.handle ||
        '',
    ).trim();

    const matchingBrowserAccount = browserIdentifier
      ? browserStatus?.accounts?.find(
          (account) =>
            String(account.browserAccountId || '').toLowerCase() === browserIdentifier.toLowerCase() ||
            String(account.channelId || '').toLowerCase() === browserIdentifier.toLowerCase() ||
            String(account.handle || '').toLowerCase() === browserIdentifier.toLowerCase(),
        )
      : browserStatus?.accounts?.length
        ? browserStatus.accounts
        : null;

    if (matchingBrowserAccount && youtubeBrowser?.disconnectYouTubeAccount) {
      const updated = await youtubeBrowser.disconnectYouTubeAccount(browserIdentifier || '');
      const normalized = normalizeBrowserYouTubeStatus(updated);
      return res.json({
        success: true,
        account: normalized.account,
        accounts: normalized.accounts,
        mode: 'electron-browser',
      });
    }

    storage.set?.('youtube_channel', {});
    res.json({ success: true, account: safeYouTubeAccount({}) });
  }));

  return router;
};
