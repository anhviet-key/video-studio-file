const express = require('express');
const { generateSceneImage } = require('../services/image_gen.service');

module.exports = function (helpers = {}) {
  const router = express.Router();
  const asyncHandler = helpers.asyncHandler || ((fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next));

  router.post('/generate-scene-image', asyncHandler(async (req, res) => {
    const { prompt, scriptText, model, style, width, height, enableAiImageGen } = req.body || {};

    if (enableAiImageGen === false) {
      return res.json({
        success: false,
        disabled: true,
        message: 'AI Image Generation is toggled OFF by user.',
      });
    }

    const promptText = (typeof prompt === 'string' ? prompt.trim() : '')
      || (typeof scriptText === 'string' ? scriptText.trim() : '')
      || 'Phong cảnh tuyệt đẹp, chất lượng cao 4k';

    const result = await generateSceneImage({ prompt: promptText, scriptText, model, style, width, height });
    if (!result.success) {
      return res.status(500).json(result);
    }

    res.json(result);
  }));

  return router;
};
