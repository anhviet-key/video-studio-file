const express = require('express');

const { readBundledVieneuPresets } = require('../utils/vieneu-presets');

module.exports = function (helpers = {}) {
  const router = express.Router();
  const listAvailableVieneuPresetVoices =
    helpers.listAvailableVieneuPresetVoices || readBundledVieneuPresets;

  router.get('/presets', (req, res) => {
    res.json({
      success: true,
      voices: [
        ...listAvailableVieneuPresetVoices().map((voice) => ({
          id: voice.id,
          name: voice.label || voice.voiceName,
          lang: 'vi',
          provider: 'vieneu',
        })),
        { id: 'af_heart', name: 'Heart (EN)', lang: 'en', provider: 'kokoro' },
        { id: 'am_adam', name: 'Adam (EN)', lang: 'en', provider: 'kokoro' },
      ],
    });
  });

  return router;
};
