const express = require('express');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');

const VIDEO_EXTENSIONS = new Set(['.mp4', '.mov', '.m4v', '.webm', '.mkv', '.avi']);

module.exports = function createPublishingMediaRouter({
  fs, ffmpegPath, cacheDir, buildFileUrl, validateThumbnail, authorize = () => true,
}) {
  const router = express.Router();
  const pending = new Map();

  router.use((req, res, next) => {
    if (!authorize(req)) return res.status(403).json({ error: 'Desktop session required.' });
    next();
  });

  const getFile = (rawPath, extensions) => {
    if (!String(rawPath || '').trim()) throw new Error('FILE_MISSING');
    const filePath = path.resolve(String(rawPath).trim());
    if (!extensions.has(path.extname(filePath).toLowerCase())) throw new Error('FILE_FORMAT');
    let stat;
    try { stat = fs.statSync(filePath); } catch { throw new Error('FILE_MISSING'); }
    if (!stat.isFile() || !stat.size) throw new Error('FILE_MISSING');
    return { filePath, stat };
  };

  const extractPreview = async (videoPath, stat) => {
    const key = crypto.createHash('sha256').update(`${videoPath}:${stat.size}:${stat.mtimeMs}`).digest('hex');
    const posterPath = path.join(cacheDir, `${key}.jpg`);
    const infoPath = path.join(cacheDir, `${key}.json`);
    if (fs.existsSync(posterPath) && fs.existsSync(infoPath)) {
      try { return { ...JSON.parse(fs.readFileSync(infoPath, 'utf8')), posterPath }; } catch { /* regenerate */ }
    }
    if (pending.has(key)) return pending.get(key);
    const task = new Promise((resolve, reject) => {
      // FFmpeg autorotates phone footage. showinfo reports the displayed frame,
      // before scaling the small poster; the original video is never rewritten.
      execFile(ffmpegPath, [
        '-hide_banner', '-i', videoPath, '-an',
        '-vf', "select=eq(n\\,0),scale=trunc(iw*sar/2)*2:ih,setsar=1,showinfo,scale=640:640:force_original_aspect_ratio=decrease",
        '-frames:v', '1', '-threads', '1', '-f', 'image2pipe', '-vcodec', 'mjpeg', 'pipe:1',
      ], { encoding: 'buffer', maxBuffer: 8 * 1024 * 1024, timeout: 30000, windowsHide: true }, (error, stdout, stderr) => {
        const log = String(stderr || '');
        const dimensions = log.match(/Parsed_showinfo[^\n]*\bs:(\d+)x(\d+)/);
        if (error || !stdout?.length || !dimensions) return reject(new Error('VIDEO_UNREADABLE'));
        const time = log.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
        const info = {
          width: Number(dimensions[1]), height: Number(dimensions[2]),
          duration: time ? Number(time[1]) * 3600 + Number(time[2]) * 60 + Number(time[3]) : 0,
        };
        try {
          fs.mkdirSync(cacheDir, { recursive: true });
          fs.writeFileSync(posterPath, stdout);
          fs.writeFileSync(infoPath, JSON.stringify(info));
          resolve({ ...info, posterPath });
        } catch (writeError) { reject(writeError); }
      });
    });
    pending.set(key, task);
    try { return await task; } finally { pending.delete(key); }
  };

  router.post('/preview', async (req, res) => {
    try {
      const { filePath, stat } = getFile(req.body?.videoPath, VIDEO_EXTENSIONS);
      const preview = await extractPreview(filePath, stat);
      // Register only this selected media file, including files on other drives.
      const videoUrl = buildFileUrl(filePath);
      let thumbnailUrl = '';
      let thumbnailWidth = 0, thumbnailHeight = 0;
      if (req.body?.thumbnailPath) {
        try {
          const thumbnail = await validateThumbnail(req.body.thumbnailPath, { isShorts: preview.width < preview.height });
          thumbnailUrl = buildFileUrl(req.body.thumbnailPath);
          thumbnailWidth = thumbnail.width;
          thumbnailHeight = thumbnail.height;
        } catch { /* a stale cover must not hide the video preview */ }
      }
      res.json({ ...preview, videoUrl, thumbnailUrl, thumbnailWidth, thumbnailHeight, posterUrl: buildFileUrl(preview.posterPath) });
    } catch (error) {
      const code = ['FILE_MISSING', 'FILE_FORMAT', 'VIDEO_UNREADABLE'].includes(error.message) ? error.message : 'VIDEO_UNREADABLE';
      res.status(400).json({ code, error: code });
    }
  });

  router.post('/thumbnail/validate', async (req, res) => {
    try {
      const { filePath } = getFile(req.body?.thumbnailPath, new Set(['.jpg', '.jpeg', '.png']));
      const info = await validateThumbnail(filePath, { isShorts: req.body?.aspectRatio === '9:16' });
      res.json({ ...info, thumbnailUrl: buildFileUrl(filePath) });
    } catch (error) {
      res.status(400).json({ error: error.message || 'THUMBNAIL_UNREADABLE' });
    }
  });
  return router;
};
