const express = require('express');
const { formatScriptPrompt, parseGeneratedScript } = require('../services/script.service');

module.exports = function (helpers = {}) {
  const router = express.Router();
  const asyncHandler = helpers.asyncHandler || ((fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next));

  router.post('/format-prompt', (req, res) => {
    const { topic, language, style, targetWords } = req.body || {};
    const prompt = formatScriptPrompt({ topic, language, style, targetWords });
    res.json({ success: true, prompt });
  });

  router.post('/parse-script', (req, res) => {
    const { rawScript } = req.body || {};
    const scenes = parseGeneratedScript(rawScript);
    res.json({ success: true, count: scenes.length, scenes });
  });

  return router;
};
