const express = require('express');
const fs = require('fs');
const path = require('path');
const {
  requireWhisperSubtitleResult,
} = require('../utils/subtitle-scan-validation');

/**
 * HTTP surface for offline speech-to-text (Whisper).
 *
 * server.js already owns every piece this needs — hasWhisperModelFiles,
 * ensureWhisperModelReady, transcribeAudioWithWhisper, cancelWhisperWorker and
 * the model-option set — but none of it was reachable: the UI polls
 * whisper-transcription-status, cancels through cancel-whisper-transcription and
 * installs models through download-whisper-model, and all four 404ed.
 *
 * The status route follows the same contract as video-ocr-status because the UI
 * drives both through waitForBackgroundScan(): a `state` of running/completed/
 * cancelled/failed, with the finished payload nested under `result`.
 */

function createWhisperRouter(helpers = {}) {
  const {
    // Injected from server.js so the model cache and worker env stay in one place.
    getDefaultModel = () => 'small',
    getModelOptions = () => ['tiny', 'base', 'small', 'medium', 'large-v3', 'large-v3-turbo'],
    hasModelFiles = () => false,
    getModelRepoId = () => '',
    getModelCacheDir = () => '',
    getModelMinBytes = () => 0,
    ensureModelReady = async () => true,
    cancelWorker = () => {},
    buildFileUrl = (p) => (p ? `/outputs/${path.basename(p)}` : null),
    // Called with the job payload once the UI has asked for a background scan.
    transcribe = null,
  } = helpers;

  const router = express.Router();

  const jobs = new Map();
  let activeJobId = '';
  let jobCounter = 0;

  const normalizeModel = (candidate) => {
    const requested = String(candidate || '').trim().toLowerCase();
    const allowed = getModelOptions();
    if (requested && allowed.includes(requested)) return requested;
    return getDefaultModel();
  };

  const modelStatus = (modelName) => {
    const model = normalizeModel(modelName);
    return {
      model,
      availableModels: getModelOptions(),
      present: Boolean(hasModelFiles(model)),
      repoId: getModelRepoId(model),
      path: getModelCacheDir(model),
      minBytes: getModelMinBytes(model),
    };
  };

  const stateOf = (job) => {
    if (!job) return 'idle';
    if (job.active) return 'running';
    if (job.cancelled) return 'cancelled';
    if (job.error) return 'failed';
    return job.result ? 'completed' : 'failed';
  };

  /**
   * Send JSON, then run `start` only once the response has reached the client.
   *
   * res.end's callback fires on 'finish' (data handed to the socket), not on a
   * completed write, so starting heavy synchronous work there still blocks the
   * event loop long enough to delay the reply. Poll writableLength until the
   * kernel buffer is empty, with a bounded number of attempts.
   */
  const respondThenStart = (res, payload, start) => {
    res.set('Content-Type', 'application/json');
    res.end(JSON.stringify(payload), () => {
      const socket = res.socket;
      if (!socket || socket.destroyed) { start(); return; }
      let attempts = 0;
      const tryStart = () => {
        if (!socket || socket.destroyed || socket.writableLength === 0 || ++attempts > 200) {
          start();
          return;
        }
        setTimeout(tryStart, 10);
      };
      tryStart();
    });
  };

  /**
   * Start a job from an already-resolved audio path.
   *
   * /api/transcribe-audio-offline does its own upload handling and path
   * validation, so it cannot simply re-POST to its own route. Exposing the
   * starter keeps a single implementation of the job lifecycle instead of a
   * second copy in server.js.
   */
  router.startBackgroundJob = (payload, lifecycle = {}) => {
    if (activeJobId && jobs.get(activeJobId)?.active) {
      const err = new Error('A transcription is already running.');
      err.statusCode = 409;
      throw err;
    }
    const jobId = `whisper-${Date.now().toString(36)}-${++jobCounter}`;
    const workingSrtPath = payload?.srtPath ? `${payload.srtPath}.${jobId}.srt` : '';
    const controller = new AbortController();
    const job = {
      active: true,
      cancelled: false,
      error: '',
      result: null,
      progress: 0,
      step: 'starting',
      progressDetails: {},
      startedAt: Date.now(),
      controller,
    };
    jobs.set(jobId, job);
    for (const [oldId, oldJob] of jobs) {
      if (jobs.size <= 50) break;
      if (oldId !== jobId && !oldJob.active) jobs.delete(oldId);
    }
    activeJobId = jobId;

    // Returns a thunk rather than starting immediately: loading a Whisper model
    // is a long synchronous prologue, and res.json() only queues the socket write.
    // Starting inline makes the client wait for the whole model warm-up before it
    // sees "accepted", with no progress bar. Callers invoke run() from the
    // response's completion callback.
    let started = false;
    const run = () => {
      if (started) return;
      started = true;
      (async () => {
      try {
        if (controller.signal.aborted) throw Object.assign(new Error('Transcription cancelled.'), { cancelled: true });
        await lifecycle.beforeStart?.();
        // transcribeAudioWithWhisper takes no abort signal, so cancelling cannot
        // interrupt the worker through the call itself. Race it: the job reports
        // cancelled immediately (the UI stops waiting) while cancelWorker() tears
        // the real worker down underneath.
        const result = await Promise.race([
          transcribe({ ...payload, srtPath: workingSrtPath, model: normalizeModel(payload?.model) }, {
            signal: controller.signal,
            onProgress: (update) => {
              const nextProgress = Number(update?.progress);
              if (Number.isFinite(nextProgress)) job.progress = nextProgress;
              job.step = String(update?.step || job.step);
              job.progressDetails = {
                ...job.progressDetails,
                ...(update && typeof update === 'object' ? update : {}),
              };
            },
          }),
          new Promise((_, reject) => {
            controller.signal.addEventListener(
              'abort',
              () => reject(Object.assign(new Error('Transcription cancelled.'), { cancelled: true })),
              { once: true },
            );
          }),
        ]);
        const audioPath = payload?.audioPath;
        const srtPath = payload?.srtPath;
        let srtContent = '';
        if (workingSrtPath && fs.existsSync(workingSrtPath)) {
          try {
            srtContent = fs.readFileSync(workingSrtPath, 'utf8');
          } catch {}
        }

        const validated = requireWhisperSubtitleResult(result, srtContent);
        const segmentsCount = validated.segmentsCount;
        if (!srtContent.trim()) throw new Error('Whisper did not create a usable SRT file.');
        // Commit only a validated result. Failure/cancellation must not destroy
        // the SRT referenced by the user's existing timeline.
        fs.renameSync(workingSrtPath, srtPath);
        await lifecycle.onComplete?.();
        const audioUrl = audioPath && fs.existsSync(audioPath) ? buildFileUrl(audioPath) : null;
        const srtUrl = buildFileUrl(srtPath);

        job.result = {
          ...(result && typeof result === 'object' ? result : { value: result }),
          audioPath,
          audioName: audioPath ? path.basename(audioPath) : '',
          audioUrl,
          srtPath,
          srtName: srtPath ? path.basename(srtPath) : '',
          srtUrl,
          transcriptText:
            validated.transcriptText ||
            (srtContent ? srtContent.replace(/\d+\r?\n\d{2}:\d{2}:\d{2},\d{3} --> \d{2}:\d{2}:\d{2},\d{3}\r?\n/g, '').replace(/\r?\n+/g, ' ').trim() : ''),
          detectedLanguage: String(result?.language || payload?.language || 'auto').trim(),
          segmentsCount,
          model: normalizeModel(payload?.model),
          srtContent,
        };
        job.step = 'completed';
        job.progress = 100;
      } catch (error) {
        job.result = null;
        try { await lifecycle.onFailure?.(); } catch (usageError) { job.error = usageError.message; }
        if (controller.signal.aborted || error?.cancelled) {
          job.cancelled = true;
          job.step = 'cancelled';
        } else {
          job.error = String(error?.message || error || 'Transcription failed.');
          job.step = 'error';
        }
      } finally {
        for (const temporaryPath of [workingSrtPath, `${workingSrtPath}.partial`]) {
          if (workingSrtPath && fs.existsSync(temporaryPath)) {
            try { fs.unlinkSync(temporaryPath); } catch {}
          }
        }
        job.active = false;
        if (activeJobId === jobId) activeJobId = '';
      }
      })();
    };

    return { jobId, run };
  };

  /**
   * Start a background transcription. The heavy lifting stays in server.js; this
   * only records progress so the UI has something to poll.
   */
  router.post('/local-runtime/start-whisper-transcription', async (req, res) => {
    if (typeof transcribe !== 'function') {
      res.status(501).json({
        error: 'Background transcription is not available in this build.',
      });
      return;
    }
    if (activeJobId && jobs.get(activeJobId)?.active) {
      res.status(409).json({
        error: 'A transcription is already running.',
        jobId: activeJobId,
      });
      return;
    }

    const body = req.body || {};
    // Reuse the shared starter so the job lifecycle, deferral and cancellation
    // race exist in exactly one place.
    let started;
    let lifecycle;
    try {
      lifecycle = await helpers.reserveUsage?.(req);
      started = router.startBackgroundJob({
        audioPath: body.audioPath || body.audioFilePath,
        srtPath: body.srtPath,
        language: body.language,
        wordsPerSubtitle: body.wordsPerSubtitle,
        model: body.model,
        settings: body.settings,
      }, lifecycle);
    } catch (error) {
      try { await lifecycle?.onFailure?.(); } catch {}
      res.status(Number(error?.statusCode) || 500).json({
        success: false,
        code: error?.code,
        error: String(error?.message || error || 'Could not start transcription.'),
      });
      return;
    }

    // Start only once "accepted" has been flushed to the client. res.json takes
    // no callback, so use res.end, which does.
    respondThenStart(
      res,
      { success: true, accepted: true, jobId: started.jobId },
      started.run,
    );
  });

  router.get('/local-runtime/whisper-transcription-status', (req, res) => {
    const jobId = String(req.query.jobId || activeJobId || '');
    const job = jobs.get(jobId);
    if (!job) {
      res.json({ state: 'idle', jobId: '', progress: 0, step: '', error: '' });
      return;
    }
    const state = stateOf(job);
    res.json({
      state,
      jobId,
      progress: job.progress,
      step: job.step,
      active: Boolean(job.active),
      ...(job.progressDetails || {}),
      error: job.cancelled ? 'Transcription cancelled.' : job.error,
      // waitForBackgroundScan throws if a completion arrives without a result.
      result: state === 'completed' ? job.result : null,
      ...(job.result
        ? {
            srtUrl: job.result.srtUrl,
            srtPath: job.result.srtPath,
            audioUrl: job.result.audioUrl,
            transcriptText: job.result.transcriptText,
            detectedLanguage: job.result.detectedLanguage,
            segmentsCount: job.result.segmentsCount,
          }
        : {}),
    });
  });

  router.post('/local-runtime/cancel-whisper-transcription', (req, res) => {
    const jobId = String(req.body?.jobId || activeJobId || '');
    const job = jobs.get(jobId);
    if (!job || !job.active) {
      res.json({ success: true, cancelled: false });
      return;
    }
    job.cancelled = true;
    job.controller?.abort();
    // Also stop the shared worker, otherwise a queued transcription keeps the
    // model resident and the UI reports cancelled while work continues.
    try {
      cancelWorker();
    } catch {
      /* the worker may not be running */
    }
    res.json({ success: true, cancelled: true });
  });

  router.get('/local-runtime/whisper-model-status', (req, res) => {
    res.json({ success: true, ...modelStatus(req.query.model) });
  });

  router.post('/local-runtime/download-whisper-model', async (req, res) => {
    const model = normalizeModel(req.body?.model);
    if (hasModelFiles(model)) {
      res.json({ success: true, alreadyInstalled: true, ...modelStatus(model) });
      return;
    }
    try {
      await ensureModelReady(model);
      res.json({ success: true, ...modelStatus(model) });
    } catch (error) {
      res.status(500).json({
        success: false,
        error: String(error?.message || error || 'Model download failed.'),
        ...modelStatus(model),
      });
    }
  });

  return router;
}

module.exports = createWhisperRouter;
