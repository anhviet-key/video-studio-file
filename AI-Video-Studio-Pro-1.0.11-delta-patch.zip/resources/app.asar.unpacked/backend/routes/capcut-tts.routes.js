const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const {
  getCapCutVoices,
  synthesizeCapCutTTS,
} = require('../services/capcut-tts.service');

module.exports = function (helpers = {}) {
  const router = express.Router();
  const { CACHE_DIR, buildFileUrl } = helpers;

  const capcutCacheDir = path.join(
    CACHE_DIR || path.join(__dirname, '..', '..', 'storage', 'cache'),
    'capcut_tts',
  );
  fs.promises.mkdir(capcutCacheDir, { recursive: true }).catch(() => {});

  router.get('/status', (req, res) => {
    const voices = getCapCutVoices();
    res.json({
      success: true,
      plugin: 'CapCut TTS Engine',
      version: '1.0.0',
      author: 'K07VN / AI Video Studio',
      enabled: true,
      available: true,
      catalogAvailable: true,
      synthesisRequiresConnection: false,
      voicesCount: voices.length,
      status: 'native-ready',
    });
  });

  router.get('/voices', (req, res) => {
    const voices = getCapCutVoices();
    res.json({
      success: true,
      voices,
      total: voices.length,
      available: true,
      catalogAvailable: true,
      synthesisRequiresConnection: false,
    });
  });

  router.post('/generate', async (req, res) => {
    try {
      const text = String(req.body?.text || '').trim();
      const speaker = String(
        req.body?.speaker || req.body?.voice || 'vi_001',
      ).trim();

      if (!text) {
        return res.status(400).json({ error: 'Text parameter is required.' });
      }

      const result = await synthesizeCapCutTTS({ text, speaker });

      const hash = crypto
        .createHash('md5')
        .update(`${speaker}:${text}`)
        .digest('hex');
      const filename = `capcut_${speaker}_${hash}.mp3`;
      await fs.promises.mkdir(capcutCacheDir, { recursive: true }).catch(() => {});
      const filePath = path.join(capcutCacheDir, filename);

      const tempPath = filePath + '.tmp.' + Date.now();
      try {
        await fs.promises.writeFile(tempPath, result.audioBuffer);
        await fs.promises.rename(tempPath, filePath);
      } catch (err) {
        await fs.promises.unlink(tempPath).catch(() => {});
        throw err;
      }

      let audioUrl = '';
      if (typeof buildFileUrl === 'function') {
        audioUrl = buildFileUrl(filePath);
      } else {
        audioUrl = `/api/local-file?path=${encodeURIComponent(filePath)}`;
      }

      return res.json({
        success: true,
        audioUrl,
        audioPath: filePath,
        provider: result.provider,
        speaker: result.speaker,
        sizeBytes: result.audioBuffer.length,
      });
    } catch (err) {
      console.error('[CAPCUT TTS ROUTE ERROR]', err.message);
      return res.status(500).json({
        error: err.message || 'Failed to synthesize CapCut TTS audio.',
      });
    }
  });

  return router;
};
