const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { withKeyedLock } = require('../utils/keyed-lock');

function resolveCorePreviewProvider(voiceId = '', langCode = 'a') {
  const voice = String(voiceId || '').trim();
  const lower = voice.toLowerCase();
  if (lower.startsWith('edge_')) return 'edge';
  if (lower.startsWith('capcut_')) return 'capcut';
  if (lower.startsWith('vnc_') || lower.startsWith('vn3_')) return 'vieneu';
  if (lower.startsWith('kcc_')) return 'kokoclone';
  if (lower.startsWith('ovc_') || lower.startsWith('omni_')) return 'omnivoice';
  if (lower.startsWith('xp|')) return 'external-piper';
  return 'kokoro';
}

function assertCorePreviewProviderHelpers(helpers = {}) {
  const names = [
    'synthesizeSegmentsWithVieneu',
    'synthesizeSegmentsWithKokoroOnnx',
    'synthesizeSegmentsWithKokoClone',
    'synthesizeSegmentsWithOmniVoice',
    'synthesizeSegmentsWithExternalPiper',
  ];
  for (const name of names) {
    if (typeof helpers[name] !== 'function') {
      throw new Error(`Voice preview requires ${name}.`);
    }
  }
  return true;
}

function createTtsRouter(helpers) {
  assertCorePreviewProviderHelpers(helpers);
  const router = express.Router();
  const withCloneLock = (key, res, action) => withKeyedLock(key, action, {
    filePath: helpers.cloneLockDirectory ? path.join(helpers.cloneLockDirectory, key) : undefined,
  }).catch(error => {
    if (!res.headersSent) res.status(error.statusCode || 503).json({ code: error.code || 'CLONE_STORAGE_BUSY', error: error.message });
  });
  // Mounted at /api: do not intercept unrelated controls such as queue cleanup,
  // speech cancellation or model installation when license IPC is unavailable.
  // All voice mutations remain protected within their own namespaces.
  router.use(['/voice-preview', '/piper-external', '/kokoclone', '/omnivoice', '/vieneu'], async (req, res, next) => {
    try {
      if (req.method !== 'GET' && helpers.requireTrustedVoiceRequest) await helpers.requireTrustedVoiceRequest(req);
      next();
    } catch (error) {
      res.status(error.statusCode || 403).json({ code: error.code || 'FEATURE_LOCKED', error: error.message });
    }
  });
  const {
    listExternalPiperVoices,
    EXTERNAL_PIPER_MODEL_DIR,
    warmExternalPiperVoice,
    listVieneuCustomVoices,
    serializeVieneuVoiceForClient,
    normalizeKokoCloneLangCode,
    listKokoCloneCustomVoices,
    serializeKokoCloneVoiceForClient,
    kokocloneCloneUpload,
    listOmniVoiceCustomVoices,
    serializeOmniVoiceForClient,
    omnivoiceCloneUpload,
    normalizeOmniVoiceLangCode,
    normalizeOmniVoiceRefText,
    writeOmniVoiceCustomVoiceRegistry,
    isOmniVoiceVoice,
    normalizeAccessPlanId,
    isAccessPlanAtLeast,
    getRequestAccessPlanId,
    getOmniVoiceClonePerLanguageLimit,
    getCustomVoiceLimit,
    OMNIVOICE_CUSTOM_VOICE_DIR,
    OMNIVOICE_REFERENCE_AUDIO_CACHE_DIR,
    vieneuCloneUpload,
    sanitizeUtf8SafeText,
    normalizeKokoCloneRefText,
    slugifyLabel,
    KOKOCLONE_CUSTOM_VOICE_DIR,
    convertAudioSampleToCloneWav,
    convertAudioSampleToOmniVoicePromptWav,
    buildOmniVoicePromptRefText,
    writeKokoCloneCustomVoiceRegistry,
    isKokoCloneVoice,
    writeVieneuCustomVoiceRegistry,
    listAvailableVieneuPresetVoices,
    buildVieneuVoiceConfig,
    normalizeVieneuVoiceId,
    getVieneuCustomVoice,
    getVieneuPresetPreviewSamplePath,
    buildFileUrl,
    VIENEU_PREVIEW_SAMPLE_TEXT,
    PREVIEW_CACHE_VERSION,
    CACHE_DIR,
    synthesizeSegmentsWithVieneu,
    synthesizeSegmentsWithKokoroOnnx,
    synthesizeSegmentsWithKokoClone,
    synthesizeSegmentsWithOmniVoice,
    synthesizeSegmentsWithExternalPiper,
    synthesizeSegmentsWithEdge,
    synthesizeSegmentsWithCapcut,
    normalizeVieneuCloneRawRefText,
    ensureVieneuPythonReady,
    ensureKokoClonePythonReady,
    probeDurationSeconds,
    normalizeVieneuCloneRefText,
    runVieneuBridgeOnce,
    buildVieneuCloneRefTextForSample,
    buildVieneuCloneConditioningRefText,
    normalizeVieneuV3SpeakerEmbedding,
    normalizeVieneuV3RefCodes,
    VIENEU_CLONE_REFERENCE_AUDIO_MAX_SEC,
    VIENEU_CUSTOM_VOICE_DIR
  } = helpers;
  const VIENEU_PREVIEW_MIN_BYTES = 64 * 1024;
  const VIENEU_PREVIEW_MIN_DURATION_SECONDS = 1.15;
  const VIENEU_PRESET_PREVIEW_TIMEOUT_MS = Math.max(
    60 * 1000,
    Number(process.env.AI_VIDEO_STUDIO_VIENEU_PRESET_PREVIEW_TIMEOUT_MS) ||
      180 * 1000,
  );

  router.post('/voice-preview', async (req, res) => {
    try {
      const voiceId = String(req.body?.voiceId || '').trim();
      const langCode = String(req.body?.langCode || 'a').trim().toLowerCase();
      const requestedText = String(req.body?.text || '').trim().slice(0, 600);
      const text = helpers.resolveAuditionText ? await helpers.resolveAuditionText(req, requestedText, langCode) : requestedText;
      if (!voiceId || !text) {
        return res.status(400).json({ error: 'Voice and preview text are required.' });
      }
      else if (/^(omni_|ovc_)/i.test(voiceId) && !['plus', 'pro', 'lifetime'].includes(getRequestAccessPlanId?.(req))) {
        return res.status(403).json({ code: 'FEATURE_LOCKED', error: 'Omni VIP requires an active Plus, Pro or Lifetime license.' });
      }
      const provider = resolveCorePreviewProvider(voiceId, langCode);
      const outputPath = path.join(
        CACHE_DIR,
        `voice_preview_${crypto.createHash('sha1').update(`${provider}:${voiceId}:${langCode}:${text}`).digest('hex')}.wav`,
      );
      if (!hasUsableLocalFile(outputPath, 256)) {
        const segments = [{ text, sourceText: text, voice: voiceId, langCode, speed: 1, outputPath }];
        const synthesize = {
          vieneu: synthesizeSegmentsWithVieneu,
          kokoro: synthesizeSegmentsWithKokoroOnnx,
          kokoclone: synthesizeSegmentsWithKokoClone,
          omnivoice: synthesizeSegmentsWithOmniVoice,
          'external-piper': synthesizeSegmentsWithExternalPiper,
          edge: synthesizeSegmentsWithEdge,
          capcut: synthesizeSegmentsWithCapcut,
        }[provider];
        if (typeof synthesize !== 'function') {
          throw new Error(`Voice preview provider ${provider} is unavailable.`);
        }
        await synthesize(segments, null, { batchSize: 1 });
      }
      if (!hasUsableLocalFile(outputPath, 256)) {
        throw new Error('Voice preview did not create usable audio.');
      }
      res.json({ ok: true, provider, audioUrl: buildFileUrl(outputPath) });
    } catch (error) {
      res.status(error.statusCode || 500).json({
        error: error.message || 'Unable to create voice preview.',
      });
    }
  });

  function assertLegacyCustomVoiceQuota(planId, vieneuCount, kokoCloneCount) {
    if (!isAccessPlanAtLeast(planId, 'basic')) {
      const error = new Error('Voice cloning is not available for this plan.');
      error.statusCode = 403;
      throw error;
    }
    const cloneLimit = getCustomVoiceLimit(planId);
    const currentCount = Number(vieneuCount || 0) + Number(kokoCloneCount || 0);
    if (Number.isFinite(cloneLimit) && currentCount >= cloneLimit) {
      const error = new Error(
        `Your current plan supports up to ${cloneLimit} cloned voice${cloneLimit === 1 ? '' : 's'}. Upgrade to PRO for unlimited voice cloning.`,
      );
      error.statusCode = 403;
      throw error;
    }
  }

  function hasUsableLocalFile(filePath, minBytes = 1024) {
    try {
      return fs.existsSync(filePath) && fs.statSync(filePath).size >= minBytes;
    } catch {
      return false;
    }
  }

  function formatVieneuCloneError(error) {
    const message = String(error?.message || error || '').trim();
    if (/locate the file on the Hub|local cache|MOSS|audio tokenizer|ONNX/i.test(message)) {
      return 'VieNeu 3.3 voice clone needs the bundled Turbo model and MOSS audio tokenizer. Restore the offline voice runtime, then try cloning again.';
    }
    return message || 'Unable to clone the Vietnamese voice.';
  }

  function buildVieneuPreviewCachePath(voiceId, previewText) {
    const resolvedVoiceConfig = buildVieneuVoiceConfig(voiceId);
    const previewHash = crypto
      .createHash('sha1')
      .update(
        JSON.stringify({
          voiceId,
          previewText,
          cacheKey: resolvedVoiceConfig?.cacheKey || voiceId,
          previewVersion: PREVIEW_CACHE_VERSION,
        }),
      )
      .digest('hex');
    return {
      previewOutputPath: path.join(CACHE_DIR, `vieneu_preview_${previewHash}.wav`),
      previewMetaPath: path.join(CACHE_DIR, `vieneu_preview_${previewHash}.json`),
      resolvedVoiceConfig,
    };
  }

  function readVieneuPreviewCacheMeta(previewMetaPath) {
    try {
      const rawMeta = fs.readFileSync(previewMetaPath, 'utf8').replace(/^\uFEFF/, '');
      const parsed = JSON.parse(rawMeta);
      return parsed && typeof parsed === 'object' ? parsed : null;
    } catch {
      return null;
    }
  }

  function writeVieneuPreviewCacheMeta(previewMetaPath, meta) {
    try {
      fs.writeFileSync(previewMetaPath, JSON.stringify(meta, null, 2));
    } catch {}
  }

  function deleteVieneuPreviewCacheFiles(previewOutputPath, previewMetaPath) {
    for (const filePath of [previewOutputPath, previewMetaPath]) {
      try {
        if (filePath && fs.existsSync(filePath)) fs.unlinkSync(filePath);
      } catch {}
    }
  }

  async function isTrustedVieneuPreviewFile(filePath) {
    if (!hasUsableLocalFile(filePath, VIENEU_PREVIEW_MIN_BYTES)) return false;
    const durationSeconds = Number(await probeDurationSeconds(filePath).catch(() => 0)) || 0;
    return durationSeconds >= VIENEU_PREVIEW_MIN_DURATION_SECONDS;
  }

  async function ensureVieneuPresetPreviewAudio(voiceId, previewText, options = {}) {
    const {
      previewOutputPath,
      previewMetaPath,
    } = buildVieneuPreviewCachePath(voiceId, previewText);
    const force = Boolean(options.force);
    if (!force && await isTrustedVieneuPreviewFile(previewOutputPath)) {
      const cachedMeta = readVieneuPreviewCacheMeta(previewMetaPath);
      return {
        previewOutputPath,
        source: cachedMeta?.source ? `cache:${cachedMeta.source}` : 'cache',
        usedVoiceId: cachedMeta?.usedVoiceId || voiceId,
        fallbackFrom: cachedMeta?.fallbackFrom || '',
      };
    }

    const candidateVoiceIds = [voiceId].filter(
      (candidateVoiceId, index, list) =>
        candidateVoiceId && list.indexOf(candidateVoiceId) === index,
    );
    let lastError = null;

    for (const candidateVoiceId of candidateVoiceIds) {
      deleteVieneuPreviewCacheFiles(previewOutputPath, previewMetaPath);

      try {
        await synthesizeSegmentsWithVieneu([
          {
            text: previewText,
            voice: candidateVoiceId,
            speed: 1,
            outputPath: previewOutputPath,
          },
        ], null, {
          timeoutMs: VIENEU_PRESET_PREVIEW_TIMEOUT_MS,
          preview: true,
        });

        if (!await isTrustedVieneuPreviewFile(previewOutputPath)) {
          deleteVieneuPreviewCacheFiles(previewOutputPath, previewMetaPath);
          throw new Error(
            `Vietnamese preview for "${candidateVoiceId}" was generated too short or silent.`,
          );
        }

        const source = 'generated';
        const fallbackFrom = '';
        writeVieneuPreviewCacheMeta(previewMetaPath, {
          requestedVoiceId: voiceId,
          usedVoiceId: candidateVoiceId,
          fallbackFrom,
          source,
          createdAt: new Date().toISOString(),
        });
        return {
          previewOutputPath,
          source,
          usedVoiceId: candidateVoiceId,
          fallbackFrom,
        };
      } catch (error) {
        lastError = error;
      }
    }

    throw lastError || new Error(`Vietnamese preview for "${voiceId}" could not be generated.`);
  }

  router.get('/piper-external/voices', (req, res) => {
    res.json({
      voices: listExternalPiperVoices().map((voice) => ({
        id: voice.id,
        label: voice.label,
        langCode: voice.langCode,
        locale: voice.locale,
        modelKey: voice.modelKey,
        modelLabel: voice.modelLabel,
        speakerKey: voice.speakerKey,
        speakerLabel: voice.speakerLabel,
        provider: voice.provider,
      })),
      modelDirectory: EXTERNAL_PIPER_MODEL_DIR,
    });
  });

  router.post('/piper-external/warm', async (req, res) => {
    try {
      const voiceId = normalizeVieneuVoiceId
        ? normalizeVieneuVoiceId(req.body?.voiceId)
        : String(req.body?.voiceId || '').trim();
      if (!voiceId) {
        return res.status(400).json({ error: 'voiceId is required.' });
      }
      const result = await warmExternalPiperVoice(voiceId);
      res.json({
        ok: true,
        voiceId,
        sampleRate: result?.sampleRate || null,
      });
    } catch (error) {
      res.status(500).json({ error: error.message || 'Unable to warm the voice engine.' });
    }
  });

  router.get('/vieneu/custom-voices', (req, res) => {
    res.json({
      voices: listVieneuCustomVoices().map(serializeVieneuVoiceForClient),
    });
  });

  router.get('/kokoclone/custom-voices', (req, res) => {
    const langCode = normalizeKokoCloneLangCode(req.query?.langCode || '');
    const voices = listKokoCloneCustomVoices()
      .filter((voice) => !langCode || voice.langCode === langCode)
      .map(serializeKokoCloneVoiceForClient);
    res.json({ voices });
  });

  router.get('/omnivoice/custom-voices', (req, res) => {
    const langCode = normalizeOmniVoiceLangCode(req.query?.langCode || '');
    const voices = listOmniVoiceCustomVoices()
      .filter((voice) => !langCode || voice.langCode === langCode)
      .map(serializeOmniVoiceForClient);
    res.json({ voices });
  });

  router.post(
    '/kokoclone/custom-voices',
    kokocloneCloneUpload.single('sampleFile'),
    async (req, res) => withCloneLock('legacy-clone-registry', res, async () => {
      let uploadedPath = req.file?.path || '';
      let normalizedPath = '';
      try {
        const planId = helpers.getCurrentVoicePlan ? await helpers.getCurrentVoicePlan(req) : getRequestAccessPlanId(req);
        const label = sanitizeUtf8SafeText(String(req.body?.label || '')).trim();
        const langCode = normalizeKokoCloneLangCode(req.body?.langCode || '');
        const sampleTranscript = normalizeKokoCloneRefText(req.body?.refText || '');

        if (!label) {
          throw new Error('Voice name is required.');
        }
        if (!langCode) {
          throw new Error('Selected voice clone language is not supported.');
        }
        if (!sampleTranscript) {
          throw new Error('Sample transcript is required.');
        }
        if (!uploadedPath || !fs.existsSync(uploadedPath)) {
          throw new Error('A reference audio sample is required.');
        }

        const existingVoices = listKokoCloneCustomVoices();
        assertLegacyCustomVoiceQuota(
          planId,
          listVieneuCustomVoices().length,
          existingVoices.length,
        );
        await ensureKokoClonePythonReady?.();
        const slugBase = slugifyLabel(`${langCode}_${label}`);
        let suffix = 1;
        let voiceId = `kcc_${slugBase}`;
        while (existingVoices.some((voice) => voice.id === voiceId)) {
          suffix += 1;
          voiceId = `kcc_${slugBase}_${suffix}`;
        }

        normalizedPath = path.join(KOKOCLONE_CUSTOM_VOICE_DIR, `${voiceId}.wav`);
        await convertAudioSampleToCloneWav(uploadedPath, normalizedPath);
        if (fs.existsSync(uploadedPath)) fs.unlinkSync(uploadedPath);
        uploadedPath = '';

        const entry = {
          id: voiceId,
          label,
          langCode,
          sampleTranscript,
          samplePath: normalizedPath,
          createdAt: new Date().toISOString(),
        };

        const commitPlan = helpers.getCurrentVoicePlan ? await helpers.getCurrentVoicePlan(req) : getRequestAccessPlanId(req);
        assertLegacyCustomVoiceQuota(commitPlan, listVieneuCustomVoices().length, listKokoCloneCustomVoices().length);
        writeKokoCloneCustomVoiceRegistry([...listKokoCloneCustomVoices(), entry]);
        res.json({
          ok: true,
          voice: serializeKokoCloneVoiceForClient(entry),
          voices: listKokoCloneCustomVoices().map(serializeKokoCloneVoiceForClient),
        });
      } catch (error) {
        try {
          if (uploadedPath && fs.existsSync(uploadedPath)) fs.unlinkSync(uploadedPath);
        } catch {}
        try {
          if (normalizedPath && fs.existsSync(normalizedPath)) fs.unlinkSync(normalizedPath);
        } catch {}
        res
          .status(error.statusCode || 400)
          .json({ error: error.message || 'Unable to create the voice clone.' });
      }
    }),
  );

  router.post(
    '/omnivoice/custom-voices',
    omnivoiceCloneUpload.single('sampleFile'),
    async (req, res) => withCloneLock('omnivoice-clone-registry', res, async () => {
      let uploadedPath = req.file?.path || '';
      let normalizedPath = '';
      try {
        const planId = helpers.getCurrentVoicePlan ? await helpers.getCurrentVoicePlan(req) : getRequestAccessPlanId(req);
        const label = sanitizeUtf8SafeText(String(req.body?.label || '')).trim();
        const langCode = normalizeOmniVoiceLangCode(req.body?.langCode || '');
        const sampleTranscript = normalizeOmniVoiceRefText(req.body?.refText || '');

        if (!isAccessPlanAtLeast(planId, 'plus')) {
          const error = new Error('Omni VIP is available from the Plus plan.');
          error.statusCode = 403;
          throw error;
        }
        if (!label) {
          throw new Error('Voice name is required.');
        }
        if (!langCode) {
          throw new Error('Omni VIP does not support this language code yet.');
        }
        if (!sampleTranscript) {
          throw new Error('Sample transcript is required.');
        }
        if (!uploadedPath || !fs.existsSync(uploadedPath)) {
          throw new Error('A reference audio sample is required.');
        }

        const existingVoices = listOmniVoiceCustomVoices();
        const sameLanguageVoiceCount = existingVoices.filter(
          (voice) =>
            String(voice?.langCode || '').trim().toLowerCase() === langCode,
        ).length;
        const cloneLimit = getOmniVoiceClonePerLanguageLimit(planId);
        if (
          Number.isFinite(cloneLimit) &&
          sameLanguageVoiceCount >= cloneLimit
        ) {
          const error = new Error(
            `Plus supports up to ${cloneLimit} Omni VIP cloned voices per language. Upgrade to PRO for full Omni access.`,
          );
          error.statusCode = 403;
          throw error;
        }
        const slugBase = slugifyLabel(`${langCode}_${label}`);
        let suffix = 1;
        let voiceId = `ovc_${slugBase}`;
        while (existingVoices.some((voice) => voice.id === voiceId)) {
          suffix += 1;
          voiceId = `ovc_${slugBase}_${suffix}`;
        }

        const sourceDurationSeconds =
          Number(await probeDurationSeconds(uploadedPath).catch(() => 0)) || 0;
        const promptTranscript =
          (await buildOmniVoicePromptRefText(
            sampleTranscript,
            langCode,
            uploadedPath,
          )) || sampleTranscript;

        normalizedPath = path.join(OMNIVOICE_CUSTOM_VOICE_DIR, `${voiceId}.wav`);
        await convertAudioSampleToOmniVoicePromptWav(uploadedPath, normalizedPath);
        if (fs.existsSync(uploadedPath)) fs.unlinkSync(uploadedPath);
        uploadedPath = '';

        const entry = {
          id: voiceId,
          label,
          langCode,
          sampleTranscript: promptTranscript,
          samplePath: normalizedPath,
          sourceDurationSeconds,
          createdAt: new Date().toISOString(),
        };

        const commitPlan = helpers.getCurrentVoicePlan ? await helpers.getCurrentVoicePlan(req) : getRequestAccessPlanId(req);
        if (!isAccessPlanAtLeast(commitPlan, 'plus') || listOmniVoiceCustomVoices().filter(voice => voice.langCode === langCode).length >= getOmniVoiceClonePerLanguageLimit(commitPlan)) {
          throw Object.assign(new Error('The current license no longer has an available Omni clone slot.'), { statusCode: 403 });
        }
        writeOmniVoiceCustomVoiceRegistry([...listOmniVoiceCustomVoices(), entry]);
        res.json({
          ok: true,
          voice: serializeOmniVoiceForClient(entry),
          voices: listOmniVoiceCustomVoices().map(serializeOmniVoiceForClient),
        });
      } catch (error) {
        try {
          if (uploadedPath && fs.existsSync(uploadedPath)) fs.unlinkSync(uploadedPath);
        } catch {}
        try {
          if (normalizedPath && fs.existsSync(normalizedPath)) fs.unlinkSync(normalizedPath);
        } catch {}
        res.status(error.statusCode || 400).json({
          error: error.message || 'Unable to create the Omni VIP voice.',
        });
      }
    }),
  );

  router.delete('/kokoclone/custom-voices/:voiceId', async (req, res) => withCloneLock('legacy-clone-registry', res, async () => {
    try {
      const voiceId = String(req.params.voiceId || '').trim();
      if (!isKokoCloneVoice(voiceId)) {
        return res.status(400).json({ error: 'Invalid custom voice id.' });
      }

      const existingVoices = listKokoCloneCustomVoices();
      const targetVoice = existingVoices.find((voice) => voice.id === voiceId);
      if (!targetVoice) {
        return res.status(404).json({ error: 'Custom voice was not found.' });
      }

      try {
        if (targetVoice.samplePath && fs.existsSync(targetVoice.samplePath)) {
          fs.unlinkSync(targetVoice.samplePath);
        }
      } catch {}

      const nextVoices = existingVoices.filter((voice) => voice.id !== voiceId);
      writeKokoCloneCustomVoiceRegistry(nextVoices);

      res.json({
        ok: true,
        removedVoiceId: voiceId,
        voices: nextVoices.map(serializeKokoCloneVoiceForClient),
      });
    } catch (error) {
      res
        .status(500)
        .json({ error: error.message || 'Unable to delete the custom voice.' });
    }
  }));

  router.delete('/omnivoice/custom-voices/:voiceId', async (req, res) => withCloneLock('omnivoice-clone-registry', res, async () => {
    try {
      const voiceId = String(req.params.voiceId || '').trim();
      if (!isOmniVoiceVoice(voiceId) || !voiceId.toLowerCase().startsWith('ovc_')) {
        return res.status(400).json({ error: 'Invalid Omni VIP custom voice id.' });
      }

      const existingVoices = listOmniVoiceCustomVoices();
      const targetVoice = existingVoices.find((voice) => voice.id === voiceId);
      if (!targetVoice) {
        return res.status(404).json({ error: 'Omni VIP custom voice was not found.' });
      }

      try {
        if (targetVoice.samplePath && fs.existsSync(targetVoice.samplePath)) {
          fs.unlinkSync(targetVoice.samplePath);
        }
        const promptCachePath = path.join(
          OMNIVOICE_REFERENCE_AUDIO_CACHE_DIR,
          `${voiceId}.prompt.wav`,
        );
        for (const cachePath of [promptCachePath, `${promptCachePath}.json`]) {
          if (fs.existsSync(cachePath)) {
            fs.unlinkSync(cachePath);
          }
        }
      } catch {}

      const nextVoices = existingVoices.filter((voice) => voice.id !== voiceId);
      writeOmniVoiceCustomVoiceRegistry(nextVoices);

      res.json({
        ok: true,
        removedVoiceId: voiceId,
        voices: nextVoices.map(serializeOmniVoiceForClient),
      });
    } catch (error) {
      res
        .status(500)
        .json({ error: error.message || 'Unable to delete the Omni VIP custom voice.' });
    }
  }));

  router.get('/vieneu/preset-voices', (req, res) => {
    res.json({
      voices: listAvailableVieneuPresetVoices().map((voice) => {
        const resolvedVoiceConfig = buildVieneuVoiceConfig(voice.id);
        return {
          id: voice.id,
          label: voice.label,
          voiceName: voice.voiceName,
          description: voice.description || voice.label,
          requiredPlanId: voice.requiredPlanId || '',
          modelProfileKey:
            resolvedVoiceConfig.modelProfileKey || voice.modelProfileKey || 'classic',
          healthStatus: resolvedVoiceConfig.healthStatus || 'healthy',
          healthFallbackVoiceId: resolvedVoiceConfig.healthFallbackVoiceId || '',
          healthReason: resolvedVoiceConfig.healthReason || '',
        };
      }),
    });
  });

  router.post('/vieneu/preview-voice', async (req, res) => {
    try {
      const voiceId = String(req.body?.voiceId || '').trim();
      if (!voiceId) {
        return res.status(400).json({ error: 'voiceId is required.' });
      }
      if (helpers.authorizeVoiceUse && !listAvailableVieneuPresetVoices().some((voice) => voice.id === voiceId)) {
        await helpers.authorizeVoiceUse(req, { voiceId });
      }

      const voiceExists =
        listAvailableVieneuPresetVoices().some((voice) => voice.id === voiceId) ||
        Boolean(getVieneuCustomVoice(voiceId));
      if (!voiceExists) {
        return res.status(404).json({ error: 'Vietnamese voice was not found.' });
      }

      const customVoice = getVieneuCustomVoice(voiceId);
      if (customVoice) {
        if (hasUsableLocalFile(customVoice.samplePath, 1024)) {
          return res.json({
            ok: true,
            audioUrl: buildFileUrl(customVoice.samplePath),
            source: 'sample',
          });
        }
        return res.status(409).json({
          error:
            'The original sample file for this cloned voice is missing. Please delete it and clone the voice again.',
        });
      }

      let previewText = sanitizeUtf8SafeText(
        req.body?.text ||
          VIENEU_PREVIEW_SAMPLE_TEXT,
      ).trim();
      if (helpers.resolveAuditionText) previewText = await helpers.resolveAuditionText(req, previewText, 'v');
      if (!previewText) {
        return res.status(400).json({ error: 'Preview text is required.' });
      }

      const presetSamplePath =
        typeof getVieneuPresetPreviewSamplePath === 'function'
          ? getVieneuPresetPreviewSamplePath(voiceId)
          : '';
      if (!Boolean(req.body?.force) && hasUsableLocalFile(presetSamplePath, 1024)) {
        return res.json({
          ok: true,
          audioUrl: buildFileUrl(presetSamplePath),
          source: 'preset-sample',
          usedVoiceId: voiceId,
          fallbackFrom: '',
        });
      }

      const { previewOutputPath, source, usedVoiceId, fallbackFrom } = await ensureVieneuPresetPreviewAudio(
        voiceId,
        previewText,
        { force: Boolean(req.body?.force) },
      );

      res.json({
        ok: true,
        audioUrl: buildFileUrl(previewOutputPath),
        source,
        usedVoiceId,
        fallbackFrom,
      });
    } catch (error) {
      res.status(error.statusCode || 500).json({
        error: error.message || 'Unable to preview the Vietnamese voice.',
      });
    }
  });

  router.post('/vieneu/preview-voices/precache', async (req, res) => {
    try {
      let previewText = sanitizeUtf8SafeText(
        req.body?.text ||
          VIENEU_PREVIEW_SAMPLE_TEXT,
      ).trim();
      if (helpers.resolveAuditionText) previewText = await helpers.resolveAuditionText(req, previewText, 'v');
      if (!previewText) {
        return res.status(400).json({ error: 'Preview text is required.' });
      }

      const requestedVoiceIds = Array.isArray(req.body?.voiceIds)
        ? req.body.voiceIds.map((voiceId) => String(voiceId || '').trim()).filter(Boolean)
        : [];
      const availableVoices = listAvailableVieneuPresetVoices();
      const availableVoiceIds = new Set(availableVoices.map((voice) => voice.id));
      const targetVoiceIds = (requestedVoiceIds.length > 0
        ? requestedVoiceIds
        : availableVoices.map((voice) => voice.id)
      ).filter((voiceId, index, items) =>
        availableVoiceIds.has(voiceId) && items.indexOf(voiceId) === index,
      );

      const results = [];
      for (const voiceId of targetVoiceIds) {
        try {
          if (helpers.authorizeVoiceUse) await helpers.authorizeVoiceUse(req, { voiceId });
          const presetSamplePath =
            typeof getVieneuPresetPreviewSamplePath === 'function'
              ? getVieneuPresetPreviewSamplePath(voiceId)
              : '';
          if (!Boolean(req.body?.force) && hasUsableLocalFile(presetSamplePath, 1024)) {
            results.push({
              voiceId,
              ok: true,
              source: 'preset-sample',
              usedVoiceId: voiceId,
              fallbackFrom: '',
              audioUrl: buildFileUrl(presetSamplePath),
            });
            continue;
          }
          const { previewOutputPath, source, usedVoiceId, fallbackFrom } = await ensureVieneuPresetPreviewAudio(
            voiceId,
            previewText,
            { force: Boolean(req.body?.force) },
          );
          results.push({
            voiceId,
            ok: true,
            source,
            usedVoiceId,
            fallbackFrom,
            audioUrl: buildFileUrl(previewOutputPath),
          });
        } catch (error) {
          results.push({
            voiceId,
            ok: false,
            error: error.message || 'Unable to cache this preview.',
          });
        }
      }

      const readyCount = results.filter((item) => item.ok).length;
      res.json({
        ok: true,
        readyCount,
        totalCount: targetVoiceIds.length,
        results,
      });
    } catch (error) {
      res.status(500).json({
        error: error.message || 'Unable to pre-cache Vietnamese voice previews.',
      });
    }
  });

  router.post(
    '/vieneu/custom-voices',
    vieneuCloneUpload.single('sampleFile'),
    async (req, res) => withCloneLock('legacy-clone-registry', res, async () => {
      let uploadedPath = req.file?.path || '';
      let normalizedPath = '';
      try {
        const planId = helpers.getCurrentVoicePlan ? await helpers.getCurrentVoicePlan(req) : getRequestAccessPlanId(req);
        const label = String(req.body?.label || '').trim();
        const rawRefText = normalizeVieneuCloneRawRefText(req.body?.refText || '');

        if (!label) {
          throw new Error('Voice name is required.');
        }
        if (!rawRefText) {
          throw new Error('Sample transcript is required.');
        }
        if (!uploadedPath || !fs.existsSync(uploadedPath)) {
          throw new Error('A Vietnamese sample audio file is required.');
        }

        const existingVoices = listVieneuCustomVoices();
        assertLegacyCustomVoiceQuota(
          planId,
          existingVoices.length,
          listKokoCloneCustomVoices().length,
        );
        await ensureVieneuPythonReady();
        const slugBase = slugifyLabel(label);
        let suffix = 1;
        let voiceId = `vnc_${slugBase}`;
        while (existingVoices.some((voice) => voice.id === voiceId)) {
          suffix += 1;
          voiceId = `vnc_${slugBase}_${suffix}`;
        }

        normalizedPath = path.join(VIENEU_CUSTOM_VOICE_DIR, `${voiceId}.wav`);
        await convertAudioSampleToCloneWav(uploadedPath, normalizedPath);
        const sampleDurationSec = await probeDurationSeconds(normalizedPath);
        const requestedRefText = normalizeVieneuCloneRefText(rawRefText);
        if (!requestedRefText) {
          throw new Error('Sample transcript is required.');
        }
        if (fs.existsSync(uploadedPath)) fs.unlinkSync(uploadedPath);
        uploadedPath = '';

        const cloneResult = await runVieneuBridgeOnce({
          action: 'clone_voice',
          samplePath: normalizedPath,
          maxReferenceSeconds: VIENEU_CLONE_REFERENCE_AUDIO_MAX_SEC,
        });
        const alignedRefText = buildVieneuCloneRefTextForSample(
          requestedRefText,
          cloneResult?.referenceSeconds || sampleDurationSec,
        );
        if (!alignedRefText) {
          throw new Error('Sample transcript is required.');
        }

        const entry = {
          id: voiceId,
          label,
          sampleTranscript: alignedRefText,
          speakerEmbedding: normalizeVieneuV3SpeakerEmbedding(
            cloneResult.speakerEmbedding,
          ),
          refCodesV3: normalizeVieneuV3RefCodes(cloneResult.refCodesV3),
          samplePath: normalizedPath,
          createdAt: new Date().toISOString(),
        };

        if (entry.speakerEmbedding.length !== 192 || !entry.refCodesV3.length) {
          throw new Error('Voice cloning returned an empty voice profile.');
        }

        const commitPlan = helpers.getCurrentVoicePlan ? await helpers.getCurrentVoicePlan(req) : getRequestAccessPlanId(req);
        assertLegacyCustomVoiceQuota(commitPlan, listVieneuCustomVoices().length, listKokoCloneCustomVoices().length);
        writeVieneuCustomVoiceRegistry([...listVieneuCustomVoices(), entry]);
        res.json({
          ok: true,
          voice: serializeVieneuVoiceForClient(entry),
          voices: listVieneuCustomVoices().map(serializeVieneuVoiceForClient),
        });
      } catch (error) {
        try {
          if (uploadedPath && fs.existsSync(uploadedPath)) fs.unlinkSync(uploadedPath);
        } catch {}
        try {
          if (normalizedPath && fs.existsSync(normalizedPath)) fs.unlinkSync(normalizedPath);
        } catch {}
        res
          .status(error.statusCode || 400)
          .json({ error: formatVieneuCloneError(error) });
      }
    }),
  );

  router.delete('/vieneu/custom-voices/:voiceId', async (req, res) => withCloneLock('legacy-clone-registry', res, async () => {
    try {
      const voiceId = String(req.params.voiceId || '').trim();
      if (!voiceId.startsWith('vnc_')) {
        return res.status(400).json({ error: 'Invalid custom Vietnamese voice id.' });
      }

      const existingVoices = listVieneuCustomVoices();
      const targetVoice = existingVoices.find((voice) => voice.id === voiceId);
      if (!targetVoice) {
        return res.status(404).json({ error: 'Vietnamese custom voice was not found.' });
      }

      try {
        if (targetVoice.samplePath && fs.existsSync(targetVoice.samplePath)) {
          fs.unlinkSync(targetVoice.samplePath);
        }
      } catch {}

      const nextVoices = existingVoices.filter((voice) => voice.id !== voiceId);
      writeVieneuCustomVoiceRegistry(nextVoices);

      res.json({
        ok: true,
        removedVoiceId: voiceId,
        voices: nextVoices.map(serializeVieneuVoiceForClient),
      });
    } catch (error) {
      res
        .status(500)
        .json({ error: error.message || 'Unable to delete the custom Vietnamese voice.' });
    }
  }));

  return router;
}

module.exports = createTtsRouter;
module.exports._test = {
  assertCorePreviewProviderHelpers,
  resolveCorePreviewProvider,
};
