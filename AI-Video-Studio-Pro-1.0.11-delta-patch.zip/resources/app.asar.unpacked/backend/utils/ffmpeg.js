const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');
const path = require('path');

async function renderVideo({ bgVideo, audioSegments, subtitles, outputPath }) {
  return new Promise((resolve, reject) => {
    const tempDir = path.join(__dirname, '../uploads');

    // =========================
    // 1. Tạo SRT
    // =========================
    const formatTime = (seconds) => {
      const date = new Date(seconds * 1000);
      return date.toISOString().substr(11, 12).replace('.', ',');
    };

    let srtContent = '';
    subtitles.forEach((sub, i) => {
      srtContent += `${i + 1}\n`;
      srtContent += `${formatTime(sub.start)} --> ${formatTime(sub.end)}\n`;
      srtContent += `${sub.text}\n\n`;
    });

    const srtPath = path.join(tempDir, `sub_${Date.now()}.srt`);
    fs.writeFileSync(srtPath, srtContent);

    // =========================
    // 2. Merge audio
    // =========================
    const listPath = path.join(tempDir, `list_${Date.now()}.txt`);
    const listContent = audioSegments.map((a) => `file '${a.path}'`).join('\n');
    fs.writeFileSync(listPath, listContent);

    const mergedAudio = path.join(tempDir, `merged_${Date.now()}.mp3`);

    ffmpeg()
      .input(listPath)
      .inputOptions(['-f concat', '-safe 0'])
      .outputOptions(['-c copy'])
      .save(mergedAudio)
      .on('end', () => {
        // =========================
        // 3. Render video
        // =========================
        let command = ffmpeg();

        if (bgVideo) {
          command.input(bgVideo);
        } else {
          command.input('color=c=black:s=1080x1920:d=30').inputFormat('lavfi');
        }

        command
          .input(mergedAudio)
          .outputOptions([
            `-vf subtitles=${srtPath}:force_style='FontSize=36,PrimaryColour=&H00FFFF,OutlineColour=&H000000,BorderStyle=3'`,
            '-c:v libx264',
            '-c:a aac',
            '-shortest',
          ])
          .on('end', () => resolve(outputPath))
          .on('error', reject)
          .save(outputPath);
      })
      .on('error', reject);
  });
}

module.exports = { renderVideo };
