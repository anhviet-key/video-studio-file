'use strict';
const fs = require('node:fs');
const path = require('node:path');
const directory = path.resolve(__dirname, '..', 'assets', 'vieneu');
const file = path.join(directory, 'presets-v3.json');
let cached;
const BASIC_VIENEU_PRESET_IDS = Object.freeze([
  'vn3_MinhDuc', 'vn3_PhamTuyen', 'vn3_ThaiSon', 'vn3_XuanVinh', 'vn3_ThanhBinh',
  'vn3_TrucLy', 'vn3_NgocLinh', 'vn3_DoanTrang', 'vn3_MaiAnh', 'vn3_ThucDoan',
  'vn3_MinhTriet', 'vn3_ThuyDung', 'vn3_QuangSon', 'vn3_NgocTran', 'vn3_MyDuyen',
  'vn3_QuynhAnh', 'vn3_DucTri', 'vn3_KimThanh', 'vn3_NgocHuyen', 'vn3_Adam',
]);
const PLUS_VIENEU_PRESET_IDS = Object.freeze([
  'vn3_AdamBua', 'vn3_ThienMinh', 'vn3_HaiDang', 'vn3_ThienTamDuc',
  'vn3_QuocTuan', 'vn3_NhatPhong', 'vn3_Vinh',
]);
function presetVoiceId(name) {
  const ascii = String(name).normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').replace(/Đ/g, 'D');
  return 'vn3_' + ascii.split(/[^a-zA-Z0-9]+/).filter(Boolean)
    .map(part => part[0].toUpperCase() + part.slice(1)).join('');
}
function readBundledVieneuPresets() {
  if (cached) return cached;
  const data = JSON.parse(fs.readFileSync(file, 'utf8'));
  const entries = Object.entries(data.presets || {});
  if (!entries.length) throw new Error('Bundled VieNeu preset profiles are missing.');
  const ids = new Set();
  cached = entries.map(([voiceName, profile]) => {
    const id = presetVoiceId(voiceName);
    if (ids.has(id) || profile.speaker_emb?.length !== 192 || !profile.speaker_emb.every(Number.isFinite)
      || !profile.codes?.length || !profile.codes.every(row => Array.isArray(row) && row.length === 16
        && row.every(code => Number.isInteger(code) && code >= 0 && code < 1024))) {
      throw new Error('Invalid bundled VieNeu preset profile.');
    }
    ids.add(id);
    const requiredPlanId = BASIC_VIENEU_PRESET_IDS.includes(id)
      ? ''
      : PLUS_VIENEU_PRESET_IDS.includes(id)
        ? 'plus'
        : 'pro';
    return { id, voiceName, label: voiceName,
      description: profile.description || voiceName, modelProfileKey: 'v3',
      requiredPlanId };
  });
  return cached;
}
module.exports = { readBundledVieneuPresets, presetVoiceId, bundledPresetPath: file, BASIC_VIENEU_PRESET_IDS, PLUS_VIENEU_PRESET_IDS };
