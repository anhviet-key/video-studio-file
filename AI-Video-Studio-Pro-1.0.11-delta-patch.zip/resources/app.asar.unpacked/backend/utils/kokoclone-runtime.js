// Matched CPU wheels are the portable baseline; never independently upgrade
// torch and torchaudio. GPU acceleration remains an explicit runtime choice.
const KOKOCLONE_TORCH_VERSION = '2.8.0';
const KOKOCLONE_IMPORT_CHECK = [
  'import torch, torchaudio, soundfile, kokoro_onnx, kanade_tokenizer, misaki, vocos',
  'from misaki.en import G2P',
  'from misaki import espeak',
  'import spacy',
  'assert spacy.util.is_package("en_core_web_sm"), "Bundled English NLP model is missing"',
  'assert torch.__version__.split("+")[0] == torchaudio.__version__.split("+")[0], "Torch/Torchaudio versions do not match"',
  'assert torchaudio.functional.resample(torch.ones(240), 24000, 16000).numel() == 160',
  'assert G2P(trf=False)("Offline voice runtime check.")[0]',
  'print("kokoclone-runtime-pack-ok")',
].join('; ');

module.exports = { KOKOCLONE_TORCH_VERSION, KOKOCLONE_IMPORT_CHECK };
