const MIX = Object.freeze({ gain: 0.1, lead: 0.08, attack: 0.06, release: 0.22 });

function normalizeDubbingMix(settings = {}) {
  const mode = ['duck', 'mix', 'replace'].includes(settings.dubbingMixMode) ? settings.dubbingMixMode : 'duck';
  const value = mode === 'mix' ? settings.dubbingOverlayGain : settings.dubbingOriginalGain;
  return {
    mode,
    gain: value !== null && value !== '' && Number.isFinite(Number(value))
      ? Math.max(0, Math.min(1, Number(value))) : mode === 'mix' ? 1 : MIX.gain,
  };
}

function normalizeDubbingIntervals(entries = []) {
  const ranges = entries.map(entry => ({ start: Number(entry?.startTime ?? entry?.start), end: Number(entry?.endTime ?? entry?.end) }))
    .filter(range => Number.isFinite(range.start) && Number.isFinite(range.end) && range.start >= 0 && range.end > range.start)
    .map(range => ({ start: Math.max(0, range.start - MIX.lead), end: range.end + MIX.lead }))
    .sort((a, b) => a.start - b.start);
  const merged = [];
  for (const range of ranges) {
    const previous = merged.at(-1);
    if (previous && range.start <= previous.end + MIX.attack + MIX.release) previous.end = Math.max(previous.end, range.end);
    else merged.push({ ...range });
  }
  return merged;
}

function duckingExpression(intervals, gain = MIX.gain) {
  if (!intervals.length) return '1';
  const number = value => Number(value).toFixed(6);
  const envelopes = intervals.map(range => {
    const attackStart = Math.max(0, range.start - MIX.attack);
    return `if(lt(t,${number(attackStart)}),1,if(lt(t,${number(range.start)}),1-(1-${number(gain)})*(t-${number(range.start - MIX.attack)})/${MIX.attack},if(lte(t,${number(range.end)}),${number(gain)},if(lt(t,${number(range.end + MIX.release)}),${number(gain)}+(1-${number(gain)})*(t-${number(range.end)})/${MIX.release},1))))`;
  });
  // Keep expressions shallow even for a whole episode with thousands of cues.
  while (envelopes.length > 1) {
    const next = [];
    for (let index = 0; index < envelopes.length; index += 2) next.push(index + 1 < envelopes.length ? `min(${envelopes[index]},${envelopes[index + 1]})` : envelopes[index]);
    envelopes.splice(0, envelopes.length, ...next);
  }
  return envelopes[0];
}

function buildDubbingAudioFilters({ enabled, sourceHasAudio, duration, intervals = [], settings = {} }) {
  const filters = [];
  const mix = normalizeDubbingMix(settings);
  const keepSource = sourceHasAudio && (!enabled || mix.mode !== 'replace');
  const length = Math.max(0.1, Number(duration) || 0.1).toFixed(6);
  const align = `aresample=48000:async=1:first_pts=0,apad,atrim=duration=${length},asetpts=PTS-STARTPTS`;
  if (keepSource) {
    const originalVolume = !enabled ? '' : mix.mode === 'mix'
      ? `,volume=${mix.gain.toFixed(6)}`
      : `,volume='${duckingExpression(normalizeDubbingIntervals(intervals), mix.gain)}':eval=frame`;
    filters.push(`[0:a:0]${align}${originalVolume}[original_audio]`);
  }
  if (enabled || !sourceHasAudio) filters.push(`[1:a:0]${align}[dub_audio]`);
  if (enabled && keepSource) {
    filters.push('[original_audio][dub_audio]amix=inputs=2:duration=first:dropout_transition=0:normalize=0[main_audio]');
    return { filters, label: 'main_audio' };
  }
  return { filters, label: keepSource ? 'original_audio' : 'dub_audio' };
}

module.exports = { MIX, normalizeDubbingMix, normalizeDubbingIntervals, duckingExpression, buildDubbingAudioFilters };
