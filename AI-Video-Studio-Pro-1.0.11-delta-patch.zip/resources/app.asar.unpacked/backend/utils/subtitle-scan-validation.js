function normalizeSubtitleSegments(entries = []) {
  return (Array.isArray(entries) ? entries : [])
    .map((entry) => ({
      startTime: Math.max(0, Number(entry?.startTime ?? entry?.start) || 0),
      endTime: Math.max(0, Number(entry?.endTime ?? entry?.end) || 0),
      text: String(entry?.text || '').trim(),
    }))
    .filter((entry) => entry.text && entry.endTime > entry.startTime);
}

function countSrtSegments(srtContent = '') {
  return String(srtContent || '')
    .trim()
    .split(/\r?\n\s*\r?\n/)
    .filter((block) => /\d{1,2}:\d{2}:\d{2}[,.]\d{3}\s*-->\s*\d{1,2}:\d{2}:\d{2}[,.]\d{3}/.test(block))
    .length;
}

function createEmptySubtitleScanError(message) {
  const error = new Error(message || 'No usable subtitle segments were detected.');
  error.code = 'NO_SUBTITLE_SEGMENTS';
  error.statusCode = 422;
  return error;
}

function requireWhisperSubtitleResult(result = {}, srtContent = '') {
  const transcriptText = String(result?.transcriptText || '').trim();
  const segmentsCount = Math.max(
    0,
    Number(result?.segmentCount || result?.segmentsCount) || 0,
    countSrtSegments(srtContent),
  );
  if (segmentsCount === 0 || (!transcriptText && !String(srtContent || '').trim())) {
    throw createEmptySubtitleScanError(
      'No spoken subtitle segments were detected. Check that the video has audible dialogue and try again.',
    );
  }
  return { segmentsCount, transcriptText };
}

function requireOcrSubtitleResult(result = {}) {
  const subtitles = normalizeSubtitleSegments(result?.subtitles);
  if (subtitles.length === 0) {
    throw createEmptySubtitleScanError(
      'No hardcoded subtitle text was detected in the selected OCR region. Adjust the subtitle region and try again.',
    );
  }
  return subtitles;
}

module.exports = {
  countSrtSegments,
  createEmptySubtitleScanError,
  normalizeSubtitleSegments,
  requireOcrSubtitleResult,
  requireWhisperSubtitleResult,
};
