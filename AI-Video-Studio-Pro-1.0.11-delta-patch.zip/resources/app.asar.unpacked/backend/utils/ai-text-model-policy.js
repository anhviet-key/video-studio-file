const policy = require('./ai-text-model-policy.json');

function isAiTextModel(provider, modelId) {
  const id = String(modelId || '').trim().toLowerCase();
  if (!id || new RegExp(policy.common, 'i').test(id)) return false;
  const rule = policy[provider] || (id.startsWith('gemini-') ? policy.gemini : '');
  return !rule || !new RegExp(rule, 'i').test(id);
}

function assertAiTextModel(provider, modelId) {
  if (!modelId || isAiTextModel(provider, modelId)) return;
  const error = new Error(`Model "${String(modelId).slice(0, 200)}" is not suitable for text scripts, translation or chat. Choose a text-generation model in Settings; TTS/audio/image/embedding models cannot be used here.`);
  error.code = 'AI_TEXT_MODEL_REQUIRED';
  throw error;
}

module.exports = { isAiTextModel, assertAiTextModel };
