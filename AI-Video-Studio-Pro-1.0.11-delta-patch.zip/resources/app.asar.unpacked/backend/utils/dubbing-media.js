const fs = require('fs');
const { spawn } = require('child_process');

// Own only this subprocess. Cancellation never terminates a shared AI worker.
function runMediaProcess(executable, args, { job, timeoutMs = 30000, onData, acceptNonZero = false } = {}) {
  return new Promise((resolve, reject) => {
    if (job?.cancelRequested) return reject(Object.assign(new Error('Media job cancelled.'), { code: 'JOB_CANCELLED' }));
    const child = spawn(executable, args, { windowsHide: true, stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '', failure;
    const fail = error => { failure ||= error; child.kill(); };
    const handle = {
      kind: 'dubbing-media',
      cancel: () => fail(Object.assign(new Error('Media job cancelled.'), { code: 'JOB_CANCELLED' })),
      kill: () => fail(Object.assign(new Error('Media job cancelled.'), { code: 'JOB_CANCELLED' })),
    };
    if (job) job.command = handle;
    const timer = setTimeout(() => fail(Object.assign(new Error('Media inspection timed out. Please retry or check the source file.'), { code: 'MEDIA_PROBE_TIMEOUT' })), timeoutMs);
    const cleanup = () => { clearTimeout(timer); if (job?.command === handle) job.command = null; };
    child.stdout.on('data', chunk => {
      try { if (onData) onData(chunk); else stdout = (stdout + chunk).slice(-65536); }
      catch (error) { fail(error); }
    });
    child.stderr.on('data', chunk => { stderr = (stderr + chunk).slice(-65536); });
    child.once('error', error => { cleanup(); reject(failure || error); });
    child.once('close', code => {
      cleanup();
      if (failure) return reject(failure);
      if (job?.cancelRequested) return reject(Object.assign(new Error('Media job cancelled.'), { code: 'JOB_CANCELLED' }));
      if (code && !acceptNonZero) return reject(new Error(`Media inspection failed (${code}): ${stderr.slice(-2000)}`));
      resolve({ stdout, stderr, code });
    });
  });
}

// Stream mono PCM in 20 ms frames: bounded memory even for hour-long projects.
// The generated voice track contains no music, so an energy gate can identify
// its audible regions without running Whisper or touching OCR.
function createSpeechDetector({ sampleRate = 16000, threshold = 0.004, minSpeech = 0.06, maxGap = 0.12 } = {}) {
  const frameBytes = Math.round(sampleRate * 0.02) * 2;
  let remainder = Buffer.alloc(0), samples = 0, start = null, lastVoiceEnd = 0;
  const intervals = [];
  const flush = () => {
    if (start !== null && lastVoiceEnd - start >= minSpeech - 0.000001) intervals.push({ start, end: lastVoiceEnd });
    start = null;
  };
  const frame = data => {
    let sum = 0;
    for (let i = 0; i + 1 < data.length; i += 2) sum += (data.readInt16LE(i) / 32768) ** 2;
    const time = samples / sampleRate;
    samples += Math.floor(data.length / 2);
    if (Math.sqrt(sum / Math.max(1, data.length / 2)) >= threshold) {
      if (start === null) start = time;
      lastVoiceEnd = samples / sampleRate;
    } else if (start !== null && samples / sampleRate - lastVoiceEnd > maxGap) flush();
  };
  return {
    push(chunk) {
      const data = remainder.length ? Buffer.concat([remainder, chunk]) : chunk;
      let offset = 0;
      for (; offset + frameBytes <= data.length; offset += frameBytes) frame(data.subarray(offset, offset + frameBytes));
      remainder = Buffer.from(data.subarray(offset));
    },
    finish() {
      if (remainder.length > 1) frame(remainder.subarray(0, remainder.length - remainder.length % 2));
      flush();
      return { intervals, duration: samples / sampleRate };
    },
  };
}

const speechCache = new Map();
const voiceFileIdentity = stat => `${stat.size}:${stat.mtimeMs}:${stat.ctimeMs}`;
async function inspectDubbingSpeech(filePath, { ffmpegPath, job, timeoutMs = 10 * 60 * 1000 } = {}) {
  if (job?.cancelRequested) throw Object.assign(new Error('Media job cancelled.'), { code: 'JOB_CANCELLED' });
  const stat = await fs.promises.stat(filePath);
  if (!stat.isFile() || stat.size < 44) throw new Error('Voice file is empty or missing. Generate voice preview again.');
  const identity = voiceFileIdentity(stat);
  const key = `${filePath}:${identity}`;
  if (speechCache.has(key)) return speechCache.get(key);
  const detector = createSpeechDetector();
  await runMediaProcess(ffmpegPath, ['-hide_banner', '-loglevel', 'error', '-i', filePath, '-map', '0:a:0', '-vn', '-ac', '1', '-ar', '16000', '-f', 's16le', 'pipe:1'], { job, timeoutMs, onData: chunk => detector.push(chunk) });
  const result = detector.finish();
  if (!result.duration || !result.intervals.length) throw new Error('The voice file contains no audible speech. Generate voice preview again.');
  if (identity !== voiceFileIdentity(await fs.promises.stat(filePath))) throw new Error('The voice file changed during inspection. Generate voice preview again.');
  result.identity = identity;
  if (speechCache.size >= 64) speechCache.delete(speechCache.keys().next().value);
  speechCache.set(key, result);
  return result;
}

module.exports = { runMediaProcess, createSpeechDetector, inspectDubbingSpeech, voiceFileIdentity };
