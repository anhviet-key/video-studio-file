const os = require('os');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { policy } = require('./access-policy');

const BYTES_PER_GB = 1024 ** 3;
const PROFILE_LANES = {
  low: 1,
  medium: 2,
  high: 4,
};
const LICENSE_LANES = Object.fromEntries(Object.entries(policy.plans).map(([id, plan]) => [id, plan.maxLanes]));
const LICENSE_ORDER = ['basic', 'plus', 'pro', 'lifetime'];
const APP_DATA_DIR =
  process.env.AI_VIDEO_STUDIO_APP_DATA_DIR ||
  (process.platform === 'win32'
    ? path.join(
        process.env.LOCALAPPDATA ||
          path.join(os.homedir(), 'AppData', 'Local'),
        'AI Video Studio',
      )
    : path.join(os.homedir(), '.ai-video-studio'));
const STORAGE_FILE = path.join(
  APP_DATA_DIR,
  'storage',
  'autopilot_queue.json',
);
const LEGACY_STORAGE_FILE = path.join(
  __dirname,
  '..',
  'storage',
  'autopilot_queue.json',
);

class QueueManager {
  constructor() {
    this.jobQueue = [];
    this.completedJobs = [];
    this.activeJobs = new Set();
    this.activeAbortControllers = new Map();
    this.isProcessingLanes = false;
    this.intervalId = null;
    this.runJobCallback = null;
    this.hardwareProfile = process.env.AI_VIDEO_STUDIO_HARDWARE_PROFILE || 'low';
    this.licenseTier = this.normalizeLicenseTier(
      process.env.AI_VIDEO_STUDIO_LICENSE_TIER || 'basic',
    );
    this.jobIdCounter = 0;

    this.loadFromFile();
  }

  createUniqueJobId() {
    const timestamp = Date.now();
    const pid = process.pid;
    const random = Math.floor(Math.random() * 10000);
    const counter = (this.jobIdCounter + 1) % 100000;
    this.jobIdCounter = counter;
    return Number(String(timestamp).slice(-6) + String(pid).slice(-3) + String(random).slice(-3) + String(counter).slice(-3));
  }

  loadFromFile() {
    try {
      const storageDir = path.dirname(STORAGE_FILE);
      if (!fs.existsSync(storageDir)) {
        fs.mkdirSync(storageDir, { recursive: true });
      }
      if (
        !fs.existsSync(STORAGE_FILE) &&
        // Never treat files shipped inside an installer as this user's history.
        !/[\\/]app\.asar(?:\.unpacked)?[\\/]/i.test(__dirname) &&
        !process.env.AI_VIDEO_STUDIO_APP_DATA_DIR &&
        fs.existsSync(LEGACY_STORAGE_FILE)
      ) {
        fs.copyFileSync(LEGACY_STORAGE_FILE, STORAGE_FILE);
      }
      if (fs.existsSync(STORAGE_FILE)) {
        const raw = fs.readFileSync(STORAGE_FILE, 'utf8');
        let data = {};
        try {
          data = JSON.parse(raw);
        } catch (parseError) {
          const backupPath = `${STORAGE_FILE}.corrupt-backup-${Date.now()}`;
          fs.copyFileSync(STORAGE_FILE, backupPath);
          console.error(
            `[QueueManager] Queue file corrupt, backed up to ${backupPath}. Starting fresh.`,
            parseError,
          );
          this._writeEmptyQueueFile();
          return;
        }
        if (Array.isArray(data.jobQueue)) {
          const recoveredJobs = data.jobQueue.map((job) => {
            if (job.status === 'processing') {
              if (job.stage === 'upload') {
                const targetPlatform = String(
                  job?.config?.targetPlatform || 'youtube',
                );
                return {
                  ...job,
                  status: 'error',
                  errorMsg:
                    `The app closed during ${targetPlatform} upload. Automatic retry was stopped to avoid publishing a duplicate video. Check the platform account before retrying.`,
                  step: 'Upload state requires review',
                };
              }
              return { ...job, status: 'pending', step: 'Resumed after restart...' };
            }
            return job;
          });
          const recoveredTerminalJobs = recoveredJobs.filter((job) =>
            ['done', 'error', 'cancelled'].includes(job.status),
          );
          this.jobQueue = recoveredJobs.filter(
            (job) => !['done', 'error', 'cancelled'].includes(job.status),
          );
          if (recoveredTerminalJobs.length > 0) {
            this.completedJobs = recoveredTerminalJobs;
          }
        }
        if (Array.isArray(data.completedJobs)) {
          const combinedCompletedJobs = [
            ...this.completedJobs,
            ...data.completedJobs,
          ];
          this.completedJobs = combinedCompletedJobs.filter(
            (job, index, jobs) =>
              jobs.findIndex((candidate) => candidate.id === job.id) === index,
          );
        }
      }
    } catch (err) {
      console.error('[QueueManager] Failed to load queue from file:', err);
      try {
        this._writeEmptyQueueFile();
      } catch (writeError) {
        console.error('[QueueManager] Failed to reset queue file:', writeError);
      }
    }
  }

  _writeEmptyQueueFile() {
    const storageDir = path.dirname(STORAGE_FILE);
    if (!fs.existsSync(storageDir)) {
      fs.mkdirSync(storageDir, { recursive: true });
    }
    fs.writeFileSync(
      STORAGE_FILE,
      JSON.stringify({ updatedAt: new Date().toISOString(), jobQueue: [], completedJobs: [] }, null, 2),
      'utf8',
    );
  }

  saveToFile({ throwOnError = false } = {}) {
    let temporary;
    try {
      const storageDir = path.dirname(STORAGE_FILE);
      if (!fs.existsSync(storageDir)) {
        fs.mkdirSync(storageDir, { recursive: true });
      }
      const data = {
        updatedAt: new Date().toISOString(),
        jobQueue: this.jobQueue,
        completedJobs: this.completedJobs,
      };
      temporary = `${STORAGE_FILE}.${crypto.randomUUID()}.tmp`;
      fs.writeFileSync(temporary, JSON.stringify(data, null, 2), { encoding: 'utf8', flag: 'wx' });
      fs.renameSync(temporary, STORAGE_FILE);
      return true;
    } catch (err) {
      console.error('[QueueManager] Failed to save queue to file:', err);
      if (throwOnError) {
        const error = new Error('Queue/history changes could not be saved. Check storage permissions and retry.');
        error.code = 'QUEUE_STORAGE_UNAVAILABLE';
        error.statusCode = 503;
        throw error;
      }
      return false;
    } finally {
      if (temporary) { try { fs.unlinkSync(temporary); } catch {} }
    }
  }

  normalizeLicenseTier(tier) {
    const normalized = String(tier || '').trim().toLowerCase();
    return LICENSE_LANES[normalized] ? normalized : 'basic';
  }

  getLicenseTier() {
    return this.normalizeLicenseTier(this.licenseTier);
  }

  isLicenseTierAtLeast(tier, requiredTier = 'basic') {
    return (
      LICENSE_ORDER.indexOf(this.normalizeLicenseTier(tier)) >=
      LICENSE_ORDER.indexOf(this.normalizeLicenseTier(requiredTier))
    );
  }

  getHardwareProfile() {
    const profile = (this.hardwareProfile || 'low').toLowerCase();
    return PROFILE_LANES[profile] ? profile : 'low';
  }

  setHardwareProfile(profile) {
    const normalized = String(profile || '').toLowerCase();
    if (PROFILE_LANES[normalized]) {
      this.hardwareProfile = normalized;
      process.env.AI_VIDEO_STUDIO_HARDWARE_PROFILE = this.hardwareProfile;
      this.startLoop();
      return true;
    }
    return false;
  }

  setLicenseTier(tier) {
    const normalized = this.normalizeLicenseTier(tier);
    this.licenseTier = normalized;
    process.env.AI_VIDEO_STUDIO_LICENSE_TIER = normalized;

    const allowedLanes = LICENSE_LANES[normalized] || 1;
    const currentProfile = this.getHardwareProfile();
    if ((PROFILE_LANES[currentProfile] || 1) > allowedLanes) {
      this.hardwareProfile =
        allowedLanes >= 4 ? 'high' : allowedLanes >= 2 ? 'medium' : 'low';
      process.env.AI_VIDEO_STUDIO_HARDWARE_PROFILE = this.hardwareProfile;
    }
    this.startLoop();
    return normalized;
  }

  createJobId() {
    return this.createUniqueJobId();
  }

  getMemoryLaneInfo() {
    const totalBytes = Number(os.totalmem()) || 0;
    const freeBytes = Number(os.freemem()) || 0;
    const totalGb = totalBytes / BYTES_PER_GB;
    const freeGb = freeBytes / BYTES_PER_GB;
    const installedLaneLimit =
      totalGb >= 14.5 ? 4 : totalGb >= 7.5 ? 2 : 1;
    const freeMemoryLaneLimit =
      freeGb > 0 && freeGb < 1.2
        ? 1
        : freeGb > 0 && freeGb < 3.5
          ? Math.min(installedLaneLimit, 2)
          : installedLaneLimit;
    const memoryLaneLimit = Math.max(
      1,
      Math.min(installedLaneLimit, freeMemoryLaneLimit),
    );
    const recommendedProfile =
      memoryLaneLimit >= 4 ? 'high' : memoryLaneLimit >= 2 ? 'medium' : 'low';
    const lowFreeMemory = freeGb > 0 && freeGb < 2.5;

    return {
      totalBytes,
      freeBytes,
      totalGb: Number(totalGb.toFixed(1)),
      freeGb: Number(freeGb.toFixed(1)),
      installedLaneLimit,
      freeMemoryLaneLimit,
      memoryLaneLimit,
      recommendedProfile,
      lowFreeMemory,
      perLaneRamGb: 4,
      message:
        installedLaneLimit >= 4
          ? 'Installed RAM supports up to 4 parallel lanes.'
          : installedLaneLimit >= 2
            ? 'Installed RAM supports up to 2 parallel lanes.'
            : 'Installed RAM supports 1 safe lane.',
    };
  }

  getLanePlan() {
    const tier = this.getLicenseTier();
    const profile = this.getHardwareProfile();
    const profileLaneLimit = PROFILE_LANES[profile] || PROFILE_LANES.high;
    const licenseLaneLimit = LICENSE_LANES[tier] || 1;
    const memory = this.getMemoryLaneInfo();
    const effectiveLaneLimit = Math.max(
      1,
      Math.min(profileLaneLimit, licenseLaneLimit, memory.memoryLaneLimit),
    );

    let laneLimitReason = 'profile';
    if (licenseLaneLimit < profileLaneLimit) {
      laneLimitReason = 'license';
    } else if (memory.memoryLaneLimit < profileLaneLimit) {
      laneLimitReason = 'memory';
    }

    return {
      requestedParallelLanes: profileLaneLimit,
      licenseLaneLimit,
      memoryLaneLimit: memory.memoryLaneLimit,
      maxParallelLanes: effectiveLaneLimit,
      laneLimitReason,
      memory,
    };
  }

  getMaxParallelLanes() {
    return this.getLanePlan().maxParallelLanes;
  }

  getQueueStatus() {
    const lanePlan = this.getLanePlan();
    return {
      queue: [...this.jobQueue, ...this.completedJobs],
      activeQueue: [...this.jobQueue],
      history: [...this.completedJobs],
      isRendering: this.activeJobs.size > 0,
      activeJobsCount: this.activeJobs.size,
      requestedParallelLanes: lanePlan.requestedParallelLanes,
      maxParallelLanes: lanePlan.maxParallelLanes,
      memoryLaneLimit: lanePlan.memoryLaneLimit,
      licenseLaneLimit: lanePlan.licenseLaneLimit,
      laneLimitReason: lanePlan.laneLimitReason,
      memory: lanePlan.memory,
      hardwareProfile: this.getHardwareProfile(),
      licenseTier: this.getLicenseTier()
    };
  }

  getAbortSignal(jobId) {
    let controller = this.activeAbortControllers.get(jobId);
    if (!controller) {
      controller = new AbortController();
      this.activeAbortControllers.set(jobId, controller);
    }
    return controller.signal;
  }

  abortJob(jobId) {
    const controller = this.activeAbortControllers.get(jobId);
    if (controller) {
      try {
        controller.abort();
      } catch (e) {
        // ignore
      }
      this.activeAbortControllers.delete(jobId);
    }
  }

  cancelJob(id) {
    const jobId = Number(id);
    const job = this.jobQueue.find((candidate) => candidate.id === jobId);
    if (!job) return null;

    if (['done', 'error', 'cancelled'].includes(job.status)) {
      return job;
    }

    const wasActive = this.activeJobs.has(jobId);
    job.cancelRequested = true;
    job.status = 'cancelled';
    job.errorMsg = 'Job cancelled';
    job.stage = 'cancelled';
    job.stageLabel = 'Cancelled';
    job.step = wasActive
      ? 'Stopping AUTO-PILOT job...'
      : 'Job cancelled by user';
    this.abortJob(jobId);

    if (wasActive) {
      this.saveToFile();
    } else {
      this.jobFinished(job);
    }
    return job;
  }

  addJob(job) {
    if (!job.createdAt) job.createdAt = new Date().toISOString();
    if (!job.id) job.id = this.createJobId();
    this.appendAuditEvent(job, 'job_created', 'Job added to the publishing queue.');
    if (job.config?.runImmediately) {
      const firstScheduledIndex = this.jobQueue.findIndex(
        (queuedJob) =>
          !queuedJob.config?.runImmediately &&
          (queuedJob.status === 'pending' || queuedJob.status === 'queued'),
      );
      if (firstScheduledIndex === -1) {
        this.jobQueue.push(job);
      } else {
        this.jobQueue.splice(firstScheduledIndex, 0, job);
      }
    } else {
      this.jobQueue.push(job);
    }
    this.saveToFile();
    this.startLoop();
    this.processNextJobs();
  }

  removeJob(id) {
    const jobId = Number(id);
    const queuedJob = this.jobQueue.find((job) => job.id === jobId);
    const completedJob = this.completedJobs.find((job) => job.id === jobId);
    if (!queuedJob && !completedJob) {
      return { error: 'Job not found.' };
    }
    if (this.activeJobs.has(jobId) || queuedJob?.status === 'processing') {
      return { error: 'An active job cannot be deleted. Cancel it first.' };
    }
    const previousQueue = this.jobQueue;
    const previousHistory = this.completedJobs;
    this.jobQueue = this.jobQueue.filter(j => j.id !== jobId);
    this.completedJobs = this.completedJobs.filter(j => j.id !== jobId);
    try { this.saveToFile({ throwOnError: true }); }
    catch (error) {
      this.jobQueue = previousQueue;
      this.completedJobs = previousHistory;
      throw error;
    }
    return { removed: true };
  }

  appendAuditEvent(job, action, detail, metadata = {}) {
    if (!job) return;
    const event = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      at: new Date().toISOString(),
      action,
      detail,
      ...metadata,
    };
    job.auditLog = [...(Array.isArray(job.auditLog) ? job.auditLog : []), event].slice(-100);
  }

  retryFailedPlatforms(id) {
    const sourceId = Number(id);
    const source = this.completedJobs.find((job) => job.id === sourceId);
    if (!source) return { error: 'Completed job not found.' };
    const failedPlatforms = Object.entries(source.publishResults || {})
      .filter(([, result]) => result?.status === 'failed')
      .map(([platform]) => platform);
    if (failedPlatforms.length === 0) return { error: 'No failed publish target to retry.' };

    const retryId = this.createJobId();
    const retryTargets = (source.publishTargets || []).filter((target) => failedPlatforms.includes(target.platform));
    const retryJob = {
      ...source,
      id: retryId,
      status: source.config?.requireApproval ? 'awaiting_approval' : 'pending',
      createdAt: new Date().toISOString(),
      startedAt: null,
      completedAt: null,
      retryOf: source.id,
      retryAttempt: Number(source.retryAttempt || 0) + 1,
      errorMsg: '',
      warningMsg: '',
      publishState: 'pending',
      youtubeVideoId: '',
      youtubeVideoUrl: '',
      tiktokPublishId: '',
      tiktokPostId: '',
      facebookVideoId: '',
      publishTargets: retryTargets,
      publishResults: Object.fromEntries(retryTargets.map((target) => [target.platform, {
        status: 'pending',
        accountName: target.accountName,
        idempotencyKey: `${source.id}:${target.platform}:retry:${Date.now()}`,
      }])),
      config: {
        ...(source.config || {}),
        targetPlatforms: failedPlatforms,
        targetPlatform: failedPlatforms[0],
        runImmediately: true,
      },
      time: 'Run Now',
      runImmediately: true,
      auditLog: [],
    };
    this.appendAuditEvent(source, 'retry_requested', `Retry created for failed targets: ${failedPlatforms.join(', ')}.`, { retryJobId: retryId });
    this.appendAuditEvent(retryJob, 'retry_created', `Retry of job ${source.id}; only failed targets retained.`, { sourceJobId: source.id, platforms: failedPlatforms });
    this.addJob(retryJob);
    return { job: retryJob };
  }

  approveJob(id) {
    const job = this.jobQueue.find((candidate) => candidate.id === Number(id));
    if (!job || job.status !== 'awaiting_approval') return null;
    job.status = 'pending';
    job.approvedAt = new Date().toISOString();
    job.approvedBy = 'local_user';
    job.step = 'Approved and queued for publishing.';
    this.appendAuditEvent(job, 'approved', 'Job approved for publishing.');
    this.saveToFile();
    this.processNextJobs();
    return job;
  }

  updateScheduledJob(id, changes = {}) {
    const job = this.jobQueue.find((candidate) => candidate.id === Number(id));
    if (!job) return { error: 'Scheduled job not found.' };
    if (!['pending', 'queued', 'awaiting_approval', 'awaiting_entitlement'].includes(job.status)) {
      return { error: 'Only jobs that have not started can be edited.' };
    }
    if (changes.scheduledAt && !Number.isFinite(Date.parse(changes.scheduledAt))) {
      return { error: 'Invalid scheduled date and time.' };
    }
    if (Object.values(job.publishResults || {}).some(result => ['published', 'submitted', 'needs_review', 'uploading'].includes(result?.status))) {
      return { error: 'A partially published workflow cannot be edited. Resume its missing targets or create a new video; confirmed uploads were preserved.' };
    }
    const topic = String(changes.topic || '').trim();
    const scriptChanged = changes.script !== undefined && String(changes.script || '').trim() !== String(job.config?.topicScripts?.['0'] || '').trim();
    const topicChanged = Boolean(topic && topic !== String(job.config?.topicList || '').trim());
    if (scriptChanged || topicChanged) {
      // Preserve the exported file/history, but never publish stale narration
      // after an edit. The next run must render and authorize the new script.
      delete job.renderResult;
      delete job.renderSlot;
      job.renderRevision = Number(job.renderRevision || 0) + 1;
    }
    if (topic) job.topic = topic;
    const script = String(changes.script || '').trim();
    const requestedTargets = Array.isArray(changes.publishTargets)
      ? changes.publishTargets
      : null;
    const isLocalOnly = changes.autoDownloadOnly === true || changes.deliveryMode === 'local';
    job.config = {
      ...(job.config || {}),
      topicList: topic || job.config?.topicList || '',
      topicScripts: changes.script !== undefined ? { ...(job.config?.topicScripts || {}), '0': script } : job.config?.topicScripts || {},
      manualMetadata: {
        ...(job.config?.manualMetadata || {}),
        ...(changes.manualMetadata || {}),
      },
    };
    if (requestedTargets) {
      const targetPlatforms = isLocalOnly
        ? []
        : requestedTargets
          .map((target) => String(target?.platform || '').trim().toLowerCase())
          .filter((platform, index, values) => ['youtube', 'tiktok', 'facebook'].includes(platform) && values.indexOf(platform) === index);
      job.publishTargets = isLocalOnly ? [] : requestedTargets.filter((target) => targetPlatforms.includes(target.platform));
      job.publishResults = Object.fromEntries(
        job.publishTargets.map((target) => [target.platform, {
          status: 'pending',
          accountName: target.accountName || target.platform,
          idempotencyKey: `${job.id}:${target.platform}:${Date.now()}`,
        }]),
      );
      job.config = {
        ...job.config,
        autoDownloadOnly: isLocalOnly,
        deliveryMode: isLocalOnly ? 'local' : targetPlatforms[0],
        targetPlatform: isLocalOnly ? 'youtube' : targetPlatforms[0],
        targetPlatforms,
      };
      job.channelId = changes.channelId || (isLocalOnly ? null : job.channelId);
      job.channelName = changes.channelName || (isLocalOnly ? 'Local download' : job.channelName);
    }
    if (changes.scheduledAt) {
      const timestamp = Date.parse(changes.scheduledAt);
      if (!Number.isFinite(timestamp)) return { error: 'Invalid scheduled date and time.' };
      job.scheduledAt = new Date(timestamp).toISOString();
      job.config.scheduledAt = job.scheduledAt;
      job.time = new Intl.DateTimeFormat(undefined, { hour: '2-digit', minute: '2-digit' }).format(new Date(timestamp));
    }
    this.appendAuditEvent(job, 'job_edited', 'Scheduled post details were updated before publishing.', {
      targets: requestedTargets ? (isLocalOnly ? ['local'] : job.config.targetPlatforms) : undefined,
    });
    this.saveToFile();
    return { job };
  }

  prepareShutdown() {
    this.isShuttingDown = true;
    if (this.intervalId) { clearInterval(this.intervalId); this.intervalId = null; }
    for (const id of this.activeJobs) this.abortJob(id);
    // Keep queued/scheduled jobs and history; exiting is not "clear queue".
    this.saveToFile();
  }

  stopAll({ clearHistory = false } = {}) {
    for (const job of this.jobQueue) {
      job.discardOnFinish = true;
      if (this.activeJobs.has(job.id)) {
        job.cancelRequested = true;
        job.status = 'cancelled';
      }
      this.abortJob(job.id);
    }
    this.jobQueue = [];
    this.activeJobs.clear();
    if (clearHistory) this.completedJobs = [];
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    try { this.saveToFile({ throwOnError: true }); }
    catch (error) {
      error.message = `Jobs were stopped, but ${error.message.charAt(0).toLowerCase()}${error.message.slice(1)}`;
      throw error;
    }
  }

  holdForEntitlement(job, error) {
    job.status = 'awaiting_entitlement';
    job.entitlementError = { code: error.code || 'FEATURE_LOCKED', message: error.message };
    job.errorMsg = error.message;
    job.step = 'License or quota requires attention. The job and existing outputs were preserved.';
    this.activeJobs.delete(job.id);
    this.appendAuditEvent(job, 'entitlement_blocked', job.step, { code: job.entitlementError.code });
    this.saveToFile();
  }

  clearHistory() {
    const previousHistory = this.completedJobs;
    this.completedJobs = [];
    try { this.saveToFile({ throwOnError: true }); }
    catch (error) { this.completedJobs = previousHistory; throw error; }
  }

  start(runJobCallback) {
    this.runJobCallback = runJobCallback;
    this.startLoop();
    this.processNextJobs();
  }

  runJobNow(id) {
    const jobId = Number(id);
    const job = this.jobQueue.find(j => j.id === jobId);
    if (!job) return false;
    if (!['pending', 'queued', 'awaiting_entitlement'].includes(job.status)) return false;
    if (job.status === 'awaiting_entitlement') {
      job.status = 'pending';
      delete job.entitlementError;
      delete job.errorMsg;
    }

    job.runImmediately = true;
    if (job.config) job.config.runImmediately = true;
    delete job.retryNotBefore;
    job.time = 'Run Now';

    const idx = this.jobQueue.indexOf(job);
    if (idx > -1) {
      this.jobQueue.splice(idx, 1);
      const insertIdx = this.jobQueue.findIndex(j => j.status !== 'processing');
      if (insertIdx === -1) {
        this.jobQueue.push(job);
      } else {
        this.jobQueue.splice(insertIdx, 0, job);
      }
    }

    this.saveToFile();
    this.processNextJobs();
    return true;
  }

  processNextJobs() {
    if (this.isShuttingDown || !this.runJobCallback || this.isProcessingLanes) {
      return;
    }

    this.isProcessingLanes = true;
    try {
      const maxLanes = this.getMaxParallelLanes();
      if (this.activeJobs.size >= maxLanes) {
        return;
      }

      const now = new Date();
      for (const job of this.jobQueue) {
      if (job.status !== 'pending' && job.status !== 'queued') {
          continue;
        }
        if (this.activeJobs.has(job.id)) {
          continue;
        }

        const shouldRun = this.checkJobSchedule(job, now);
        if (shouldRun) {
          this.activeJobs.add(job.id);
          job.status = 'processing';
          if (!job.startedAt) job.startedAt = new Date().toISOString();
          job.step = job.step && job.step !== 'Queued...' ? job.step : 'Initializing workflow...';
          this.saveToFile();
          
          if (this.runJobCallback) {
            const signal = this.getAbortSignal(job.id);
            this.runJobCallback(job, signal).catch(err => {
              console.error(`[QueueManager] Error running job ${job.id}:`, err);
              job.status = 'error';
              job.errorMsg = err.message || String(err);
              this.jobFinished(job);
            });
          }
          if (this.activeJobs.size >= maxLanes) {
            break;
          }
        }
      }
    } finally {
      this.isProcessingLanes = false;
    }
  }

  startLoop() {
    if (this.intervalId) return;

    this.intervalId = setInterval(() => {
      this.processNextJobs();
    }, 2000);
  }

  checkJobSchedule(job, now) {
    try {
      const retryNotBefore = Date.parse(job.retryNotBefore || '');
      if (Number.isFinite(retryNotBefore)) {
        if (now.getTime() < retryNotBefore) return false;
        delete job.retryNotBefore;
      }
      if (job.config?.runImmediately || job.runImmediately) return true;
      const scheduledAt = job.scheduledAt || job.config?.scheduledAt;
      if (scheduledAt) {
        const scheduledTimestamp = Date.parse(scheduledAt);
        if (Number.isFinite(scheduledTimestamp)) {
          return now.getTime() >= scheduledTimestamp;
        }
      }
      const startTime = job.config?.startTime || job.time;
      if (!startTime) return true;

      const parts = startTime.split(':');
      if (parts.length < 2) return true;

      const targetHour = Number(parts[0]);
      const targetMin = Number(parts[1]);

      const targetTime = new Date(
        now.getFullYear(),
        now.getMonth(),
        now.getDate(),
        targetHour,
        targetMin,
        0,
        0,
      );

      return now.getTime() >= targetTime.getTime();
    } catch (e) {
      console.error(`[QueueManager] Error checking schedule for job ${job.id}:`, e);
      return true;
    }
  }

  retryJob(job, delayMs = 5000) {
    const maxRetries = job.config?.maxRetries ?? 2;
    job.retryCount = (job.retryCount || 0) + 1;
    if (job.retryCount <= maxRetries) {
      job.status = 'pending';
      job.retryNotBefore = new Date(Date.now() + delayMs).toISOString();
      job.step = `Retrying in ${Math.round(delayMs / 1000)}s (Attempt ${job.retryCount}/${maxRetries})...`;
      this.activeJobs.delete(job.id);
      this.saveToFile();
      return true;
    }
    return false;
  }

  jobFinished(job) {
    this.activeJobs.delete(job.id);
    this.activeAbortControllers.delete(job.id);

    if (job.discardOnFinish) {
      this.jobQueue = this.jobQueue.filter((candidate) => candidate.id !== job.id);
      this.completedJobs = this.completedJobs.filter(
        (candidate) => candidate.id !== job.id,
      );
      this.saveToFile();
      this.processNextJobs();
      return;
    }
    
    if (
      job.status === 'done' ||
      job.status === 'error' ||
      job.status === 'cancelled'
    ) {
      if (!job.completedAt) job.completedAt = new Date().toISOString();
      const idx = this.jobQueue.findIndex(j => j.id === job.id);
      if (idx !== -1) {
        this.jobQueue.splice(idx, 1);
      }
      if (!this.completedJobs.some(j => j.id === job.id)) {
        this.completedJobs.unshift(job);
      }
    }
    this.saveToFile();
    this.processNextJobs();
  }
}

module.exports = new QueueManager();
