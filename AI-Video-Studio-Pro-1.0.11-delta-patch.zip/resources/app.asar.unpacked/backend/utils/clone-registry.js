const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { accessError } = require('./access-policy');
function readCloneRegistry(filePath) {
  if (!fs.existsSync(filePath)) return [];
  try {
    const entries = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    if (!Array.isArray(entries) || entries.some(entry => !entry || typeof entry !== 'object' || Array.isArray(entry))) throw new Error('Invalid clone registry.');
    return entries;
  } catch {
    throw accessError('CLONE_STORAGE_UNAVAILABLE', 'The clone registry could not be verified. Existing voice data was preserved; no new clone was authorized.', 503);
  }
}
function writeCloneRegistry(filePath, entries) {
  if (!Array.isArray(entries)) throw new Error('A clone registry must be an array.');
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temporary = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
  try {
    fs.writeFileSync(temporary, JSON.stringify(entries, null, 2), { flag: 'wx', mode: 0o600 });
    fs.renameSync(temporary, filePath);
  } finally { if (fs.existsSync(temporary)) fs.unlinkSync(temporary); }
}
function assertNormalizedCloneRegistry(original, normalized) {
  const ids = normalized.map(entry => entry.id);
  if (original.length !== normalized.length || new Set(ids).size !== ids.length) {
    throw accessError('CLONE_STORAGE_UNAVAILABLE', 'The clone registry contains incompatible or duplicate records. Existing voice data was preserved; repair or migrate the registry before changing clones.', 503);
  }
}
module.exports = { readCloneRegistry, writeCloneRegistry, assertNormalizedCloneRegistry };
