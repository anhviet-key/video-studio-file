function parseScript(script) {
  return script
    .split('\n')
    .map((line) => {
      const match = line.match(/^(A|B):\s*(.*)$/i);
      if (!match) return null;

      return {
        speaker: match[1],
        text: match[2],
      };
    })
    .filter(Boolean);
}

module.exports = { parseScript };
