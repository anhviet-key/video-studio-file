const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { Readable, Transform } = require('node:stream');
const { pipeline } = require('node:stream/promises');

const VERSION = /^\d+\.\d+\.\d+$/;
const CDN_HOSTS = new Set([
  'release-assets.githubusercontent.com',
  'objects.githubusercontent.com',
  'github-releases.githubusercontent.com',
  'raw.githubusercontent.com',
  'cdn.jsdelivr.net',
  'github.com',
]);
function compareVersions(left, right) {
  if (!VERSION.test(left) || !VERSION.test(right)) throw new Error('Invalid update version.');
  const a = left.split('.').map(Number), b = right.split('.').map(Number);
  for (let i = 0; i < 3; i++) if (a[i] !== b[i]) return Math.sign(a[i] - b[i]);
  return 0;
}
function validateUpdate(info, currentVersion) {
  if (info?.ok === false) throw new Error(info.error || 'Update check failed.');
  const version = String(info?.latestVersion || info?.version || '');
  if (compareVersions(version, currentVersion) <= 0) throw new Error('No newer update is available.');
  const asset = info.asset || info.assets?.windows?.x64 || info.assets?.windows;
  const name = String(asset?.fileName || asset?.name || '');
  const sha256 = String(asset?.sha256 || '').toLowerCase();
  const sizeBytes = Number(asset?.sizeBytes || asset?.size);
  const isOnline =
    name === 'AI-Video-Studio-Pro-Online-Setup.exe' ||
    name === `AI-Video-Studio-Pro-Online-Setup-${version}.exe`;
  const isFull =
    name === `AI-Video-Studio-Pro-Setup-${version}.exe` ||
    name === `Video-Studio-PRO-Setup-${version}.exe`;
  const isDelta =
    name.endsWith('-delta-patch.zip') ||
    name === `AI-Video-Studio-Pro-${version}-delta-patch.zip` ||
    name === `AI-Video-Studio-Pro-delta-patch-${version}.zip`;
  if (!isOnline && !isFull && !isDelta) throw new Error('Unexpected update installer filename.');
  if (!/^[a-f0-9]{64}$/.test(sha256)) throw new Error('Update manifest is missing a valid SHA-256 checksum.');
  const minSizeBytes = isDelta ? 50 * 1024 : (isOnline ? 50 * 1024 : 100 * 1024 * 1024);
  if (!Number.isSafeInteger(sizeBytes) || sizeBytes < minSizeBytes || sizeBytes > 5 * 1024 ** 3) throw new Error('Invalid update installer size.');
  const url = new URL(asset.url);
  const downloadPrefix = '/anhviet-key/video-studio-file/releases/download/';
  const rawPrefix = '/anhviet-key/video-studio-file/raw/';
  const mainPrefix = '/anhviet-key/video-studio-file/main/';
  const decodedPath = decodeURIComponent(url.pathname);
  const isGithubRelease = url.hostname === 'github.com' && decodedPath.startsWith(downloadPrefix);
  const isGithubRaw = (url.hostname === 'github.com' || url.hostname === 'raw.githubusercontent.com') &&
    (decodedPath.startsWith(rawPrefix) || decodedPath.startsWith(mainPrefix) || decodedPath.includes('/video-studio-file/'));
  const isCdn = url.hostname === 'cdn.jsdelivr.net' && decodedPath.includes('video-studio-file');

  if (
    url.protocol !== 'https:' ||
    (!isGithubRelease && !isGithubRaw && !isCdn) ||
    !decodedPath.endsWith(`/${name}`) ||
    url.username ||
    url.password ||
    url.search ||
    url.hash
  ) {
    throw new Error('Update must come from the official versioned GitHub release.');
  }
  return { version, fileName: name, url: url.href, sha256, sizeBytes, isDelta, signatureRequired: Boolean(asset.signatureRequired) };
}
async function hashFile(filePath) {
  const hash = crypto.createHash('sha256');
  for await (const chunk of fs.createReadStream(filePath)) hash.update(chunk);
  return hash.digest('hex');
}
async function verifyInstaller(filePath, asset, verifySignature) {
  const stat = await fs.promises.lstat(filePath);
  if (!stat.isFile() || stat.isSymbolicLink() || stat.size !== asset.sizeBytes) throw new Error('Update installer size does not match the manifest.');
  if (await hashFile(filePath) !== asset.sha256) throw new Error('Update installer checksum does not match.');
  if (asset.signatureRequired && !(await verifySignature(filePath))) throw new Error('Update installer does not have a valid Authenticode signature.');
}
function createDesktopUpdateService({ directory, currentVersion, fetchImpl = fetch, verifySignature = async () => false, onProgress = () => {} }) {
  let pending = null;
  let abortController = null;
  const ready = new Map();
  async function download(info) {
    const asset = validateUpdate(info, currentVersion);
    if (pending) return pending;
    pending = (async () => {
      await fs.promises.mkdir(directory, { recursive: true });
      const target = path.join(directory, asset.fileName);
      // Never treat a partial/existing file as ready without verification.
      try {
        await verifyInstaller(target, asset, verifySignature);
        const token = crypto.randomBytes(24).toString('hex');
        ready.set(token, { asset, filePath: target });
        onProgress({ phase: 'ready', percent: 100 });
        return { success: true, token, version: asset.version, filePath: target };
      } catch { /* Invalid cache: download to a unique partial, not over the ready file. */ }
      const partial = path.join(directory, `.${asset.fileName}.${crypto.randomBytes(8).toString('hex')}.partial`);
      abortController = new AbortController();
      // Total timeout is generous for a multi-GB offline setup on slow networks.
      const timeout = setTimeout(() => abortController?.abort(new Error('Update download timed out.')), 60 * 60 * 1000);
      let written = 0, lastProgress = 0;
      try {
        let downloadUrl = asset.url, response;
        for (let redirect = 0; redirect <= 5; redirect++) {
          const parsed = new URL(downloadUrl);
          if (parsed.protocol !== 'https:' || parsed.username || parsed.password || (redirect > 0 && !CDN_HOSTS.has(parsed.hostname))) throw new Error('Untrusted update redirect.');
          response = await fetchImpl(downloadUrl, { redirect: 'manual', signal: abortController.signal });
          if (![301, 302, 303, 307, 308].includes(response.status)) break;
          const next = response.headers.get('location');
          await response.body?.cancel();
          if (!next || redirect === 5) throw new Error('Invalid update redirect.');
          downloadUrl = new URL(next, downloadUrl).href;
        }
        if (!response.ok || !response.body) throw new Error(`Update download failed (${response.status}).`);
        const declaredSize = Number(response.headers.get('content-length') || 0);
        if (declaredSize && declaredSize !== asset.sizeBytes) throw new Error('Download size differs from the release manifest.');
        const count = new Transform({ transform(chunk, _encoding, callback) {
          written += chunk.length;
          if (written > asset.sizeBytes) return callback(new Error('Update download exceeds the declared size.'));
          if (Date.now() - lastProgress > 250) {
            lastProgress = Date.now();
            onProgress({ phase: 'downloading', percent: Math.min(99, Math.floor(written / asset.sizeBytes * 100)), receivedBytes: written, totalBytes: asset.sizeBytes });
          }
          callback(null, chunk);
        } });
        await pipeline(Readable.fromWeb(response.body), count, fs.createWriteStream(partial, { flags: 'wx' }), { signal: abortController.signal });
        onProgress({ phase: 'verifying', percent: 99 });
        await verifyInstaller(partial, asset, verifySignature);
        // Windows rename will not overwrite: only replace this validated cache filename.
        await fs.promises.rm(target, { force: true });
        await fs.promises.rename(partial, target);
        const token = crypto.randomBytes(24).toString('hex');
        ready.set(token, { asset, filePath: target });
        onProgress({ phase: 'ready', percent: 100 });
        return { success: true, token, version: asset.version, filePath: target };
      } catch (error) {
        await fs.promises.rm(partial, { force: true }).catch(() => {});
        throw error;
      } finally { clearTimeout(timeout); abortController = null; }
    })();
    try { return await pending; } finally { pending = null; }
  }
  return {
    download,
    cancel() { abortController?.abort(new Error('Update download cancelled.')); },
    async getVerified(token) {
      const entry = ready.get(token);
      if (!entry) throw new Error('Download and verify the update before installing it.');
      await verifyInstaller(entry.filePath, entry.asset, verifySignature);
      return entry;
    },
    hasVerifiedPath(filePath) { return [...ready.values()].some((entry) => path.resolve(entry.filePath) === path.resolve(filePath)); },
  };
}
module.exports = { compareVersions, validateUpdate, hashFile, verifyInstaller, createDesktopUpdateService };
