/**
 * Subtitle Formatter & Line-Break Engine
 * Directly inspired by Subtitle Edit (libse: TextSplit.cs, AutoBreakLine, SplitLongLinesHelper.cs)
 *
 * Implements:
 * 1. AutoBreakLine: Balanced 2-line break (Bottom-Heavy preference) with syntax scoring
 * 2. CPL (Characters Per Line) compliance (default 38-42 chars for Latin/Vietnamese, 20-22 for CJK)
 * 3. CPS (Characters Per Second) reading speed checking (target 14-20 CPS, max 21 CPS)
 * 4. Punctuation & grammar boundary prioritization (sentence ends, commas, conjunctions)
 * 5. Strict No-Break rules (honorifics, numbers with measurement units, orphan words)
 * 6. SplitLongLines: Auto-splitting subtitles that exceed character or duration limits
 * 7. Post-processing: Duration extension into silence gaps, minimum gap enforcement (60ms)
 */

const DEFAULT_SINGLE_LINE_MAX_LENGTH = 38;
const DEFAULT_MAX_LINES = 2;
const MIN_SUBTITLE_DURATION_SEC = 0.84; // Standard minimum display duration (Netflix/SE)
const MIN_ABSOLUTE_DURATION_SEC = 0.60; // Absolute floor for short exclamations
const MAX_SUBTITLE_DURATION_SEC = 7.00; // Standard maximum display duration
const OPTIMAL_INTER_SUBTITLE_GAP_SEC = 0.06; // 60ms gap (~2 frames at 25fps) to prevent flicker
const MAX_RECOMMENDED_CPS = 21.0; // Reading speed warning threshold (Characters Per Second)

// Sentence-terminating punctuation
const SENTENCE_END_REGEX = /[.!?…\u3002\uFF01\uFF1F][\"'”’)\]}]*$/;
const CLAUSE_BOUNDARY_REGEX = /[,;:\uFF0C\u3001\uFF1B\uFF1A\-–—][\"'”’)\]}]*$/;

// Honorifics and titles that MUST NOT be split from the following word
const NO_BREAK_AFTER_TITLES = new Set([
  'mr.', 'mrs.', 'ms.', 'dr.', 'prof.', 'st.', 'sr.', 'jr.',
  'ts.', 'ths.', 'gs.', 'pgs.', 'bs.', 'ds.', 'ks.',
  'bác', 'cô', 'chú', 'anh', 'chị', 'em', 'ông', 'bà', 'thầy',
]);

// Determiners & articles that shouldn't be left dangling at the end of a line
const NO_BREAK_AFTER_DETERMINERS = new Set([
  'the', 'a', 'an', 'this', 'that', 'these', 'those',
  'những', 'các', 'mỗi', 'từng', 'cái', 'con', 'chiếc', 'mọi',
]);

// Conjunctions & prepositions where breaking BEFORE them creates natural syntactic flow
const CONJUNCTION_PREFIXES_VI = new Set([
  'và', 'nhưng', 'hoặc', 'vì', 'bởi vì', 'cho nên', 'do đó', 'tuy nhiên',
  'nếu', 'khi', 'để', 'mà', 'rằng', 'với', 'trong khi', 'mặc dù',
  'thì', 'lại', 'rồi', 'song', 'ngoài ra',
]);

const CONJUNCTION_PREFIXES_EN = new Set([
  'and', 'but', 'or', 'because', 'so', 'that', 'which', 'when',
  'where', 'although', 'if', 'while', 'after', 'before', 'though',
  'unless', 'since', 'until', 'with', 'for', 'to',
]);

// Measurement units and symbols that must not be split from preceding numbers
const NUMBER_MEASURE_UNITS = new Set([
  'kg', 'g', 'mg', 'km', 'm', 'cm', 'mm', 'l', 'ml',
  '%', 's', 'giây', 'phút', 'h', 'giờ', 'ngày', 'tháng', 'năm',
  'đ', 'vnđ', 'vnd', 'usd', 'eur', 'triệu', 'tỷ', 'k', 'nghìn',
]);

function isCjkLanguage(lang = '') {
  const normalized = String(lang || '').trim().toLowerCase();
  return ['zh', 'c', 'ja', 'j', 'ko', 'k', 'chi_sim', 'chi_tra', 'jpn', 'kor'].includes(normalized);
}

function cleanTextWhitespace(text = '') {
  return String(text || '')
    .replace(/\u00A0/g, ' ') // Non-breaking space
    .replace(/[\r\t]+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function isNumericToken(token = '') {
  return /^\d+([.,]\d+)*%?$/.test(String(token || '').trim());
}

/**
 * Score break suitability between words[cutIndex - 1] and words[cutIndex].
 * Mirrors Subtitle Edit's GetBreakCost / CanBreak logic.
 */
function scoreBreakPoint(words, cutIndex, totalWords, language = 'vi') {
  if (cutIndex <= 0 || cutIndex >= words.length) return -9999;

  const prevWord = words[cutIndex - 1];
  const nextWord = words[cutIndex];
  const prevClean = prevWord.toLowerCase().replace(/^[^\w\u00C0-\u1EF9]+|[^\w\u00C0-\u1EF9]+$/gu, '');
  const nextClean = nextWord.toLowerCase().replace(/^[^\w\u00C0-\u1EF9]+|[^\w\u00C0-\u1EF9]+$/gu, '');

  let score = 0;

  // 1. Sentence-ending punctuation (. ? ! …) -> Top priority
  if (SENTENCE_END_REGEX.test(prevWord)) {
    score += 30;
  }
  // 2. Clause-ending punctuation (, ; : -) -> High priority
  else if (CLAUSE_BOUNDARY_REGEX.test(prevWord)) {
    score += 18;
  }

  // 3. Dialogue Dash on next word (- or –) -> Immediate split
  if (nextWord.startsWith('-') || nextWord.startsWith('–')) {
    score += 25;
  }

  // 4. Natural conjunctions on next word (break before them)
  const isVi = !language || language.startsWith('vi') || language === 'v';
  const isEn = language.startsWith('en') || language === 'a';
  if ((isVi && CONJUNCTION_PREFIXES_VI.has(nextClean)) || (isEn && CONJUNCTION_PREFIXES_EN.has(nextClean))) {
    score += 10;
  }

  // 5. PENALTIES: Do NOT break after titles / honorifics
  if (NO_BREAK_AFTER_TITLES.has(prevWord.toLowerCase()) || NO_BREAK_AFTER_TITLES.has(prevClean)) {
    score -= 60;
  }

  // 6. PENALTIES: Do NOT break between a number and its measurement unit
  if (isNumericToken(prevWord) && NUMBER_MEASURE_UNITS.has(nextClean)) {
    score -= 60;
  }

  // 7. PENALTIES: Do NOT break after determiners/articles
  if (NO_BREAK_AFTER_DETERMINERS.has(prevClean)) {
    score -= 20;
  }

  // 8. PENALTIES: Do not leave orphan words (1 small word on line 2 or line 1)
  if (cutIndex === words.length - 1 && nextWord.length <= 4) {
    score -= 25;
  }
  if (cutIndex === 1 && prevWord.length <= 3) {
    score -= 20;
  }

  return score;
}

/**
 * Auto-break a single subtitle text into up to maxLines (default 2),
 * strictly matching Subtitle Edit's TextSplit & AutoBreakLine algorithm.
 */
function autoBreakSubtitleText(text, options = {}) {
  const {
    maxCharactersPerLine = DEFAULT_SINGLE_LINE_MAX_LENGTH,
    maxLines = DEFAULT_MAX_LINES,
    language = 'vi',
    preferBottomHeavy = true,
  } = options;

  const cleaned = cleanTextWhitespace(text);
  if (!cleaned) return '';

  const singleLineLimit = Math.max(16, Number(maxCharactersPerLine) || DEFAULT_SINGLE_LINE_MAX_LENGTH);
  const allowedLines = Math.max(1, Math.min(4, Number(maxLines) || DEFAULT_MAX_LINES));

  // If text already fits nicely on one line, return unbroken
  if (cleaned.length <= singleLineLimit || allowedLines <= 1) {
    return cleaned;
  }

  // CJK handling (Chinese, Japanese, Korean)
  if (isCjkLanguage(language)) {
    const chars = Array.from(cleaned);
    const cjkLimit = Math.min(singleLineLimit, 22);
    if (chars.length <= cjkLimit) return cleaned;

    const mid = Math.floor(chars.length / 2);
    let bestCut = mid;
    let bestScore = -9999;

    for (let i = Math.max(1, mid - 6); i <= Math.min(chars.length - 1, mid + 6); i++) {
      const prevChar = chars[i - 1];
      let score = -Math.abs(i - mid) * 2;
      if (['。', '！', '？', '.', '!', '?'].includes(prevChar)) score += 30;
      else if (['，', '、', '；', '：', ',', ';', ':'].includes(prevChar)) score += 15;
      if (score > bestScore) {
        bestScore = score;
        bestCut = i;
      }
    }
    const line1 = chars.slice(0, bestCut).join('');
    const line2 = chars.slice(bestCut).join('');
    return `${line1}\n${line2}`;
  }

  // Space-delimited languages (Vietnamese, English, etc.)
  const words = cleaned.split(/\s+/).filter(Boolean);
  if (words.length <= 1) return cleaned;

  let bestCutIndex = -1;
  let bestTotalScore = -Infinity;

  const totalLength = cleaned.length;
  // Subtitle Edit bottom-heavy preference: line 2 is ~6-14% longer than line 1
  const idealFirstLineRatio = preferBottomHeavy ? 0.46 : 0.50;
  const idealFirstLineLength = Math.round(totalLength * idealFirstLineRatio);

  let cumulativeLength = 0;
  for (let i = 0; i < words.length - 1; i++) {
    cumulativeLength += words[i].length + (i > 0 ? 1 : 0);
    const line1Len = cumulativeLength;
    const line2Len = totalLength - line1Len - 1;

    const cutIndex = i + 1;
    const ruleScore = scoreBreakPoint(words, cutIndex, words.length, language);

    // Balance cost: difference between line 1 length and ideal line 1 length
    const balanceDiff = Math.abs(line1Len - idealFirstLineLength);
    const balancePenalty = balanceDiff * 1.25;

    // Overhang penalty: heavily penalize lines exceeding singleLineLimit
    let overhangPenalty = 0;
    if (line1Len > singleLineLimit) overhangPenalty += (line1Len - singleLineLimit) * 4.5;
    if (line2Len > singleLineLimit) overhangPenalty += (line2Len - singleLineLimit) * 4.5;

    const totalScore = ruleScore - balancePenalty - overhangPenalty;

    if (totalScore > bestTotalScore) {
      bestTotalScore = totalScore;
      bestCutIndex = cutIndex;
    }
  }

  if (bestCutIndex <= 0 || bestCutIndex >= words.length) {
    return cleaned;
  }

  const line1 = words.slice(0, bestCutIndex).join(' ');
  const line2 = words.slice(bestCutIndex).join(' ');

  return `${line1}\n${line2}`;
}

/**
 * Phonetic/lexical weight estimation for audio timeline synchronization
 */
function estimateSegmentTimingWeight(text = '', language = 'vi') {
  const cleaned = cleanTextWhitespace(text);
  if (!cleaned) return 0;

  if (isCjkLanguage(language)) {
    const chars = Array.from(cleaned.replace(/\s+/g, ''));
    let weight = chars.length * 1.0;
    const strongPunct = (cleaned.match(/[。！？.!?]/g) || []).length;
    const softPunct = (cleaned.match(/[，、；：,;:]/g) || []).length;
    return Math.max(1, weight + strongPunct * 1.5 + softPunct * 0.6);
  }

  const tokens = cleaned.match(/\S+/g) || [];
  let totalWeight = 0;

  for (const token of tokens) {
    const cleanToken = token.replace(/[^\w\u00C0-\u1EF9]+/gu, '');
    const charCount = Math.max(1, cleanToken.length);
    let wordWeight = 1.0 + Math.min(1.0, charCount / 10);

    if (SENTENCE_END_REGEX.test(token)) {
      wordWeight += 1.2;
    } else if (CLAUSE_BOUNDARY_REGEX.test(token)) {
      wordWeight += 0.5;
    }
    totalWeight += wordWeight;
  }

  return Math.max(1, totalWeight);
}

/**
 * Splits text into timed subtitle chunks respecting CPL and natural grammar pauses.
 */
function buildTimedSubtitleChunks(
  text = '',
  langCode = 'vi',
  targetUnitsPerChunk = 7,
  totalDurationSec = 0,
  maxLines = DEFAULT_MAX_LINES,
  options = {},
) {
  const cleaned = cleanTextWhitespace(text)
    .replace(/\[pause[^\]]*\]/gi, ' ')
    .replace(/\b[AB]:/g, ' ')
    .trim();

  if (!cleaned) return [];

  const maxCpl = Number(options.maxCharactersPerLine) || DEFAULT_SINGLE_LINE_MAX_LENGTH;
  const targetWords = Math.max(2, Math.min(30, Number(targetUnitsPerChunk) || 7));
  const maxCharsPerSubtitle = maxCpl * Math.max(1, Math.min(3, Number(maxLines) || DEFAULT_MAX_LINES));

  // Split into raw sentences
  const rawSentences = cleaned.split(/(?<=[.!?…\n])\s+/).filter(Boolean);
  const rawChunks = [];

  for (const sentence of rawSentences) {
    const sentenceWords = sentence.split(/\s+/).filter(Boolean);
    if (sentenceWords.length <= targetWords && sentence.length <= maxCharsPerSubtitle) {
      rawChunks.push(sentence);
      continue;
    }

    let currentWords = [];
    for (let i = 0; i < sentenceWords.length; i++) {
      currentWords.push(sentenceWords[i]);
      const currentText = currentWords.join(' ');
      const hasClauseEnding = CLAUSE_BOUNDARY_REGEX.test(sentenceWords[i]);
      const reachedTarget = currentWords.length >= targetWords || currentText.length >= maxCharsPerSubtitle * 0.85;

      if ((hasClauseEnding && currentWords.length >= Math.floor(targetWords * 0.6)) || reachedTarget) {
        rawChunks.push(currentText);
        currentWords = [];
      }
    }
    if (currentWords.length > 0) {
      if (
        rawChunks.length > 0 &&
        currentWords.length <= 2 &&
        rawChunks[rawChunks.length - 1].length + currentWords.join(' ').length + 1 <= maxCharsPerSubtitle
      ) {
        rawChunks[rawChunks.length - 1] += ' ' + currentWords.join(' ');
      } else {
        rawChunks.push(currentWords.join(' '));
      }
    }
  }

  if (rawChunks.length === 0) {
    rawChunks.push(cleaned);
  }

  const chunks = rawChunks.map((chunkText) => {
    const formattedText = autoBreakSubtitleText(chunkText, {
      maxCharactersPerLine: maxCpl,
      maxLines,
      language: langCode,
      preferBottomHeavy: true,
    });
    const timingWeight = estimateSegmentTimingWeight(chunkText, langCode);
    return {
      text: formattedText,
      weight: Math.max(1, chunkText.split(/\s+/).length),
      timingWeight,
    };
  });

  const totalWeight = chunks.reduce((sum, chunk) => sum + chunk.timingWeight, 0);
  const normalizedDuration = Math.max(0.3, Number(totalDurationSec) || 0);

  let allocatedDurations = chunks.map((chunk) => {
    return totalWeight > 0
      ? normalizedDuration * (chunk.timingWeight / totalWeight)
      : normalizedDuration / chunks.length;
  });

  // Duration safety: clamp short chunks
  const minRequiredTotal = chunks.length * MIN_ABSOLUTE_DURATION_SEC;
  if (normalizedDuration >= minRequiredTotal) {
    for (let idx = 0; idx < allocatedDurations.length; idx++) {
      if (allocatedDurations[idx] < MIN_ABSOLUTE_DURATION_SEC) {
        allocatedDurations[idx] = MIN_ABSOLUTE_DURATION_SEC;
      }
    }
    const currentSum = allocatedDurations.reduce((a, b) => a + b, 0);
    if (currentSum > 0) {
      const scale = normalizedDuration / currentSum;
      allocatedDurations = allocatedDurations.map((d) => d * scale);
    }
  }

  return chunks.map((chunk, index) => ({
    text: chunk.text,
    weight: chunk.weight,
    timingWeight: chunk.timingWeight,
    duration: Math.max(0.2, allocatedDurations[index]),
  }));
}

/**
 * Splits an excessively long subtitle into two smaller timed subtitle events,
 * directly implementing Subtitle Edit's SplitLongLinesHelper.
 */
function splitSubtitleEvent(entry, options = {}) {
  const {
    maxCharactersPerLine = DEFAULT_SINGLE_LINE_MAX_LENGTH,
    maxLines = DEFAULT_MAX_LINES,
    language = 'vi',
    minGapSec = OPTIMAL_INTER_SUBTITLE_GAP_SEC,
  } = options;

  const rawText = cleanTextWhitespace(entry.text || '');
  const start = Math.max(0, Number(entry.start ?? entry.startTime) || 0);
  const end = Math.max(start, Number(entry.end ?? entry.endTime) || start);
  const duration = end - start;
  const maxTotalChars = maxCharactersPerLine * maxLines;

  // If text already qualifies as a single event, return as-is
  if (rawText.length <= maxTotalChars && duration <= MAX_SUBTITLE_DURATION_SEC) {
    return [
      {
        ...entry,
        start,
        end,
        text: autoBreakSubtitleText(rawText, { maxCharactersPerLine, maxLines, language }),
      },
    ];
  }

  // Find best midpoint split
  const words = rawText.split(/\s+/).filter(Boolean);
  if (words.length <= 2) {
    return [
      {
        ...entry,
        start,
        end,
        text: autoBreakSubtitleText(rawText, { maxCharactersPerLine, maxLines, language }),
      },
    ];
  }

  const midWordIndex = Math.floor(words.length / 2);
  let bestCut = midWordIndex;
  let bestScore = -Infinity;

  for (let i = Math.max(1, midWordIndex - 4); i <= Math.min(words.length - 1, midWordIndex + 4); i++) {
    const score = scoreBreakPoint(words, i, words.length, language) - Math.abs(i - midWordIndex) * 2;
    if (score > bestScore) {
      bestScore = score;
      bestCut = i;
    }
  }

  const text1 = words.slice(0, bestCut).join(' ');
  const text2 = words.slice(bestCut).join(' ');

  // Calculate proportional timing with min gap and floor duration
  const charRatio = text1.length / (text1.length + text2.length);
  const halfGap = minGapSec / 2;
  const minPartFloor = Math.min(
    MIN_SUBTITLE_DURATION_SEC,
    Math.max(0.3, duration / 2 - halfGap),
  );

  let splitTime = start + duration * charRatio;
  if (duration >= minPartFloor * 2 + minGapSec) {
    const minSplit = start + minPartFloor + halfGap;
    const maxSplit = end - minPartFloor - halfGap;
    splitTime = Math.max(minSplit, Math.min(maxSplit, splitTime));
  }

  const part1End = Math.max(start + 0.3, splitTime - halfGap);
  const part2Start = Math.min(end - 0.3, splitTime + halfGap);

  const event1 = {
    ...entry,
    start: Number(start.toFixed(3)),
    end: Number(part1End.toFixed(3)),
    text: autoBreakSubtitleText(text1, { maxCharactersPerLine, maxLines, language }),
  };

  const event2 = {
    ...entry,
    start: Number(part2Start.toFixed(3)),
    end: Number(end.toFixed(3)),
    text: autoBreakSubtitleText(text2, { maxCharactersPerLine, maxLines, language }),
  };

  return [event1, event2];
}

/**
 * Post-processes an array of subtitles (e.g. from OCR or Whisper):
 * - Auto-splits overly long lines
 * - Auto-breaks lines into balanced 2-line format
 * - Extends short display durations into silence gaps
 * - Enforces standard minimum gaps
 */
function postProcessSubtitles(subtitles = [], options = {}) {
  const {
    maxCharactersPerLine = DEFAULT_SINGLE_LINE_MAX_LENGTH,
    maxLines = DEFAULT_MAX_LINES,
    language = 'vi',
    minDurationSec = MIN_SUBTITLE_DURATION_SEC,
    minGapSec = OPTIMAL_INTER_SUBTITLE_GAP_SEC,
    splitExcessiveLines = true,
  } = options;

  if (!Array.isArray(subtitles) || subtitles.length === 0) return [];

  // Phase 1: Expand overly long lines if requested
  let initialList = [];
  for (const sub of subtitles) {
    const text = cleanTextWhitespace(sub.text || '');
    if (!text) continue;

    if (splitExcessiveLines && text.length > maxCharactersPerLine * maxLines) {
      initialList.push(...splitSubtitleEvent(sub, options));
    } else {
      initialList.push({
        ...sub,
        start: Math.max(0, Number(sub.start ?? sub.startTime) || 0),
        end: Math.max(0, Number(sub.end ?? sub.endTime) || 0),
        text,
      });
    }
  }

  // Phase 2: Format and timing refinement
  const result = [];
  for (let i = 0; i < initialList.length; i++) {
    const item = initialList[i];
    let start = item.start;
    let end = Math.max(start + 0.1, item.end);
    let duration = end - start;

    if (duration < 0.08) continue;

    const formattedText = autoBreakSubtitleText(item.text, {
      maxCharactersPerLine,
      maxLines,
      language,
      preferBottomHeavy: true,
    });

    const nextItem = initialList[i + 1];
    const nextStart = nextItem ? nextItem.start : Infinity;

    // Extend display duration into silence if subtitle is too short to read comfortably
    if (duration < minDurationSec && nextStart > end + minGapSec) {
      const maxPossibleEnd = nextStart - minGapSec;
      end = Math.min(maxPossibleEnd, start + minDurationSec);
    }

    // Ensure clean gap with previous item
    if (result.length > 0) {
      const prev = result[result.length - 1];
      if (start < prev.end + minGapSec) {
        if (prev.end - prev.start > minDurationSec) {
          prev.end = Math.max(prev.start + 0.3, start - minGapSec);
        } else {
          start = prev.end + minGapSec;
          if (end <= start) end = start + 0.3;
        }
      }
    }

    result.push({
      ...item,
      id: result.length + 1,
      startTime: Number(start.toFixed(3)),
      endTime: Number(end.toFixed(3)),
      start: Number(start.toFixed(3)),
      end: Number(end.toFixed(3)),
      text: formattedText,
    });
  }

  return result;
}

/**
 * Calculates subtitle readability metrics (CPL, CPS, duration, gap)
 */
function calculateSubtitleReadability(subtitles = []) {
  if (!Array.isArray(subtitles) || subtitles.length === 0) {
    return {
      totalSubtitles: 0,
      averageCPS: 0,
      maxCPL: 0,
      warningsCount: 0,
      warnings: [],
    };
  }

  let totalChars = 0;
  let totalDuration = 0;
  let maxCPL = 0;
  const warnings = [];

  for (let i = 0; i < subtitles.length; i++) {
    const sub = subtitles[i];
    const start = Number(sub.start ?? sub.startTime) || 0;
    const end = Number(sub.end ?? sub.endTime) || 0;
    const duration = Math.max(0.01, end - start);
    const text = String(sub.text || '').trim();
    const lines = text.split('\n');

    for (const line of lines) {
      if (line.length > maxCPL) maxCPL = line.length;
      if (line.length > 43) {
        warnings.push({
          type: 'CPL_EXCEEDED',
          index: i + 1,
          lineLength: line.length,
          text: line,
        });
      }
    }

    const cleanCharCount = text.replace(/[\s\r\n]+/g, '').length;
    const cps = cleanCharCount / duration;
    totalChars += cleanCharCount;
    totalDuration += duration;

    if (cps > MAX_RECOMMENDED_CPS) {
      warnings.push({
        type: 'CPS_TOO_HIGH',
        index: i + 1,
        cps: Number(cps.toFixed(1)),
        duration: Number(duration.toFixed(2)),
        text,
      });
    }

    if (duration < MIN_ABSOLUTE_DURATION_SEC) {
      warnings.push({
        type: 'DURATION_TOO_SHORT',
        index: i + 1,
        duration: Number(duration.toFixed(2)),
        text,
      });
    }

    if (i < subtitles.length - 1) {
      const nextStart = Number(subtitles[i + 1].start ?? subtitles[i + 1].startTime) || 0;
      const gap = nextStart - end;
      if (gap < 0) {
        warnings.push({
          type: 'OVERLAPPING_SUBTITLES',
          index: i + 1,
          overlapSec: Number((-gap).toFixed(3)),
        });
      }
    }
  }

  const averageCPS = totalDuration > 0 ? Number((totalChars / totalDuration).toFixed(1)) : 0;

  return {
    totalSubtitles: subtitles.length,
    averageCPS,
    maxCPL,
    warningsCount: warnings.length,
    warnings,
  };
}

module.exports = {
  DEFAULT_SINGLE_LINE_MAX_LENGTH,
  DEFAULT_MAX_LINES,
  MIN_SUBTITLE_DURATION_SEC,
  MIN_ABSOLUTE_DURATION_SEC,
  MAX_SUBTITLE_DURATION_SEC,
  OPTIMAL_INTER_SUBTITLE_GAP_SEC,
  MAX_RECOMMENDED_CPS,
  autoBreakSubtitleText,
  buildTimedSubtitleChunks,
  splitSubtitleEvent,
  postProcessSubtitles,
  calculateSubtitleReadability,
  estimateSegmentTimingWeight,
  cleanTextWhitespace,
};
