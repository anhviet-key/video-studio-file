// Google-only transport. Keys stay in headers, never in request URLs or errors.
function aiError(code, message, fields = {}) {
  return Object.assign(new Error(message), { code, ...fields });
}

function abortError(signal) {
  return typeof signal?.reason?.code === 'string' ? signal.reason : aiError('REQUEST_CANCELLED', 'AI request cancelled.');
}

function waitForSignal(promise, signal) {
  if (signal?.aborted) {
    void Promise.resolve(promise).catch(() => {});
    return Promise.reject(abortError(signal));
  }
  if (!signal) return promise;
  let onAbort;
  const aborted = new Promise((_, reject) => {
    onAbort = () => reject(abortError(signal));
    signal.addEventListener('abort', onAbort, { once: true });
  });
  return Promise.race([promise, aborted]).finally(() => signal.removeEventListener('abort', onAbort));
}

async function withGeminiDeadline(operation, { signal, timeoutMs = 120000 } = {}) {
  if (signal?.aborted) throw abortError(signal);
  const controller = new AbortController();
  const abort = () => controller.abort(abortError(signal));
  if (signal?.aborted) abort();
  else signal?.addEventListener('abort', abort, { once: true });
  const timer = setTimeout(() => controller.abort(aiError('AI_PROVIDER_TIMEOUT', 'Gemini request timed out.')),
    Math.max(1, Math.min(Number(timeoutMs) || 120000, 120000)));
  try { return await waitForSignal(Promise.resolve().then(() => operation(controller.signal)), controller.signal); }
  finally { clearTimeout(timer); signal?.removeEventListener('abort', abort); }
}

function responseText(payload) {
  // Thoughts and other candidates are not the user-facing script.
  return (payload?.candidates?.[0]?.content?.parts || [])
    .filter(part => !part.thought && typeof part.text === 'string').map(part => part.text).join('');
}

function geminiGenerationConfig(model, config = {}) {
  // The ceiling includes thoughts. Reserve room for the multilingual script.
  const visibleBudget = Math.max(2048, Math.ceil((Number(config.maxOutputTokens) || 1024) * 1.5));
  const next = { ...config, maxOutputTokens: Math.min(24576, visibleBudget) };
  if (/^gemini-2\.5-(?:flash|pro)(?:$|-)/i.test(model)) {
    next.thinkingConfig = { thinkingBudget: 1024 };
    next.maxOutputTokens = Math.min(24576, visibleBudget + 1024);
  } else if (/^gemini-3\.(?:[5-8]-flash|1-pro)(?:$|-)/i.test(model)) {
    // 3.8 and 3.7 do not accept minimal. Low is supported by these families.
    next.thinkingConfig = { thinkingLevel: 'low' };
    next.maxOutputTokens = Math.min(24576, visibleBudget + 4096);
  }
  return next;
}

async function requestGeminiText({ url, headers, payload, onChunk, signal, fetchImpl = fetch }) {
  let emitted = false;
  let reader;
  try {
    if (signal?.aborted) throw abortError(signal);
    const response = await fetchImpl(url, { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers },
      body: JSON.stringify(payload), signal });
    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      const status = response.status;
      let providerMessage = String(data?.error?.message || response.statusText || 'Request failed.');
      for (const secret of [headers?.['x-goog-api-key'], headers?.Authorization?.replace(/^Bearer\s+/i, '')]) {
        if (secret) providerMessage = providerMessage.split(secret).join('[redacted]');
      }
      providerMessage = providerMessage.slice(0, 1500);
      const code = status === 429 ? 'AI_PROVIDER_RATE_LIMIT' : status >= 500 ? 'AI_PROVIDER_BUSY'
        : status === 401 || status === 403 || /api.?key.*(?:invalid|not valid)|invalid.api.key/i.test(providerMessage) ? 'AI_PROVIDER_AUTH'
          : status === 404 ? 'AI_MODEL_UNAVAILABLE' : 'AI_PROVIDER_ERROR';
      throw aiError(code, `Gemini HTTP ${status}: ${providerMessage}`,
        { status, providerStatus: data?.error?.status, retryAfter: response.headers.get('retry-after') });
    }
    if (!onChunk) {
      const data = await response.json();
      const reason = data?.candidates?.[0]?.finishReason;
      if (reason && reason !== 'STOP') throw aiError('AI_PROVIDER_INCOMPLETE', `Gemini response was incomplete (${reason}).`);
      const text = responseText(data).trim();
      if (!text) throw aiError('AI_PROVIDER_EMPTY', `Gemini returned no text (${data?.candidates?.[0]?.finishReason || data?.promptFeedback?.blockReason || 'empty response'}).`);
      return text;
    }
    if (!response.body || !response.headers.get('content-type')?.includes('text/event-stream')) {
      throw aiError('AI_PROVIDER_STREAM_INVALID', 'Gemini did not return an event stream.');
    }
    reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let text = '';
    let finished = false;
    const consume = event => {
      const raw = event.split('\n').filter(line => line.startsWith('data:')).map(line => line.slice(5).trim()).join('\n');
      if (!raw || raw === '[DONE]') return;
      let data;
      try { data = JSON.parse(raw); } catch { throw aiError('AI_PROVIDER_STREAM_INVALID', 'Invalid Gemini stream event.'); }
      const finishReason = data?.candidates?.[0]?.finishReason;
      if (finishReason && finishReason !== 'STOP') throw aiError('AI_PROVIDER_INCOMPLETE', `Gemini response was incomplete (${finishReason}).`);
      if (finishReason === 'STOP') finished = true;
      const chunk = responseText(data);
      if (chunk) { text += chunk; emitted = true; onChunk(chunk); }
    };
    while (true) {
      const { value, done } = await reader.read();
      buffer += decoder.decode(value || new Uint8Array(), { stream: !done });
      buffer = buffer.replace(/\r\n/g, '\n');
      if (buffer.length > 8 * 1024 * 1024) throw aiError('AI_PROVIDER_STREAM_INVALID', 'Gemini stream event too large.');
      let end;
      while ((end = buffer.indexOf('\n\n')) >= 0) { consume(buffer.slice(0, end)); buffer = buffer.slice(end + 2); }
      if (done) break;
    }
    if (buffer.trim()) consume(buffer);
    if (!finished) throw aiError('AI_PROVIDER_INCOMPLETE', 'Gemini stream ended without a completed response.');
    if (!text.trim()) throw aiError('AI_PROVIDER_EMPTY', 'Gemini returned an empty response.');
    return text.trim();
  } catch (error) {
    if (signal?.aborted) error = abortError(signal);
    error.partial = emitted;
    throw error;
  } finally {
    if (reader) { await reader.cancel().catch(() => {}); reader.releaseLock(); }
  }
}

module.exports = { requestGeminiText, withGeminiDeadline, waitForSignal, responseText, geminiGenerationConfig };
