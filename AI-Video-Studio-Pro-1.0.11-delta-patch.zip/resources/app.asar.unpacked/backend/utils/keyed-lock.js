const fs = require('fs');
const path = require('path');
const lockfile = require('proper-lockfile');
// A shared key serializes create/delete across
// engines, not just requests to one router; failed work always releases the lock.
const tails = new Map();
async function withKeyedLock(key, action, { filePath } = {}) {
  const previous = tails.get(key) || Promise.resolve();
  let release;
  const current = new Promise(resolve => { release = resolve; });
  tails.set(key, current);
  await previous;
  let unlock;
  try {
    if (filePath) {
      fs.mkdirSync(path.dirname(filePath), { recursive: true });
      unlock = await lockfile.lock(filePath, { realpath: false, stale: 120000, retries: { retries: 8, minTimeout: 100, maxTimeout: 1000 } });
    }
    return await action();
  }
  finally {
    try { if (unlock) await unlock(); }
    finally {
      release();
      if (tails.get(key) === current) tails.delete(key);
    }
  }
}
module.exports = { withKeyedLock };
