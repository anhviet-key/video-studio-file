// Prefer the requested variant, but reuse another complete supported model when
// a fresh profile defaults to a variant that has never been installed.
function selectInstalledModel({ requested, cpuPreferred, preferCpu, options, isComplete }) {
  if (preferCpu && /Q[56]_K/i.test(requested) && isComplete(cpuPreferred)) return cpuPreferred;
  if (isComplete(requested)) return requested;
  if (isComplete(cpuPreferred)) return cpuPreferred;
  return options.find((option) => isComplete(option.fileName))?.fileName || requested;
}

module.exports = { selectInstalledModel };
