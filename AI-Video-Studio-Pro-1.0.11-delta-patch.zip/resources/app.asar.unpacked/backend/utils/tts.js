const path = require('path');

async function generateSpeechSegments(segments, voiceMap) {
  let time = 0;
  const results = [];
  const subtitles = [];

  for (let i = 0; i < segments.length; i++) {
    const seg = segments[i];

    const voice = voiceMap[seg.speaker];

    const filePath = path.join(__dirname, `../outputs/seg_${i}.wav`);

    // ⚠️ HÀM NÀY BẠN ĐÃ CÓ (kokoro)
    const duration = await generateKokoro(seg.text, filePath, voice);

    results.push({
      path: filePath,
      duration,
    });

    subtitles.push({
      start: time,
      end: time + duration,
      text: seg.text,
    });

    time += duration;
  }

  return { results, subtitles };
}

module.exports = { generateSpeechSegments };
