function formatAiRequestFailure(error) {
  const message = String(error?.message || error || '').trim();
  const causeCode = String(error?.cause?.code || error?.code || '').replace(/[^A-Z0-9_]/g, '').slice(0, 64);
  if (/^(?:AI_PROVIDER_|AI_MODEL_|REQUEST_CANCELLED)/.test(error?.code || '')) {
    return { code: error.code, error: message, ...(error.status ? { status: error.status } : {}),
      ...(error.model ? { model: error.model } : {}) };
  }
  const status = Number(error?.status || error?.response?.status) || 0;
  const providerCode = status === 429 ? 'AI_PROVIDER_RATE_LIMIT' : status >= 500 ? 'AI_PROVIDER_BUSY'
    : status === 401 || status === 403 || /api.?key.*(?:invalid|not valid)|invalid.api.key/i.test(message) ? 'AI_PROVIDER_AUTH'
      : status === 404 ? 'AI_MODEL_UNAVAILABLE' : '';
  if (providerCode) return { code: providerCode, error: message, ...(status ? { status } : {}) };
  if (error?.code === 'AI_TEXT_MODEL_REQUIRED') return { code: error.code, error: message };
  if (/timeout|timed out|ETIMEDOUT|UND_ERR_.*TIMEOUT/i.test(`${message} ${causeCode}`)) {
    return { code: 'AI_PROVIDER_TIMEOUT', error: 'The selected AI provider timed out. Check the service or try a shorter request.' };
  }
  if (/fetch failed|failed to fetch|network error|connection error|ECONNREFUSED|ECONNRESET|ENOTFOUND|EAI_AGAIN|UND_ERR_SOCKET/i.test(`${message} ${causeCode}`)) {
    return { code: 'AI_PROVIDER_NETWORK', error: 'Cannot connect to the selected AI provider. Check its address, network, VPN/proxy and service status.', ...(causeCode ? { causeCode } : {}) };
  }
  return { code: 'AI_PROVIDER_ERROR', error: message || 'The AI provider returned no usable result.' };
}

module.exports = { formatAiRequestFailure };
