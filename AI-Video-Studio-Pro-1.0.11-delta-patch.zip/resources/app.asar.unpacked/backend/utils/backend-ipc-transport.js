const STREAM_PATHS = new Set([
  '/api/generate-script/stream',
  '/api/translate-script/stream',
  '/api/chat/stream',
]);
const METHODS = new Set(['GET', 'POST', 'PUT', 'DELETE', 'PATCH']);

function transportFailure(error, { timedOut = false, cancelled = false, streaming = false } = {}) {
  const code = timedOut ? 'BACKEND_TIMEOUT' : cancelled ? 'REQUEST_CANCELLED'
    : streaming ? 'BACKEND_STREAM_INTERRUPTED' : 'BACKEND_UNAVAILABLE';
  const messages = {
    BACKEND_TIMEOUT: 'The backend request timed out. Try a shorter request or check the AI service.',
    REQUEST_CANCELLED: 'The request was cancelled.',
    BACKEND_STREAM_INTERRUPTED: 'The backend stream was interrupted before it completed.',
    BACKEND_UNAVAILABLE: 'Cannot connect to the local backend. Wait for startup to finish or restart the application.',
  };
  // Report safe diagnostics, not a URL, prompt, key, or request body.
  const causeCode = String(error?.cause?.code || error?.code || '').replace(/[^A-Z0-9_]/g, '').slice(0, 64);
  return { success: false, code, error: messages[code], ...(causeCode ? { causeCode } : {}) };
}

async function readBackendResponse(response) {
  // A response body can be read only once, including when JSON parsing fails.
  const raw = await response.text();
  let data;
  try { data = raw ? JSON.parse(raw) : {}; }
  catch { data = { text: raw }; }
  return { success: true, status: response.status, data };
}

function createBackendIpcTransport({ getBaseUrl, getHeaders, fetchImpl = globalThis.fetch }) {
  const activeStreams = new Map();
  const owners = new Map();
  function trackOwner(sender, controller) {
    let owner = owners.get(sender.id);
    if (!owner) {
      const controllers = new Set();
      const abortAll = () => controllers.forEach(item => item.abort());
      owner = { controllers, abortAll };
      owners.set(sender.id, owner);
      sender.once('destroyed', abortAll);
    }
    owner.controllers.add(controller);
    return () => {
      owner.controllers.delete(controller);
      if (owner.controllers.size === 0) {
        sender.removeListener('destroyed', owner.abortAll);
        owners.delete(sender.id);
      }
    };
  }

  async function request(event, req = {}, stream = false) {
    const normalizedPath = String(req.path || '').trim();
    const method = String(req.method || 'GET').toUpperCase();
    let targetUrl;
    try {
      targetUrl = new URL(normalizedPath, getBaseUrl());
      const decoded = decodeURIComponent(targetUrl.pathname);
      if (!normalizedPath.startsWith('/api/') || !METHODS.has(method)
        || !decoded.startsWith('/api/') || decoded.includes('..')
        || targetUrl.origin !== new URL(getBaseUrl()).origin
        || (stream && (method !== 'POST' || !STREAM_PATHS.has(targetUrl.pathname)))) {
        throw new Error('Invalid request');
      }
    } catch {
      return { success: false, code: 'IPC_REQUEST_DENIED', error: 'IPC request is not allowed.' };
    }

    const sender = event.sender;
    const requestId = String(req.requestId || '');
    const key = `${sender.id}:${requestId}`;
    if (stream && (!/^[a-zA-Z0-9-]{1,100}$/.test(requestId) || activeStreams.has(key)
      || [...activeStreams.keys()].filter(value => value.startsWith(`${sender.id}:`)).length >= 3)) {
      return { success: false, code: 'IPC_REQUEST_DENIED', error: 'Invalid or duplicate stream request.' };
    }

    const controller = new AbortController();
    const timeoutMs = Math.min(15 * 60_000, Math.max(1000, Number(req.timeoutMs) || 10 * 60_000));
    let timedOut = false;
    let streaming = false;
    const abort = () => controller.abort();
    const timer = setTimeout(() => { timedOut = true; abort(); }, timeoutMs);
    const untrackOwner = trackOwner(sender, controller);
    if (sender.isDestroyed()) abort();
    if (stream) activeStreams.set(key, controller);
    try {
      const data = req.data;
      const headers = { ...getHeaders() };
      const options = { method, headers, signal: controller.signal };
      if (data?.__videoStudioMultipart) {
        const form = new FormData();
        for (const entry of Array.isArray(data.entries) ? data.entries : []) {
          const field = String(entry?.field || '').trim();
          if (!field) continue;
          if (entry.kind === 'file' && entry.bytes) {
            const fileName = String(entry.fileName || 'upload.bin')
              .replace(/[\\/:*?"<>|\u0000-\u001F]/g, '_').slice(0, 180) || 'upload.bin';
            form.append(field, new Blob([Buffer.from(entry.bytes)], {
              type: String(entry.mimeType || 'application/octet-stream'),
            }), fileName);
          } else form.append(field, String(entry?.value ?? ''));
        }
        if (method !== 'GET') options.body = form;
      } else {
        headers['Content-Type'] = 'application/json';
        // Axios serializes an absent request payload as null in the IPC adapter.
        // Sending literal JSON null makes express.json's strict parser reject
        // valid bodyless controls (stop/cancel/delete) before reaching a route.
        if (data !== undefined && data !== null && method !== 'GET') options.body = JSON.stringify(data);
      }
      const response = await fetchImpl(targetUrl, options);
      if (!stream || !response.ok) return await readBackendResponse(response);
      if (!response.headers.get('content-type')?.includes('application/x-ndjson') || !response.body) {
        return { success: false, code: 'BACKEND_STREAM_INVALID', error: 'The backend did not return an AI event stream.' };
      }
      streaming = true;
      const decoder = new TextDecoder();
      for await (const bytes of response.body) {
        if (sender.isDestroyed()) { abort(); break; }
        const text = decoder.decode(bytes, { stream: true });
        if (text) sender.send('system:ipc-stream-chunk', { requestId, text });
      }
      const tail = decoder.decode();
      if (tail && !sender.isDestroyed()) sender.send('system:ipc-stream-chunk', { requestId, text: tail });
      if (controller.signal.aborted) throw new Error('Aborted');
      return { success: true, status: response.status, data: null };
    } catch (error) {
      return transportFailure(error, { timedOut, cancelled: controller.signal.aborted, streaming });
    } finally {
      clearTimeout(timer);
      untrackOwner();
      if (stream) activeStreams.delete(key);
    }
  }

  return {
    request: (event, req) => request(event, req),
    stream: (event, req) => request(event, req, true),
    cancel(event, requestId) {
      const controller = activeStreams.get(`${event.sender.id}:${String(requestId || '')}`);
      controller?.abort();
      return { success: Boolean(controller) };
    },
  };
}

module.exports = { createBackendIpcTransport, readBackendResponse, transportFailure };
