const VIENEU_EMOTION_CUE_ALIASES = Object.freeze({
  chuckle: '[cười]',
  'cười': '[cười]',
  cuoi: '[cười]',
  sigh: '[thở dài]',
  'thở dài': '[thở dài]',
  'tho dai': '[thở dài]',
  'clear throat': '[hắng giọng]',
  'hắng giọng': '[hắng giọng]',
  'hang giong': '[hắng giọng]',
});

function normalizeVieneuEmotionCue(value = '') {
  const match = String(value || '')
    .trim()
    .normalize('NFC')
    .match(/^\[([^\]]+)\]$/);
  if (!match) return '';
  const key = String(match[1] || '')
    .trim()
    .toLowerCase()
    .replace(/[_-]+/g, ' ')
    .replace(/\s+/g, ' ');
  return VIENEU_EMOTION_CUE_ALIASES[key] || '';
}

function stripVieneuEmotionCues(value = '') {
  return String(value || '').replace(/\[[^\]]+\]/g, (match) =>
    normalizeVieneuEmotionCue(match) ? ' ' : match,
  );
}

module.exports = {
  normalizeVieneuEmotionCue,
  stripVieneuEmotionCues,
};
