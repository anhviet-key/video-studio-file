const policy = require('../config/access-policy.json');
const PLAN_IDS = Object.freeze(Object.keys(policy.plans));

function normalizePlanId(value) {
  const plan = String(value || '').trim().toLowerCase();
  return PLAN_IDS.includes(plan) ? plan : null;
}

function limitFor(planId, field) {
  const value = policy.plans[normalizePlanId(planId) || 'basic'][field];
  return value === null ? Infinity : value;
}

function featuresFor(planId) {
  const plan = normalizePlanId(planId) || 'basic';
  const social = ['plus', 'pro', 'lifetime'].includes(plan);
  return { preview: true, subtitles: true, localDownload: true, autoLocal: true,
    youtube: social, autopilot: social, socialUpload: social, omni: social,
    dialogue: true, transcript: true, extendedVieneu: ['pro', 'lifetime'].includes(plan) };
}

function accessError(code, message, status = 403) {
  return Object.assign(new Error(message), { code, status, statusCode: status, entitlementBlocked: true });
}

function normalizeContext(info = {}, now = Date.now()) {
  const planId = normalizePlanId(info.planId);
  const expiry = info.expiresAt == null ? null : Date.parse(info.expiresAt);
  const legacy = info.licenseSource === 'legacy';
  const licensed = info.isLicensed === true && Boolean(planId) && !info.licenseExpired &&
    (planId === 'lifetime' ? info.expiresAt == null : legacy || (Number.isFinite(expiry) && expiry > now));
  return { planId: licensed ? planId : 'basic', isLicensed: licensed,
    state: licensed ? 'active' : info.licenseExpired ? 'expired' : 'trial',
    expiresAt: licensed ? info.expiresAt || null : null, policyVersion: policy.version,
    trialRemain: Math.max(0, Math.min(policy.trialLimit, Number(info.trialRemain) || 0)),
    licenseSource: licensed ? info.licenseSource || 'cloud' : 'trial' };
}

function assertCapability(context, capability) {
  // Stale plan metadata is not a grant, even when this helper is called without
  // normalizeContext first. Apply the same fail-closed rule to every paid feature.
  const plan = context?.isLicensed === true
    ? normalizePlanId(context.planId) || 'basic'
    : 'basic';
  const features = featuresFor(plan);
  if (!Object.hasOwn(features, capability) || !features[capability]) {
    throw accessError('FEATURE_LOCKED', `${capability} is not available with the current license. Renew or upgrade your plan.`);
  }
  return context;
}

module.exports = { policy, PLAN_IDS, normalizePlanId, limitFor, featuresFor, normalizeContext, assertCapability, accessError };
