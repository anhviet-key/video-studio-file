import gc
import json
import os
import re
import sys
import time
import traceback
from contextlib import redirect_stdout
from pathlib import Path
import numpy as np

os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("TOKENIZERS_PARALLELISM", "false")

if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")

MODEL = None
MODEL_KEY = None
MODEL_DEVICE = None
THREADS_CONFIGURED = False


def _json_error(message):
    print(json.dumps({"ok": False, "error": str(message)}, ensure_ascii=False))


def _load_payload():
    raw = sys.stdin.read()
    if not raw:
        return {}
    return json.loads(raw)


def _safe_text(value):
    return str(value or "").replace("\x00", "").strip()


def _normalize_tts_text(value):
    text = " ".join(_safe_text(value).split())
    if not text:
        return ""
    text = (
        text.replace(" ,", ",")
        .replace(" .", ".")
        .replace(" !", "!")
        .replace(" ?", "?")
        .replace(" ;", ";")
        .replace(" :", ":")
    )
    if text and text[-1] not in ".!?;:":
        text = f"{text}."
    return text


def _duration_seconds(path):
    try:
        import soundfile as sf

        info = sf.info(path)
        if info.samplerate:
            return float(info.frames) / float(info.samplerate)
    except Exception:
        return 0.0
    return 0.0


def _env_int(name, default_value, min_value=None, max_value=None):
    try:
        value = int(str(os.environ.get(name, "")).strip() or int(default_value))
    except Exception:
        value = int(default_value)
    if min_value is not None:
        value = max(int(min_value), value)
    if max_value is not None:
        value = min(int(max_value), value)
    return value


def _env_enabled(name, default=False):
    value = _safe_text(os.environ.get(name)).lower()
    if not value:
        return bool(default)
    return value in {"1", "true", "yes", "on"}


def _resolve_device(torch_module, requested):
    requested = _safe_text(requested).lower()
    if requested and requested not in {"auto", "gpu"}:
        return requested

    min_cuda_mb = int(
        os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_MIN_CUDA_MB", "4096") or "4096"
    )
    if torch_module.cuda.is_available():
        try:
            total_mb = torch_module.cuda.get_device_properties(0).total_memory // (
                1024 * 1024
            )
        except Exception:
            total_mb = 0
        if total_mb >= min_cuda_mb:
            return "cuda"

    if hasattr(torch_module, "xpu") and torch_module.xpu.is_available():
        return "xpu"
    if getattr(torch_module.backends, "mps", None) and torch_module.backends.mps.is_available():
        return "mps"
    return "cpu"


def _resolve_dtype(torch_module, device, requested):
    requested = _safe_text(requested).lower()
    if requested in {"float16", "fp16"}:
        return torch_module.float16
    if requested in {"bfloat16", "bf16"}:
        return torch_module.bfloat16
    if requested in {"float32", "fp32"}:
        return torch_module.float32
    if str(device).startswith(("cuda", "xpu")):
        return torch_module.float16
    return torch_module.float32


def _configure_torch_runtime(torch_module):
    global THREADS_CONFIGURED
    if THREADS_CONFIGURED:
        return
    threads_raw = (
        os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_THREADS")
        or os.environ.get("AI_VIDEO_STUDIO_TTS_THREADS")
        or "4"
    )
    try:
        threads = max(1, min(8, int(float(threads_raw))))
    except Exception:
        threads = 4
    try:
        torch_module.set_num_threads(threads)
    except Exception:
        pass
    try:
        torch_module.set_num_interop_threads(max(1, min(2, threads)))
    except Exception:
        pass
    THREADS_CONFIGURED = True


def _split_config_list(value):
    if isinstance(value, (list, tuple)):
        raw_parts = value
    else:
        raw_parts = re.split(r"[\r\n,;]+", _safe_text(value))
    return [_safe_text(part) for part in raw_parts if _safe_text(part)]


def _unique_non_empty(values):
    result = []
    seen = set()
    for value in values:
        item = _safe_text(value)
        if not item or item in seen:
            continue
        seen.add(item)
        result.append(item)
    return result


def _set_huggingface_endpoint(endpoint):
    endpoint = _safe_text(endpoint).rstrip("/")
    if endpoint:
        os.environ["HF_ENDPOINT"] = endpoint
    else:
        os.environ.pop("HF_ENDPOINT", None)
    try:
        import huggingface_hub.constants as hf_constants

        hf_constants.ENDPOINT = endpoint or "https://huggingface.co"
    except Exception:
        pass


def _import_omnivoice_class():
    try:
        from omnivoice import OmniVoice

        return OmniVoice
    except Exception:
        from omnivoice.models.omnivoice import OmniVoice

        return OmniVoice


def _get_model(payload):
    global MODEL, MODEL_KEY, MODEL_DEVICE

    with redirect_stdout(sys.stderr):
        import torch
        OmniVoice = _import_omnivoice_class()

    _configure_torch_runtime(torch)

    primary_model_id = _safe_text(
        payload.get("modelRepo")
        or os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_MODEL")
        or "k2-fsa/OmniVoice"
    )
    model_ids = _unique_non_empty(
        [primary_model_id]
        + _split_config_list(payload.get("modelFallbackRepos"))
        + _split_config_list(os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_MODEL_FALLBACK_REPOS"))
    )
    if not model_ids:
        model_ids = ["k2-fsa/OmniVoice"]
    endpoint_candidates = _unique_non_empty(
        _split_config_list(payload.get("hfEndpointFallbacks"))
        + _split_config_list(os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_HF_ENDPOINTS"))
        + [os.environ.get("HF_ENDPOINT"), "https://huggingface.co"]
    )
    if not endpoint_candidates:
        endpoint_candidates = [""]
    device = _resolve_device(
        torch,
        payload.get("device") or os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_DEVICE", "auto"),
    )
    dtype = _resolve_dtype(
        torch,
        device,
        payload.get("dtype") or os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_DTYPE", "auto"),
    )
    model_key = f"{'|'.join(model_ids)}::{'|'.join(endpoint_candidates)}::{device}::{dtype}"

    if MODEL is not None and MODEL_KEY == model_key:
        return MODEL

    MODEL = None
    gc.collect()
    if torch.cuda.is_available():
        try:
            torch.cuda.empty_cache()
        except Exception:
            pass

    original_endpoint = os.environ.get("HF_ENDPOINT")
    last_error = None
    try:
        for endpoint in endpoint_candidates:
            _set_huggingface_endpoint(endpoint)
            endpoint_label = endpoint or "default"
            for model_id in model_ids:
                try:
                    with redirect_stdout(sys.stderr):
                        loaded_model = OmniVoice.from_pretrained(
                            model_id,
                            device_map=device,
                            dtype=dtype,
                            load_asr=False,
                        )
                        if device == "cpu" and _env_enabled(
                            "AI_VIDEO_STUDIO_OMNIVOICE_DYNAMIC_QUANTIZATION", False
                        ):
                            try:
                                loaded_model = torch.quantization.quantize_dynamic(
                                    loaded_model,
                                    {torch.nn.Linear},
                                    dtype=torch.qint8
                                )
                            except Exception as e:
                                print(f"[OMNI] Dynamic quantization failed: {e}", file=sys.stderr)
                        MODEL = loaded_model
                    MODEL_KEY = model_key
                    MODEL_DEVICE = device
                    print(
                        f"[OMNI] Loaded model {model_id} via {endpoint_label}",
                        file=sys.stderr,
                        flush=True,
                    )
                    return MODEL
                except Exception as error:
                    last_error = error
                    print(
                        f"[OMNI] Model load failed for {model_id} via {endpoint_label}: {error}",
                        file=sys.stderr,
                        flush=True,
                    )
    finally:
        _set_huggingface_endpoint(original_endpoint or "")
    raise last_error or RuntimeError("Unable to load OmniVoice model.")



def _run_status(payload):
    with redirect_stdout(sys.stderr):
        import torch
        import soundfile  # noqa: F401
        _import_omnivoice_class()

    _configure_torch_runtime(torch)
    device = _resolve_device(
        torch,
        payload.get("device") or os.environ.get("AI_VIDEO_STUDIO_OMNIVOICE_DEVICE", "auto"),
    )
    return {
        "ok": True,
        "device": device,
        "cudaAvailable": bool(torch.cuda.is_available()),
    }


def _run_warm(payload):
    _get_model(payload)
    return {
        "ok": True,
        "device": MODEL_DEVICE,
        "modelLoaded": True,
    }


def _split_text_for_omnivoice(text, max_chars=130):
    normalized = " ".join(str(text or "").split()).strip()
    if not normalized:
        return []
    if len(normalized) <= max_chars:
        return [normalized]

    sentences = re.split(r"(?<=[.!?。！？;；])\s+", normalized)
    parts = []
    for sentence in sentences:
        sentence = sentence.strip()
        if not sentence:
            continue
        if len(sentence) <= max_chars:
            parts.append(sentence)
            continue
        
        clauses = re.split(r"(?<=[,;:，；：])\s+", sentence)
        current = ""
        for clause in clauses:
            clause = clause.strip()
            if not clause:
                continue
            if len(clause) > max_chars:
                words = clause.split()
                hard_parts = []
                hard_current = ""
                for word in words:
                    candidate = f"{hard_current} {word}".strip()
                    if hard_current and len(candidate) > max_chars:
                        hard_parts.append(hard_current)
                        hard_current = word
                    else:
                        hard_current = candidate
                if hard_current:
                    hard_parts.append(hard_current)
                if current:
                    parts.append(current)
                    current = ""
                parts.extend(hard_parts)
                continue
            next_text = f"{current} {clause}".strip() if current else clause
            if current and len(next_text) > max_chars:
                parts.append(current)
                current = clause
            else:
                current = next_text
        if current:
            parts.append(current)

    final_parts = [p.strip() for p in parts if p.strip()]
    return final_parts if final_parts else [normalized]


def _tensor_to_numpy(tensor):
    if tensor is None:
        return None
    if hasattr(tensor, "cpu"):
        tensor = tensor.cpu()
    if hasattr(tensor, "numpy"):
        return tensor.numpy()
    return tensor


def _apply_fades_and_padding(audio, sample_rate):
    audio = np.asarray(audio, dtype=np.float32).reshape(-1)
    if audio.size == 0:
        return audio
    if not np.isfinite(audio).all():
        audio = np.nan_to_num(audio, nan=0.0, posinf=0.0, neginf=0.0)
    peak = float(np.max(np.abs(audio))) if audio.size else 0.0
    if peak > 1.0:
        audio = (audio / peak) * 0.98
    
    # Apply fade-in (5ms)
    fade_in_samples = max(1, int(sample_rate * 0.005))
    if audio.size > fade_in_samples * 2:
        fade_in_ramp = np.linspace(0.0, 1.0, fade_in_samples, dtype=np.float32)
        audio[:fade_in_samples] *= fade_in_ramp

    # Apply fade-out (10ms)
    fade_out_samples = max(1, int(sample_rate * 0.01))
    if audio.size > fade_out_samples * 2:
        fade_out_ramp = np.linspace(1.0, 0.0, fade_out_samples, dtype=np.float32)
        audio[-fade_out_samples:] *= fade_out_ramp

    # Lead silence (80ms) and Tail silence (50ms)
    lead_silence = np.zeros(int(sample_rate * 0.08), dtype=np.float32)
    tail_silence = np.zeros(int(sample_rate * 0.05), dtype=np.float32)
    
    return np.concatenate((lead_silence, audio, tail_silence))


def _run_synthesize(payload):
    import soundfile as sf

    segments = payload.get("segments")
    if not isinstance(segments, list) or not segments:
        raise ValueError("No OmniVoice segments were provided.")

    model = _get_model(payload)
    results = []
    for index, segment in enumerate(segments):
        text = _normalize_tts_text(segment.get("text"))
        output_path = _safe_text(segment.get("outputPath"))
        language = _safe_text(segment.get("engineLang") or segment.get("langCode"))
        reference_audio = _safe_text(segment.get("referenceAudio"))
        reference_text = _safe_text(segment.get("referenceText"))
        instruct = _safe_text(segment.get("instruct"))
        speed = float(segment.get("speed") or 1.0)

        if not text:
            raise ValueError(f"Segment {index + 1} is empty.")
        if not output_path:
            raise ValueError(f"Missing output path for segment {index + 1}.")
        if reference_audio and not os.path.exists(reference_audio):
            raise FileNotFoundError(
                f"Reference audio missing for segment {index + 1}: {reference_audio}"
            )
        if reference_audio and not reference_text:
            raise ValueError(
                f"Reference transcript missing for OmniVoice segment {index + 1}."
            )

        Path(output_path).parent.mkdir(parents=True, exist_ok=True)
        started = time.time()
        
        max_chars = _env_int(
            "AI_VIDEO_STUDIO_OMNIVOICE_MAX_CHARS",
            72 if str(MODEL_DEVICE or "").lower().startswith("cpu") else 120,
            40,
            160,
        )
        text_parts = _split_text_for_omnivoice(text, max_chars=max_chars)
        sample_rate = int(getattr(model, "sampling_rate", None) or 24000)
        collected_audio = []
        join_silence = np.zeros(int(sample_rate * 0.12), dtype=np.float32) # 120ms pause between sentences

        for part in text_parts:
            generate_kwargs = {
                "text": part,
                "language": language or None,
                "speed": speed,
            }
            if reference_audio:
                generate_kwargs["ref_audio"] = reference_audio
                generate_kwargs["ref_text"] = reference_text
                clone_steps = _env_int(
                    "AI_VIDEO_STUDIO_OMNIVOICE_CLONE_NUM_STEP",
                    12 if str(MODEL_DEVICE or "").lower().startswith("cpu") else 24,
                    4,
                    32,
                )
                generate_kwargs["num_step"] = clone_steps
                print(
                    f"[omnivoice] clone segment {index + 1}/{len(segments)} "
                    f"lang={language or 'auto'} steps={clone_steps} "
                    f"ref={os.path.basename(reference_audio)}",
                    file=sys.stderr,
                    flush=True,
                )
            elif instruct:
                generate_kwargs["instruct"] = instruct

            with redirect_stdout(sys.stderr):
                audios = model.generate(**generate_kwargs)
            if not audios:
                raise RuntimeError(f"OmniVoice returned no audio for part: '{part}'")
            
            audio_part = _tensor_to_numpy(audios[0]).reshape(-1)
            if audio_part.size == 0:
                continue
            if not np.isfinite(audio_part).all():
                audio_part = np.nan_to_num(audio_part, nan=0.0, posinf=0.0, neginf=0.0)
            peak = float(np.max(np.abs(audio_part))) if audio_part.size else 0.0
            if peak > 1.0:
                audio_part = (audio_part / peak) * 0.98
            
            if collected_audio:
                collected_audio.append(join_silence)
            collected_audio.append(audio_part)

        if not collected_audio:
            raise RuntimeError(f"OmniVoice produced no audio for segment {index + 1}.")

        combined_audio = np.concatenate(collected_audio)
        final_audio = _apply_fades_and_padding(combined_audio, sample_rate)
        sf.write(output_path, final_audio, sample_rate)
        results.append(
            {
                "index": index,
                "outputPath": output_path,
                "durationSeconds": _duration_seconds(output_path),
                "elapsedSeconds": time.time() - started,
                "device": MODEL_DEVICE,
            }
        )

    return {"ok": True, "results": results, "device": MODEL_DEVICE}


def _handle_payload(payload):
    source_dir = _safe_text(payload.get("sourceDir"))
    if source_dir and os.path.isdir(source_dir):
        sys.path.insert(0, source_dir)
        os.chdir(source_dir)

    action = _safe_text(payload.get("action")) or "synthesize"
    if action == "status":
        return _run_status(payload)
    if action == "warm":
        return _run_warm(payload)
    if action == "synthesize":
        return _run_synthesize(payload)
    raise ValueError(f"Unsupported OmniVoice action: {action}")


def _run_worker_loop():
    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        request_id = None
        try:
            payload = json.loads(raw_line)
            request_id = payload.get("id")
            result = _handle_payload(payload)
            if isinstance(result, dict):
                result.setdefault("ok", True)
            else:
                result = {"ok": True, "result": result}
            result["id"] = request_id
            print(json.dumps(result, ensure_ascii=False), flush=True)
        except Exception as exc:
            print(traceback.format_exc(), file=sys.stderr, flush=True)
            print(
                json.dumps(
                    {"ok": False, "id": request_id, "error": str(exc)},
                    ensure_ascii=False,
                ),
                flush=True,
            )


def main():
    try:
        if "--worker" in sys.argv:
            _run_worker_loop()
            return

        payload = _load_payload()
        result = _handle_payload(payload)
        print(json.dumps(result, ensure_ascii=False))
    except Exception as exc:
        print(traceback.format_exc(), file=sys.stderr, flush=True)
        _json_error(exc)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
