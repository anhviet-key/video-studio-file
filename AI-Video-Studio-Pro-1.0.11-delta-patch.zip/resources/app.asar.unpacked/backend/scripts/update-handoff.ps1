$params = @{}
$currentKey = $null
foreach ($token in $args) {
  if ($token.StartsWith('-')) {
    $currentKey = $token.TrimStart('-')
    $params[$currentKey] = @()
  } elseif ($currentKey) {
    $params[$currentKey] += $token
  }
}
$ParentPid = if ($params.ContainsKey('ParentPid')) { [int]($params['ParentPid'] -join ' ') } else { 0 }
$Installer = if ($params.ContainsKey('Installer')) { $params['Installer'] -join ' ' } else { '' }
$ExpectedSha256 = if ($params.ContainsKey('ExpectedSha256')) { ($params['ExpectedSha256'] -join ' ').ToLowerInvariant() } else { '' }
$ExpectedSize = if ($params.ContainsKey('ExpectedSize')) { [long]($params['ExpectedSize'] -join ' ') } else { 0L }
$InstallDir = if ($params.ContainsKey('InstallDir')) { $params['InstallDir'] -join ' ' } else { '' }
$AppExe = if ($params.ContainsKey('AppExe')) { $params['AppExe'] -join ' ' } else { '' }
$Receipt = if ($params.ContainsKey('Receipt')) { $params['Receipt'] -join ' ' } else { '' }
$RequireSignature = $params.ContainsKey('RequireSignature')

$ErrorActionPreference = 'Stop'
$result = @{ success = $false; checkedAt = [DateTime]::UtcNow.ToString('o') }
try {
  # Do not kill the app: it must save and shut down itself before installation.
  $runningParent = if ($ParentPid -gt 0) { Get-Process -Id $ParentPid -ErrorAction SilentlyContinue } else { $null }
  if ($runningParent) { Wait-Process -Id $ParentPid -Timeout 90 -ErrorAction Stop }
  $installerItem = Get-Item -LiteralPath $Installer
  if ($installerItem.Length -ne $ExpectedSize) { throw 'Installer size changed before installation.' }
  if ((Get-FileHash -LiteralPath $Installer -Algorithm SHA256).Hash.ToLowerInvariant() -ne $ExpectedSha256) { throw 'Installer checksum changed before installation.' }
  if ($RequireSignature -and (Get-AuthenticodeSignature -LiteralPath $Installer).Status -ne 'Valid') { throw 'Installer signature is not valid.' }
  if ([IO.Path]::GetFullPath([IO.Path]::GetDirectoryName($AppExe)) -ne [IO.Path]::GetFullPath($InstallDir)) { throw 'Invalid installation destination.' }
  if ($Installer.EndsWith('.zip', [StringComparison]::OrdinalIgnoreCase)) {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [System.IO.Compression.ZipFile]::OpenRead($Installer)
    try {
      foreach ($entry in $archive.Entries) {
        if ([string]::IsNullOrEmpty($entry.Name)) { continue }
        $targetPath = [IO.Path]::Combine($InstallDir, $entry.FullName)
        $targetDir = [IO.Path]::GetDirectoryName($targetPath)
        if (-not (Test-Path -LiteralPath $targetDir)) {
          [System.IO.Directory]::CreateDirectory($targetDir) | Out-Null
        }
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $targetPath, $true)
      }
    } finally {
      $archive.Dispose()
    }
    $result.success = $true
  } else {
    # NSIS /D must be last and its value must not be enclosed in quotes.
    $installerProcess = Start-Process -FilePath $Installer -ArgumentList @('--updated', "/D=$InstallDir") -WindowStyle Normal -PassThru -Wait
    if ($installerProcess.ExitCode -ne 0) { throw "Installer exited with code $($installerProcess.ExitCode)." }
    $result.success = $true
  }
} catch {
  $result.error = $_.Exception.Message
} finally {
  $result | ConvertTo-Json -Compress | Set-Content -LiteralPath $Receipt -Encoding UTF8
  # Reopen app after update or failure so the app continues seamlessly
  $running = Get-Process -Name "AI Video Studio Pro" -ErrorAction SilentlyContinue
  if (-not $running) {
    if (Test-Path -LiteralPath $AppExe -PathType Leaf) { Start-Process -FilePath $AppExe -WindowStyle Normal }
  }
}
