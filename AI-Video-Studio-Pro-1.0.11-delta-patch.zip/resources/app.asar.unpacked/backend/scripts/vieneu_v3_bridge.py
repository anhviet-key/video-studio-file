"""AI Video Studio bridge for VieNeu 3.3 v3 Turbo (torch-free ONNX/CPU).

The bridge intentionally supports only the v3 data model. VieNeu v2 GGUF,
flat reference codes, and neucodec profiles are not loaded here.
"""

import json
import os
import sys
import time
import traceback
from pathlib import Path

import numpy as np
import soundfile as sf
from vieneu import Vieneu


os.environ.setdefault("PYTHONUTF8", "1")
if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")


DEFAULT_MODEL_DIR = os.environ.get("AI_VIDEO_STUDIO_VIENEU_V3_MODEL_DIR", "").strip()
DEFAULT_ONNX_DIR = os.environ.get("AI_VIDEO_STUDIO_VIENEU_V3_ONNX_DIR", "").strip()
DEFAULT_CODEC_DIR = os.environ.get("AI_VIDEO_STUDIO_VIENEU_V3_CODEC_DIR", "").strip()
DEFAULT_THREADS = max(
    1,
    int(
        os.environ.get(
            "AI_VIDEO_STUDIO_VIENEU_THREADS",
            os.environ.get("AI_VIDEO_STUDIO_TTS_THREADS", "4"),
        )
        or 4
    ),
)
ENGINE_SAMPLE_RATE = 48_000
# VieNeu v3 returns native 48 kHz samples. AI Video Studio defaults to a compact
# 24 kHz timeline, but can preserve the native 48 kHz bandwidth when requested.
# Any rate conversion must resample the signal; relabelling the same samples
# changes playback speed and pitch.
DEFAULT_OUTPUT_SAMPLE_RATE = 24_000
ENGINE_VERSION = "3.3.0"
CUSTOM_VOICE_CACHE = {}


def emit_json(value):
    sys.stdout.write(json.dumps(value, ensure_ascii=False))
    sys.stdout.flush()


def emit_json_line(value):
    sys.stdout.write(json.dumps(value, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def load_json_from_stdin_once():
    raw = sys.stdin.read()
    if not raw.strip():
        raise ValueError("VieNeu 3.3 bridge received an empty request.")
    return json.loads(raw)


def iter_json_lines_from_stdin():
    for raw in sys.stdin:
        line = raw.strip()
        if line:
            yield line


def find_hf_snapshot(repo_folder_name):
    roots = [
        os.environ.get("HF_HOME", ""),
        os.path.expanduser("~/.cache/huggingface"),
        os.path.join(os.environ.get("LOCALAPPDATA", ""), "AI Video Studio", "runtime", "vieneu-python", "hf-home"),
    ]
    for root in roots:
        if not root:
            continue
        hub_dir = Path(root) / "hub" / repo_folder_name / "snapshots"
        if hub_dir.is_dir():
            snapshots = sorted(hub_dir.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
            for s in snapshots:
                if s.is_dir():
                    return str(s)
    return ""


def resolve_runtime_options(payload=None):
    payload = payload or {}
    model_dir = str(payload.get("backboneRepo") or DEFAULT_MODEL_DIR).strip()
    if not model_dir or not Path(model_dir).is_dir():
        model_dir = find_hf_snapshot("models--pnnbao-ump--VieNeu-TTS-v3-Turbo")

    onnx_dir = str(payload.get("onnxDir") or DEFAULT_ONNX_DIR).strip()
    if not onnx_dir or not Path(onnx_dir).is_dir():
        if model_dir and (Path(model_dir) / "onnx_int8").is_dir():
            onnx_dir = str(Path(model_dir) / "onnx_int8")

    codec_dir = str(payload.get("codecDir") or DEFAULT_CODEC_DIR).strip()
    if not codec_dir or not Path(codec_dir).is_dir():
        codec_dir = find_hf_snapshot("models--OpenMOSS-Team--MOSS-Audio-Tokenizer-Nano-ONNX")

    threads = max(1, int(payload.get("threads") or DEFAULT_THREADS))
    if not model_dir or not Path(model_dir).is_dir():
        raise FileNotFoundError("VieNeu 3.3 model directory is missing.")
    if not onnx_dir or not Path(onnx_dir).is_dir():
        raise FileNotFoundError("VieNeu 3.3 ONNX int8 directory is missing.")
    if not codec_dir or not Path(codec_dir).is_dir():
        raise FileNotFoundError("VieNeu 3.3 MOSS ONNX codec directory is missing.")
    return model_dir, onnx_dir, codec_dir, threads


def create_v3_onnx_runtime(model_dir, onnx_dir, codec_dir, threads):
    """Create VieNeu 3.3 with an explicit offline MOSS codec directory.

    VieNeu 3.3.0's public V3Turbo factory accepts extra keyword arguments but
    does not forward ``codec_dir`` to ``OnnxV3LiteEngine``. Without this small
    compatibility shim an otherwise complete offline installation still tries
    to contact Hugging Face. Keep the patch local to construction and restore
    the package class immediately afterwards.
    """
    from vieneu._v3_turbo_engine import onnx_runtime_lite

    required_codec_files = tuple(getattr(onnx_runtime_lite, "_CODEC_FILES", ()))
    missing_codec_files = [
        file_name
        for file_name in required_codec_files
        if not (Path(codec_dir) / file_name).is_file()
    ]
    if missing_codec_files:
        raise FileNotFoundError(
            "VieNeu 3.3 MOSS ONNX codec is incomplete: "
            + ", ".join(missing_codec_files)
        )

    original_engine = onnx_runtime_lite.OnnxV3LiteEngine

    def local_codec_engine(*args, **kwargs):
        kwargs["codec_dir"] = codec_dir
        return original_engine(*args, **kwargs)

    onnx_runtime_lite.OnnxV3LiteEngine = local_codec_engine
    try:
        return Vieneu(
            mode="v3turbo",
            backbone_repo=model_dir,
            backend="onnx",
            precision="int8",
            onnx_dir=onnx_dir,
            threads=threads,
        )
    finally:
        onnx_runtime_lite.OnnxV3LiteEngine = original_engine


def create_runtime(payload=None):
    model_dir, onnx_dir, codec_dir, threads = resolve_runtime_options(payload)
    tts = create_v3_onnx_runtime(model_dir, onnx_dir, codec_dir, threads)
    tts.ai_video_studio_codec_dir = codec_dir
    load_bundled_preset_voices(tts)
    return tts


def load_bundled_preset_voices(tts):
    """Add validated profiles without replacing the existing 3.3 voices."""
    pack_path = Path(__file__).resolve().parent.parent / "assets" / "vieneu" / "presets-v3.json"
    with pack_path.open("r", encoding="utf-8") as handle:
        presets = json.load(handle).get("presets", {})
    if not presets:
        raise ValueError("Bundled VieNeu preset profiles are missing.")
    prepared = {}
    for name, profile in presets.items():
        embedding = np.asarray(profile.get("speaker_emb", []), dtype=np.float32)
        codes = np.asarray(profile.get("codes", []), dtype=np.int64)
        if (embedding.shape != (192,) or not np.isfinite(embedding).all()
                or codes.ndim != 2 or codes.shape[0] == 0 or codes.shape[1] != 16
                or (codes < 0).any() or (codes >= 1024).any()):
            raise ValueError(f"Invalid bundled v3 voice profile: {name}")
        if name not in tts._preset_voices:
            prepared[name] = {"description": profile.get("description", name),
                              "gender": profile.get("gender", ""),
                              "speaker_emb": embedding, "codes": codes}
    tts._preset_voices.update(prepared)


def runtime_signature(payload=None):
    return resolve_runtime_options(payload)


def preset_voice_payloads(tts):
    result = []
    for display_name, voice_name in tts.list_preset_voices():
        result.append({"voiceName": voice_name, "label": display_name})
    return result


def file_signature(file_path):
    path = Path(file_path).resolve()
    stat = path.stat()
    return f"{path}:{stat.st_size}:{stat.st_mtime_ns}"


def enroll_custom_voice(tts, sample_path):
    if not sample_path or not Path(sample_path).is_file():
        raise FileNotFoundError("VieNeu 3.3 clone sample was not found.")
    signature = file_signature(sample_path)
    cached = CUSTOM_VOICE_CACHE.get(signature)
    if cached is not None:
        return cached
    speaker_embedding, ref_codes = tts.encode_reference(sample_path, denoise=True)
    profile = {
        "speaker_emb": np.asarray(speaker_embedding, dtype=np.float32).reshape(-1),
        "codes": np.asarray(ref_codes, dtype=np.int64),
    }
    CUSTOM_VOICE_CACHE.clear()
    CUSTOM_VOICE_CACHE[signature] = profile
    return profile


def resolve_voice(tts, segment):
    speaker_embedding = segment.get("speakerEmbedding")
    ref_codes = segment.get("refCodesV3")
    if isinstance(speaker_embedding, list) and isinstance(ref_codes, list):
        embedding = np.asarray(speaker_embedding, dtype=np.float32).reshape(-1)
        codes = np.asarray(ref_codes, dtype=np.int64)
        if embedding.size == 192 and codes.size > 0 and codes.ndim == 2:
            return {"speaker_emb": embedding, "codes": codes}
    sample_path = str(segment.get("referenceAudioPath") or "").strip()
    if sample_path:
        return enroll_custom_voice(tts, sample_path)
    raw_name = str(segment.get("voiceName") or segment.get("voice") or "").strip()
    for _, voice_id in tts.list_preset_voices():
        if raw_name.lower() in (voice_id.lower(), f"vn3_{voice_id.lower()}", f"vn3_{voice_id.lower()}".replace(" ", "")):
            return voice_id
    clean_raw = raw_name.replace("vn3_", "").replace(" ", "").replace("_", "").lower()
    for v_name in getattr(tts, "_preset_voices", {}):
        clean_v = v_name.replace(" ", "").replace("_", "").lower()
        if clean_v == clean_raw:
            return v_name
    return raw_name or "Adam"


def normalize_output_sample_rate(value=None):
    try:
        return 48_000 if int(value) == 48_000 else DEFAULT_OUTPUT_SAMPLE_RATE
    except (TypeError, ValueError):
        return DEFAULT_OUTPUT_SAMPLE_RATE


def resample_for_output(audio, source_rate, output_rate=DEFAULT_OUTPUT_SAMPLE_RATE):
    source_rate = max(1, int(source_rate or ENGINE_SAMPLE_RATE))
    output_rate = normalize_output_sample_rate(output_rate)
    if source_rate == output_rate:
        return np.asarray(audio, dtype=np.float32).reshape(-1)

    import soxr

    return np.asarray(
        soxr.resample(
            np.asarray(audio, dtype=np.float32).reshape(-1),
            source_rate,
            output_rate,
            quality="HQ",
        ),
        dtype=np.float32,
    )


def synthesize_segment(tts, segment):
    started = time.perf_counter()
    output_path = str(segment.get("outputPath") or "").strip()
    if not output_path:
        raise ValueError("VieNeu 3.3 output path is required.")
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    output_sample_rate = normalize_output_sample_rate(segment.get("outputSampleRate"))
    if segment.get("pauseMatch"):
        audio = np.zeros(int(output_sample_rate * 0.65), dtype=np.float32)
        voice_name = "pause"
    else:
        text = str(segment.get("sourceText") or segment.get("text") or "").strip()
        if not text:
            raise ValueError("VieNeu 3.3 text is empty.")
        voice = resolve_voice(tts, segment)
        voice_name = str(segment.get("voiceName") or segment.get("voice") or "custom")
        audio = tts.infer(
            text,
            voice=voice,
            max_chars=256,
            denoise=True,
            apply_watermark=False,
        )
        # Speed is applied once by the Node audio pipeline after synthesis.  Doing
        # it here as well compounds the requested rate (for example 1.2x became
        # 1.44x) and makes the voice sound unnaturally rushed or dragged out.
        audio = np.asarray(audio, dtype=np.float32).reshape(-1)
        if audio.size == 0:
            raise RuntimeError("VieNeu 3.3 returned no audio.")
        audio = resample_for_output(
            audio,
            getattr(tts, "sample_rate", ENGINE_SAMPLE_RATE),
            output_sample_rate,
        )
        tail = np.zeros(int(output_sample_rate * 0.05), dtype=np.float32)
        audio = np.concatenate((audio, tail))
    sf.write(output_path, audio, output_sample_rate, subtype="PCM_16")
    return {
        "outputPath": output_path,
        "sampleRate": output_sample_rate,
        "sampleCount": int(audio.size),
        "voiceName": voice_name,
        "engineVersion": ENGINE_VERSION,
        "elapsedSeconds": time.perf_counter() - started,
    }


def clone_voice(tts, payload):
    sample_path = str(payload.get("samplePath") or "").strip()
    profile = enroll_custom_voice(tts, sample_path)
    info = sf.info(sample_path)
    return {
        "ok": True,
        "engineVersion": ENGINE_VERSION,
        "speakerEmbedding": profile["speaker_emb"].astype(float).tolist(),
        "refCodesV3": profile["codes"].astype(int).tolist(),
        "sampleRate": int(info.samplerate),
        "referenceSeconds": float(info.frames / max(1, info.samplerate)),
    }


def handle_payload(tts, payload):
    action = str(payload.get("action") or "").lower()
    if action in ("voices", "list_voices"):
        voices = preset_voice_payloads(tts)
        return {"ok": True, "voices": voices, "count": len(voices), "engineVersion": ENGINE_VERSION}
    if action == "warm":
        return {"ok": True, "engineVersion": ENGINE_VERSION, "voicesCount": len(tts.list_preset_voices())}
    if action == "clone_voice":
        return clone_voice(tts, payload)
    if action != "synthesize":
        raise ValueError(f"Unsupported VieNeu 3.3 action: {action}")
    return {
        "ok": True,
        "engineVersion": ENGINE_VERSION,
        "results": [synthesize_segment(tts, segment) for segment in payload.get("segments", [])],
    }


def run_once():
    payload = load_json_from_stdin_once()
    tts = create_runtime(payload)
    emit_json(handle_payload(tts, payload))


def run_worker():
    tts = create_runtime()
    signature = runtime_signature()
    emit_json_line({
        "ok": True,
        "type": "ready",
        "engineVersion": ENGINE_VERSION,
        "voicesCount": len(tts.list_preset_voices()),
    })
    for line in iter_json_lines_from_stdin():
        request_id = None
        try:
            payload = json.loads(line)
            request_id = payload.get("id")
            requested_signature = runtime_signature(payload)
            if requested_signature != signature:
                tts = create_runtime(payload)
                signature = requested_signature
            response = handle_payload(tts, payload)
            if request_id is not None:
                response["id"] = request_id
            emit_json_line(response)
        except Exception as exc:
            error = {"ok": False, "error": str(exc), "traceback": traceback.format_exc()}
            if request_id is not None:
                error["id"] = request_id
            emit_json_line(error)


def main():
    try:
        if "--worker" in sys.argv:
            run_worker()
        else:
            run_once()
    except Exception as exc:
        emit_json({"ok": False, "error": str(exc), "traceback": traceback.format_exc()})
        sys.exit(1)


if __name__ == "__main__":
    main()
