import json
import os
import inspect
import sys
import time
import traceback
from contextlib import redirect_stdout

# Monkeypatch torch.Tensor.numpy to prevent CUDA tensor conversion crash
try:
    import torch
    original_numpy = torch.Tensor.numpy
    def safe_numpy(self, *args, **kwargs):
        if self.is_cuda:
            return self.cpu().numpy(*args, **kwargs)
        return original_numpy(self, *args, **kwargs)
    torch.Tensor.numpy = safe_numpy
except ImportError:
    pass


CLONER = None


def _json_error(message):
    print(json.dumps({"ok": False, "error": str(message)}, ensure_ascii=False))


def _load_payload():
    raw = sys.stdin.read()
    if not raw:
        return {}
    return json.loads(raw)


def _safe_text(value):
    return str(value or "").replace("\x00", "").strip()


def _normalize_tts_text(value):
    text = _safe_text(value)
    if not text:
        return ""
    text = " ".join(text.split())
    text = (
        text.replace(" ,", ",")
        .replace(" .", ".")
        .replace(" !", "!")
        .replace(" ?", "?")
        .replace(" ;", ";")
        .replace(" :", ":")
    )
    if text and text[-1] not in ".!?;:":
        text = f"{text}."
    return text


def _duration_seconds(path):
    try:
        import soundfile as sf

        info = sf.info(path)
        if info.samplerate:
            return float(info.frames) / float(info.samplerate)
    except Exception:
        return 0.0
    return 0.0


def _prepare_source(payload):
    source_dir = _safe_text(payload.get("sourceDir"))
    if source_dir and os.path.isdir(source_dir):
        if source_dir not in sys.path:
            sys.path.insert(0, source_dir)
        os.chdir(source_dir)


def _get_cloner():
    global CLONER
    if CLONER is not None:
        return CLONER

    with redirect_stdout(sys.stderr):
        from core.cloner import KokoClone
        CLONER = KokoClone()
    return CLONER


def _run_synthesize(payload):
    _prepare_source(payload)

    segments = payload.get("segments")
    if not isinstance(segments, list) or not segments:
        raise ValueError("No KokoClone segments were provided.")

    cloner = _get_cloner()
    results = []
    for index, segment in enumerate(segments):
        text = _normalize_tts_text(segment.get("text"))
        engine_lang = _safe_text(segment.get("engineLang") or "en")
        reference_audio = _safe_text(segment.get("referenceAudio"))
        reference_text = _safe_text(segment.get("referenceText"))
        output_path = _safe_text(segment.get("outputPath"))
        if not text:
            raise ValueError(f"Segment {index + 1} is empty.")
        if not reference_audio or not os.path.exists(reference_audio):
            raise FileNotFoundError(f"Reference audio missing for segment {index + 1}.")
        if not output_path:
            raise ValueError(f"Missing output path for segment {index + 1}.")

        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        started = time.time()
        generate_kwargs = {
            "text": text,
            "lang": engine_lang,
            "reference_audio": reference_audio,
            "output_path": output_path,
        }
        generate_params = inspect.signature(cloner.generate).parameters
        if reference_text:
            if "reference_text" in generate_params:
                generate_kwargs["reference_text"] = reference_text
            elif "ref_text" in generate_params:
                generate_kwargs["ref_text"] = reference_text
            elif "transcript" in generate_params:
                generate_kwargs["transcript"] = reference_text
        with redirect_stdout(sys.stderr):
            cloner.generate(**generate_kwargs)
        results.append(
            {
                "index": index,
                "outputPath": output_path,
                "durationSeconds": _duration_seconds(output_path),
                "elapsedSeconds": time.time() - started,
            }
        )

    return {"ok": True, "results": results}


def _handle_payload(payload):
    action = _safe_text(payload.get("action")) or "synthesize"
    if action == "status":
        _prepare_source(payload)
        _get_cloner()
        return {"ok": True, "ready": True}
    if action == "synthesize":
        return _run_synthesize(payload)
    raise ValueError(f"Unsupported KokoClone action: {action}")


def _run_worker_loop():
    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        request_id = None
        try:
            payload = json.loads(raw_line)
            request_id = payload.get("id")
            result = _handle_payload(payload)
            result["id"] = request_id
            print(json.dumps(result, ensure_ascii=False), flush=True)
        except Exception as exc:
            print(traceback.format_exc(), file=sys.stderr, flush=True)
            print(
                json.dumps(
                    {"ok": False, "id": request_id, "error": str(exc)},
                    ensure_ascii=False,
                ),
                flush=True,
            )


def main():
    try:
        if "--worker" in sys.argv:
            _run_worker_loop()
            return

        payload = _load_payload()
        result = _handle_payload(payload)
        print(json.dumps(result, ensure_ascii=False))
    except Exception as exc:
        _json_error(exc)
        raise SystemExit(1)


if __name__ == "__main__":
    main()
