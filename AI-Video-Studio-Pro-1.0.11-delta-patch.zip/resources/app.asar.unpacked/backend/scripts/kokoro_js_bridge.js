const fs = require('fs');
const path = require('path');
const { KokoroTTS, TextSplitterStream } = require('kokoro-js');

const hardwareProfile = (process.env.AI_VIDEO_STUDIO_HARDWARE_PROFILE || 'high').toLowerCase();
let maxWordsPerPart = 32;
let maxCharsPerPart = 300;

if (hardwareProfile === 'low') {
  maxWordsPerPart = 20;
  maxCharsPerPart = 200;
} else if (hardwareProfile === 'medium') {
  maxWordsPerPart = 28;
  maxCharsPerPart = 280;
} else {
  maxWordsPerPart = 40;
  maxCharsPerPart = 350;
}

function clampPcm16Sample(value) {
  const normalized = Number.isFinite(Number(value)) ? Number(value) : 0;
  return Math.max(-1, Math.min(1, normalized));
}

function splitTextByWordWindow(text = '', maxWords = 20) {
  const words = String(text || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean);
  if (words.length <= maxWords) {
    return words.length ? [words.join(' ')] : [];
  }

  const chunks = [];
  for (let index = 0; index < words.length; index += maxWords) {
    chunks.push(words.slice(index, index + maxWords).join(' '));
  }
  return chunks;
}

function countTextWords(text = '') {
  return String(text || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
}

function splitTextBySentenceBoundary(text = '') {
  const normalized = String(text || '').replace(/\s+/g, ' ').trim();
  if (!normalized) return [];
  return (
    normalized.match(/[^.!?]+[.!?]+(?:["')\]]+)?|[^.!?]+$/g) || [normalized]
  )
    .map((part) => String(part || '').trim())
    .filter(Boolean);
}

function packTextPartsIntoWindows(parts = [], maxWords = maxWordsPerPart, maxChars = maxCharsPerPart) {
  const safeParts = (Array.isArray(parts) ? parts : [])
    .map((part) => String(part || '').trim())
    .filter(Boolean);
  if (safeParts.length === 0) return [];

  const chunks = [];
  let current = '';
  let currentWordCount = 0;

  for (const part of safeParts) {
    const partWordCount = part.split(/\s+/).filter(Boolean).length;
    const nextText = current ? `${current} ${part}` : part;
    const nextWordCount = currentWordCount + partWordCount;
    if (
      current &&
      (nextWordCount > maxWords || nextText.length > maxChars)
    ) {
      chunks.push(current);
      current = part;
      currentWordCount = partWordCount;
      continue;
    }
    current = nextText;
    currentWordCount = nextWordCount;
  }

  if (current) {
    chunks.push(current);
  }
  return chunks;
}

function mergeShortTextParts(
  parts = [],
  {
    minWords = 8,
    maxWords = 24,
    maxChars = 220,
  } = {},
) {
  const safeParts = (Array.isArray(parts) ? parts : [])
    .map((part) => String(part || '').trim())
    .filter(Boolean);
  if (safeParts.length <= 1) return safeParts;

  const merged = [];
  let current = '';
  let currentWordCount = 0;

  const flushCurrent = () => {
    if (current) merged.push(current);
    current = '';
    currentWordCount = 0;
  };

  for (const part of safeParts) {
    const partWordCount = part.split(/\s+/).filter(Boolean).length;
    if (!current) {
      current = part;
      currentWordCount = partWordCount;
      continue;
    }

    const nextText = `${current} ${part}`;
    const nextWordCount = currentWordCount + partWordCount;
    const shouldMergeShortCurrent =
      currentWordCount < minWords &&
      nextWordCount <= maxWords &&
      nextText.length <= maxChars;
    const shouldMergeShortPart =
      partWordCount <= Math.max(4, Math.floor(minWords / 2)) &&
      nextWordCount <= maxWords &&
      nextText.length <= maxChars;

    if (shouldMergeShortCurrent || shouldMergeShortPart) {
      current = nextText;
      currentWordCount = nextWordCount;
      continue;
    }

    flushCurrent();
    current = part;
    currentWordCount = partWordCount;
  }

  flushCurrent();
  return merged;
}

function splitLongClauseSafely(text = '') {
  const clause = String(text || '').trim();
  if (!clause) return [];
  const clauseWordCount = clause.split(/\s+/).filter(Boolean).length;
  if (clause.length <= 240 && clauseWordCount <= 24) {
    return [clause];
  }

  const clauseParts = clause
    .split(/(?<=[,;:])\s+|(?<=\s-\s)/g)
    .map((part) => String(part || '').trim())
    .filter(Boolean);

  if (clauseParts.length <= 1) {
    return splitTextByWordWindow(clause, 18);
  }

  return packTextPartsIntoWindows(clauseParts, 24, 220).flatMap((part) => {
    const partWordCount = part.split(/\s+/).filter(Boolean).length;
    if (part.length <= 220 && partWordCount <= 24) {
      return [part];
    }
    return splitTextByWordWindow(part, 18);
  });
}

function splitTextIntoSafeKokoroParts(text = '') {
  const normalized = String(text || '').replace(/\s+/g, ' ').trim();
  if (!normalized) return [];
  try {
    const splitter = new TextSplitterStream();
    splitter.push(normalized);
    splitter.close();
    const sentences = Array.from(splitter)
      .map((part) => String(part || '').trim())
      .filter(Boolean);
    if (sentences.length > 0) {
      return mergeShortTextParts(
        sentences.flatMap((sentence) => splitLongClauseSafely(sentence)),
      );
    }
  } catch {}

  const sentenceMatches =
    normalized.match(/[^.!?]+[.!?]+(?:["'”’)\]]+)?|[^.!?]+$/g) || [];
  const fallbackSentences = sentenceMatches
    .map((part) => String(part || '').trim())
    .filter(Boolean);
  if (fallbackSentences.length <= 1) {
    return splitLongClauseSafely(normalized);
  }
  return mergeShortTextParts(
    fallbackSentences.flatMap((sentence) => splitLongClauseSafely(sentence)),
  );
}

function applyEdgeFade(samples, sampleRate = 24000, fadeMs = 12) {
  if (!(samples instanceof Float32Array) || samples.length < 4) {
    return samples;
  }
  const safeSampleRate = Math.max(8000, Math.round(Number(sampleRate) || 24000));
  const fadeSamples = Math.max(
    1,
    Math.min(
      Math.floor(samples.length / 8),
      Math.round((safeSampleRate * Math.max(2, Number(fadeMs) || 12)) / 1000),
    ),
  );
  if (fadeSamples <= 1) {
    return samples;
  }

  const nextSamples = new Float32Array(samples);
  for (let index = 0; index < fadeSamples; index += 1) {
    const fadeInGain = index / fadeSamples;
    const fadeOutGain = (fadeSamples - index) / fadeSamples;
    nextSamples[index] *= fadeInGain;
    const outIndex = nextSamples.length - fadeSamples + index;
    nextSamples[outIndex] *= fadeOutGain;
  }
  return nextSamples;
}

function analyzeAudioPart(samples) {
  if (!(samples instanceof Float32Array) || samples.length === 0) {
    return {
      sampleCount: 0,
      peak: 0,
      rms: 0,
      nonZeroRatio: 0,
    };
  }

  let peak = 0;
  let sumSquares = 0;
  let nonZeroCount = 0;
  for (let index = 0; index < samples.length; index += 1) {
    const value = Number.isFinite(samples[index]) ? samples[index] : 0;
    const absValue = Math.abs(value);
    if (absValue > peak) peak = absValue;
    if (absValue > 1e-5) nonZeroCount += 1;
    sumSquares += value * value;
  }

  return {
    sampleCount: samples.length,
    peak,
    rms: Math.sqrt(sumSquares / Math.max(1, samples.length)),
    nonZeroRatio: nonZeroCount / Math.max(1, samples.length),
  };
}

function isLikelySilentAudioPart(samples) {
  const stats = analyzeAudioPart(samples);
  if (stats.sampleCount <= 0) return true;
  return (
    stats.peak < 1e-5 ||
    stats.rms < 1e-5 ||
    stats.nonZeroRatio < 0.0005
  );
}

function estimateMinimumPartDurationSeconds(text = '', speed = 1) {
  const wordCount = String(text || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
  if (wordCount <= 2) return 0;
  return wordCount / Math.max(3.8, 5.2 * Math.max(0.5, Number(speed) || 1));
}

function isLikelyEmptyOrTruncatedPart(partAudio, sampleRate, text = '', speed = 1) {
  if (!(partAudio instanceof Float32Array) || partAudio.length === 0) {
    return true;
  }
  const durationSeconds = partAudio.length / Math.max(1, Number(sampleRate) || 24000);
  const minDuration = estimateMinimumPartDurationSeconds(text, speed);
  if (minDuration <= 0) return false;
  return durationSeconds < minDuration * 0.4;
}

function splitProblematicPartFurther(text = '', depth = 0) {
  const safeText = String(text || '').replace(/\s+/g, ' ').trim();
  if (!safeText) return [];
  const sentenceParts = splitTextBySentenceBoundary(safeText);
  if (sentenceParts.length > 1) {
    const maxWords = Math.max(7, 10 - depth * 2);
    const maxChars = Math.max(90, 150 - depth * 20);
    return packTextPartsIntoWindows(sentenceParts, maxWords, maxChars).flatMap(
      (part) =>
        countTextWords(part) > maxWords
          ? splitTextByWordWindow(part, maxWords)
          : [part],
    );
  }
  const commaParts = safeText
    .split(/(?<=[,;:])\s+/g)
    .map((part) => String(part || '').trim())
    .filter(Boolean);
  if (commaParts.length > 1) {
    return packTextPartsIntoWindows(
      commaParts,
      Math.max(8, 16 - depth * 2),
      Math.max(90, 180 - depth * 20),
    ).flatMap((part) => splitTextByWordWindow(part, Math.max(6, 14 - depth)));
  }
  return splitTextByWordWindow(safeText, Math.max(6, 8 - depth));
}

function buildKokoroStableTextVariants(text = '') {
  const normalized = String(text || '').replace(/\s+/g, ' ').trim();
  if (!normalized) return [];
  const variants = new Set();
  const addVariant = (value) => {
    const candidate = String(value || '')
      .replace(/\s+/g, ' ')
      .trim();
    if (candidate && candidate !== normalized) {
      variants.add(candidate);
    }
  };

  addVariant(normalized.replace(/[!?]+/g, '.'));
  addVariant(
    normalized
      .replace(/[“”"‘’]/g, '')
      .replace(/[!?]+/g, '.'),
  );
  addVariant(
    normalized
      .replace(/[;:]+/g, ',')
      .replace(/[!?]+/g, '.'),
  );

  return Array.from(variants).slice(0, 3);
}

async function tryGenerateKokoroPart(tts, text, { voice, speed, lang } = {}) {
  try {
    const part = await tts.generate(text, {
      voice,
      speed,
      lang,
    });
    const audio = part?.audio;
    const sampleRate = Number(part?.sampling_rate) || 24000;
    const silent = isLikelySilentAudioPart(audio);
    const truncated = isLikelyEmptyOrTruncatedPart(
      audio,
      sampleRate,
      text,
      speed,
    );
    return {
      ok: audio instanceof Float32Array && audio.length > 0 && !silent && !truncated,
      audio,
      sampleRate,
      silent,
      truncated,
      error: null,
    };
  } catch (error) {
    return {
      ok: false,
      audio: null,
      sampleRate: 24000,
      silent: true,
      truncated: true,
      error,
    };
  }
}

async function synthesizePartWithRetry(
  tts,
  partText,
  {
    voice = 'am_adam',
    speed = 1,
    lang = 'a',
    depth = 0,
  } = {},
) {
  const generatedPart = await tryGenerateKokoroPart(tts, partText, {
    voice,
    speed,
    lang,
  });
  const partAudio = generatedPart.audio;
  const partRate = generatedPart.sampleRate;
  const partWordCount = String(partText || '')
    .trim()
    .split(/\s+/)
    .filter(Boolean).length;
  const partIsSilent = generatedPart.silent;
  const partIsTruncated = generatedPart.truncated;
  if (generatedPart.ok) {
    return [
      {
        audio: applyEdgeFade(partAudio, partRate),
        sampleRate: partRate,
        text: partText,
      },
    ];
  }

  if (depth <= 2) {
    const variants = buildKokoroStableTextVariants(partText);
    for (const variantText of variants) {
      const variantPart = await tryGenerateKokoroPart(tts, variantText, {
        voice,
        speed,
        lang,
      });
      if (variantPart.ok) {
        return [
          {
            audio: applyEdgeFade(variantPart.audio, variantPart.sampleRate),
            sampleRate: variantPart.sampleRate,
            text: partText,
          },
        ];
      }
    }
  }

  if (depth >= 3) {
    // Prevent voice drops: return silent gap instead of aborting the whole segment
    return [
      {
        audio: new Float32Array(Math.floor(24000 * 0.1)),
        sampleRate: 24000,
        text: partText,
        error: `Kokoro JS gave unusable audio for: ${partText}`,
      },
    ];
  }

  const retryParts = splitProblematicPartFurther(partText, depth);
  if (retryParts.length <= 1) {
    return [
      {
        audio: new Float32Array(Math.floor(24000 * 0.1)),
        sampleRate: 24000,
        text: partText,
        error: `Kokoro JS gave unusable audio for: ${partText}`,
      },
    ];
  }

  const nestedResults = [];
  for (const retryPart of retryParts) {
    const items = await synthesizePartWithRetry(tts, retryPart, {
      voice,
      speed,
      lang,
      depth: depth + 1,
    });
    nestedResults.push(...items);
  }
  return nestedResults;
}

function concatenateFloat32Audio(chunks = [], gapSamples = 0) {
  const safeChunks = (Array.isArray(chunks) ? chunks : []).filter(
    (chunk) => chunk instanceof Float32Array && chunk.length > 0,
  );
  if (safeChunks.length === 0) {
    return new Float32Array(0);
  }

  const safeGapSamples = Math.max(0, Math.round(Number(gapSamples) || 0));
  const totalLength =
    safeChunks.reduce((sum, chunk) => sum + chunk.length, 0) +
    Math.max(0, safeChunks.length - 1) * safeGapSamples;
  const combined = new Float32Array(totalLength);
  let offset = 0;

  safeChunks.forEach((chunk, chunkIndex) => {
    combined.set(chunk, offset);
    offset += chunk.length;
    if (safeGapSamples > 0 && chunkIndex < safeChunks.length - 1) {
      offset += safeGapSamples;
    }
  });

  return combined;
}

function writeMono16BitWav(outputPath, samples, sampleRate = 24000) {
  const safeSamples =
    samples instanceof Float32Array ? samples : new Float32Array(0);
  const pcmDataSize = safeSamples.length * 2;
  const wavBuffer = Buffer.allocUnsafe(44 + pcmDataSize);

  wavBuffer.write('RIFF', 0);
  wavBuffer.writeUInt32LE(36 + pcmDataSize, 4);
  wavBuffer.write('WAVE', 8);
  wavBuffer.write('fmt ', 12);
  wavBuffer.writeUInt32LE(16, 16);
  wavBuffer.writeUInt16LE(1, 20);
  wavBuffer.writeUInt16LE(1, 22);
  wavBuffer.writeUInt32LE(Math.max(1, Math.round(sampleRate || 24000)), 24);
  wavBuffer.writeUInt32LE(Math.max(1, Math.round(sampleRate || 24000)) * 2, 28);
  wavBuffer.writeUInt16LE(2, 32);
  wavBuffer.writeUInt16LE(16, 34);
  wavBuffer.write('data', 36);
  wavBuffer.writeUInt32LE(pcmDataSize, 40);

  for (let index = 0; index < safeSamples.length; index += 1) {
    const sample = clampPcm16Sample(safeSamples[index]);
    const pcmValue =
      sample < 0 ? Math.round(sample * 0x8000) : Math.round(sample * 0x7fff);
    wavBuffer.writeInt16LE(pcmValue, 44 + index * 2);
  }

  fs.writeFileSync(outputPath, wavBuffer);
}

let cachedTts = null;
let cachedRuntimeKey = '';

function emitWorkerProgress(event = {}) {
  try {
    process.stderr.write(`__KOKORO_JS_PROGRESS__${JSON.stringify(event)}\n`);
  } catch {}
}

async function ensureWorkerTts(modelDir, dtype = 'q4f16', requestId = null, total = 0) {
  const safeModelDir = String(modelDir || '').trim();
  const safeDtype = String(dtype || 'q4f16').trim() || 'q4f16';
  const runtimeKey = `${path.resolve(safeModelDir)}::${safeDtype}`;
  if (cachedTts && cachedRuntimeKey === runtimeKey) {
    return cachedTts;
  }

  emitWorkerProgress({ id: requestId, type: 'loading', total });
  cachedTts = await KokoroTTS.from_pretrained(safeModelDir, {
    dtype: safeDtype,
    device: 'cpu',
  });
  cachedRuntimeKey = runtimeKey;
  emitWorkerProgress({ id: requestId, type: 'loaded', total });
  return cachedTts;
}

async function synthesizeSegmentSafely(tts, segment, index, total, emitProgress) {
  const text = String(segment.text || '').trim();
  const voice = String(segment.voice || 'am_adam');
  const speed = Number(segment.speed) || 1;
  const outputPath = String(segment.outputPath || '').trim();
  const lang = String(segment.langCode || segment.lang || 'a');
  const sampleGapSeconds = 0.05;

  const safeParts = splitTextIntoSafeKokoroParts(text);
  if (safeParts.length <= 1) {
    const renderedParts = await synthesizePartWithRetry(tts, text, {
      voice,
      speed,
      lang,
    });
    const sampleRate = Number(renderedParts[0]?.sampleRate) || 24000;
    const combinedAudio = concatenateFloat32Audio(
      renderedParts.map((part) => part.audio),
      Math.round(sampleRate * sampleGapSeconds),
    );
    writeMono16BitWav(outputPath, combinedAudio, sampleRate);
    return {
      fileSize: fs.existsSync(outputPath) ? fs.statSync(outputPath).size : 0,
      sampleCount: combinedAudio.length,
      chunkCount: renderedParts.length,
      streamMode: renderedParts.length > 1,
    };
  }

  const collectedChunks = [];
  let sampleRate = 24000;
  for (let sentenceIndex = 0; sentenceIndex < safeParts.length; sentenceIndex += 1) {
    const partText = safeParts[sentenceIndex];
    const renderedParts = await synthesizePartWithRetry(tts, partText, {
      voice,
      speed,
      lang,
    });
    for (const renderedPart of renderedParts) {
      const partAudio = renderedPart?.audio;
      const partRate = Number(renderedPart?.sampleRate) || 24000;
      if (!(partAudio instanceof Float32Array) || partAudio.length === 0) {
        throw new Error(`Kokoro JS skipped an empty audio part for text: ${partText}`);
      }
      sampleRate = partRate;
      collectedChunks.push(partAudio);
    }
    emitProgress({
      type: 'sentence_done',
      index,
      total,
      sentenceIndex,
      sentenceTotal: safeParts.length,
      voice,
      outputPath,
      textLength: String(partText || '').length,
      sampleCount: renderedParts.reduce(
        (sum, part) => sum + (part?.audio instanceof Float32Array ? part.audio.length : 0),
        0,
      ),
    });
  }

  if (collectedChunks.length === 0) {
    throw new Error(`Kokoro JS stream returned no audio chunks for voice "${voice}".`);
  }

  const combinedAudio = concatenateFloat32Audio(
    collectedChunks,
    Math.round(sampleRate * sampleGapSeconds),
  );
  writeMono16BitWav(outputPath, combinedAudio, sampleRate);

  return {
    fileSize: fs.existsSync(outputPath) ? fs.statSync(outputPath).size : 0,
    sampleCount: combinedAudio.length,
    chunkCount: collectedChunks.length,
    streamMode: true,
  };
}

async function handleSynthesizeRequest(payload = {}) {
  const requestId =
    Object.prototype.hasOwnProperty.call(payload, 'id') ? payload.id : null;
  const modelDir = String(payload.modelDir || '').trim();
  const dtype = String(payload.dtype || 'q4f16').trim();
  const segments = Array.isArray(payload.segments) ? payload.segments : [];
  if (!modelDir) {
    throw new Error('Kokoro JS model directory is missing.');
  }

  const tts = await ensureWorkerTts(modelDir, dtype, requestId, segments.length);
  const results = [];

  for (let index = 0; index < segments.length; index += 1) {
    const segment = segments[index];
    const outputPath = String(segment.outputPath || '').trim();
    if (!outputPath) {
      throw new Error('Kokoro JS segment output path is missing.');
    }
    fs.mkdirSync(path.dirname(outputPath), { recursive: true });
    if (fs.existsSync(outputPath)) {
      fs.rmSync(outputPath, { force: true });
    }

    emitWorkerProgress({
      id: requestId,
      type: 'segment_start',
      index,
      total: segments.length,
      outputPath,
      voice: String(segment.voice || 'am_adam'),
      textLength: String(segment.text || '').length,
    });

    const result = await synthesizeSegmentSafely(
      tts,
      segment,
      index,
      segments.length,
      (event) => emitWorkerProgress({ id: requestId, ...event }),
    );
    const fileSize = fs.existsSync(outputPath) ? fs.statSync(outputPath).size : 0;
    results.push({
      outputPath,
      fileSize,
      sampleCount: Number(result?.sampleCount) || 0,
      chunkCount: Number(result?.chunkCount) || 0,
      streamMode: Boolean(result?.streamMode),
      validatedSafely: true,
    });

    emitWorkerProgress({
      id: requestId,
      type: 'segment_done',
      index,
      total: segments.length,
      outputPath,
      fileSize,
      chunkCount: Number(result?.chunkCount) || 0,
      streamMode: Boolean(result?.streamMode),
    });
  }

  return {
    ok: true,
    id: requestId,
    results,
  };
}

async function handleWarmRequest(payload = {}) {
  const requestId =
    Object.prototype.hasOwnProperty.call(payload, 'id') ? payload.id : null;
  const modelDir = String(payload.modelDir || '').trim();
  const dtype = String(payload.dtype || 'q4f16').trim();
  if (!modelDir) {
    throw new Error('Kokoro JS model directory is missing.');
  }

  await ensureWorkerTts(modelDir, dtype, requestId, 0);
  return {
    ok: true,
    id: requestId,
    warmed: true,
  };
}

async function handleRequest(payload = {}) {
  const action = String(payload?.action || 'synthesize').trim().toLowerCase();
  if (action === 'warm') {
    return handleWarmRequest(payload);
  }
  return handleSynthesizeRequest(payload);
}

async function readStdinJson() {
  const chunks = [];
  for await (const chunk of process.stdin) {
    chunks.push(chunk);
  }
  const raw = Buffer.concat(chunks).toString('utf8').trim();
  return raw ? JSON.parse(raw) : {};
}

async function runWorkerMode() {
  process.stdin.setEncoding('utf8');
  process.stdout.write(`${JSON.stringify({ type: 'ready', ok: true })}\n`);

  let buffer = '';
  let queue = Promise.resolve();

  const dispatchRequest = (payload) => {
    queue = queue
      .catch(() => undefined)
      .then(async () => {
        try {
          const response = await handleRequest(payload);
          process.stdout.write(`${JSON.stringify(response)}\n`);
        } catch (error) {
          process.stdout.write(
            `${JSON.stringify({
              ok: false,
              id:
                Object.prototype.hasOwnProperty.call(payload || {}, 'id')
                  ? payload.id
                  : null,
              error: error?.message || String(error),
              stack: error?.stack || '',
            })}\n`,
          );
        }
      });
  };

  process.stdin.on('data', (chunk) => {
    buffer += chunk;
    let newlineIndex = buffer.indexOf('\n');
    while (newlineIndex >= 0) {
      const rawLine = buffer.slice(0, newlineIndex).trim();
      buffer = buffer.slice(newlineIndex + 1);
      if (rawLine) {
        try {
          dispatchRequest(JSON.parse(rawLine));
        } catch (error) {
          process.stdout.write(
            `${JSON.stringify({
              ok: false,
              id: null,
              error: error?.message || String(error),
              stack: error?.stack || '',
            })}\n`,
          );
        }
      }
      newlineIndex = buffer.indexOf('\n');
    }
  });
}

async function runOneShotMode() {
  const payload = await readStdinJson();
  const response = await handleRequest(payload);
  process.stdout.write(JSON.stringify(response));
}

const isWorkerMode = process.argv.includes('--worker');

if (isWorkerMode) {
  runWorkerMode().catch((error) => {
    process.stdout.write(
      `${JSON.stringify({
        ok: false,
        id: null,
        error: error?.message || String(error),
        stack: error?.stack || '',
      })}\n`,
    );
    process.exitCode = 1;
  });
} else {
  const processKeepAlive = setInterval(() => {}, 1000);
  runOneShotMode()
    .then(() => {
      clearInterval(processKeepAlive);
    })
    .catch((error) => {
      clearInterval(processKeepAlive);
      process.stdout.write(
        JSON.stringify({
          ok: false,
          error: error?.message || String(error),
          stack: error?.stack || '',
        }),
      );
      process.exitCode = 1;
    });
}
