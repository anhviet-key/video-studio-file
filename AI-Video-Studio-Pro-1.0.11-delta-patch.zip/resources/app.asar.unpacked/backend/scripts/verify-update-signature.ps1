param([Parameter(Mandatory=$true)][string]$FilePath)
$ErrorActionPreference = 'Stop'
try {
  if ((Get-AuthenticodeSignature -LiteralPath $FilePath).Status -eq 'Valid') { exit 0 }
} catch { }
exit 1
