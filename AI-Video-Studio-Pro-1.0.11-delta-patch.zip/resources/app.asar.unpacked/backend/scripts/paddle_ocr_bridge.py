import argparse
import json
import os
import sys
import traceback

os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK", "True")
os.environ["FLAGS_use_onednn"] = "0"
os.environ["FLAGS_allocator_strategy"] = "auto_growth"

if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")


def emit(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def build_engine(language="multilingual"):
    from paddleocr import PaddleOCR

    normalized_language = str(language or "multilingual").strip().lower()
    # This recognizer covers Chinese/English/Japanese, NOT the full Vietnamese
    # alphabet. The backend routes explicit Vietnamese scans to its dedicated
    # Vietnamese LSTM worker; do not claim universal language support here.
    recognition_model = (
        "en_PP-OCRv5_mobile_rec"
        if normalized_language == "eng-strict"
        else "PP-OCRv5_mobile_rec"
    )

    return PaddleOCR(
        device="cpu",
        cpu_threads=max(1, min(4, os.cpu_count() or 1)),
        ocr_version="PP-OCRv5",
        # Subtitle bands are a constrained, high-contrast OCR workload.  The
        # mobile PP-OCRv5 pair is dramatically lighter on CPU/RAM than the
        # server pair and is the only practical choice for long local videos.
        text_detection_model_name="PP-OCRv5_mobile_det",
        text_recognition_model_name=recognition_model,
        enable_mkldnn=False,
        text_det_thresh=0.25,
        text_det_box_thresh=0.45,
        text_det_unclip_ratio=1.8,
        use_doc_orientation_classify=False,
        use_doc_unwarping=False,
        use_textline_orientation=False,
    )


def unwrap_json(item):
    value = getattr(item, "json", item)
    if callable(value):
        value = value()
    if isinstance(value, str):
        value = json.loads(value)
    if isinstance(value, dict) and isinstance(value.get("res"), dict):
        return value["res"]
    return value if isinstance(value, dict) else {}


def normalize_box(poly):
    points = poly or []
    xs = []
    ys = []
    for point in points:
        if isinstance(point, (list, tuple)) and len(point) >= 2:
            try:
                xs.append(float(point[0]))
                ys.append(float(point[1]))
            except (TypeError, ValueError):
                pass
    if not xs or not ys:
        return {"x0": 0, "y0": 0, "x1": 0, "y1": 0}
    return {"x0": min(xs), "y0": min(ys), "x1": max(xs), "y1": max(ys)}


def recognize(engine, image_path):
    results = engine.predict(input=image_path)
    words = []
    for item in results:
        data = unwrap_json(item)
        texts = data.get("rec_texts") or []
        scores = data.get("rec_scores") or []
        polys = data.get("rec_polys") or data.get("dt_polys") or []
        for index, raw_text in enumerate(texts):
            text = str(raw_text or "").strip()
            if not text:
                continue
            try:
                confidence = float(scores[index]) if index < len(scores) else 0.0
            except (TypeError, ValueError):
                confidence = 0.0
            box = normalize_box(polys[index] if index < len(polys) else [])
            words.append({
                "text": text,
                "confidence": confidence,
                "x0": box["x0"],
                "y0": box["y0"],
                "x1": box["x1"],
                "y1": box["y1"],
            })
    # Sort words top-to-bottom, left-to-right
    if words:
        words.sort(key=lambda w: (round(w["y0"] / 12) * 12, w["x0"]))

    return {
        "text": " ".join(word["text"] for word in words),
        "confidence": (
            sum(word["confidence"] for word in words) / len(words) if words else 0.0
        ),
        "words": words,
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--language", default="multilingual")
    args = parser.parse_args()
    engine = build_engine(args.language)
    if args.prepare:
        # Initialization alone does not prove inference works on a clean machine.
        import tempfile
        from PIL import Image, ImageDraw, ImageFont
        fonts = [os.path.join(os.environ.get("SystemRoot", "C:\\Windows"), "Fonts", "arial.ttf"),
                 "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"]
        font = next((ImageFont.truetype(item, 36) for item in fonts if os.path.isfile(item)), ImageFont.load_default())
        image = Image.new("RGB", (400, 100), "white")
        ImageDraw.Draw(image).text((24, 24), "OCR READY", fill="black", font=font)
        with tempfile.TemporaryDirectory(prefix="ocr-probe-") as temporary:
            probe_path = os.path.join(temporary, "probe.png")
            image.save(probe_path)
            probe = recognize(engine, probe_path)
        if "".join(probe["text"].split()) != "OCRREADY":
            raise RuntimeError("OCR recognition readiness probe failed")
        emit({"ok": True, "prepared": True, "engine": "pp-ocrv5-mobile", "language": args.language, "probeText": probe["text"]})
        return

    emit({"ok": True, "ready": True, "engine": "pp-ocrv5-mobile", "language": args.language})
    for raw_line in sys.stdin:
        raw_line = raw_line.strip()
        if not raw_line:
            continue
        request_id = None
        try:
            payload = json.loads(raw_line)
            request_id = payload.get("id")
            action = str(payload.get("action") or "recognize").lower()
            if action == "shutdown":
                emit({"id": request_id, "ok": True, "shutdown": True})
                break
            image_path = str(payload.get("imagePath") or "")
            if not image_path or not os.path.isfile(image_path):
                raise FileNotFoundError("OCR image was not found.")
            emit({"id": request_id, "ok": True, "data": recognize(engine, image_path)})
        except Exception as error:
            emit({
                "id": request_id,
                "ok": False,
                "error": str(error),
                "trace": traceback.format_exc(limit=4),
            })


if __name__ == "__main__":
    main()
