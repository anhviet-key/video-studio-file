import argparse
import json
import os
import re
import sys

os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def srt_time(seconds):
    millis = max(0, int(round(float(seconds or 0) * 1000)))
    hours, millis = divmod(millis, 3600000)
    minutes, millis = divmod(millis, 60000)
    secs, millis = divmod(millis, 1000)
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def build_model():
    from funasr import AutoModel
    return AutoModel(
        model="funasr/paraformer-zh",
        hub="hf",
        vad_model="funasr/fsmn-vad",
        punc_model="funasr/ct-punc",
        device="cpu",
        disable_update=True,
    )


def normalize_sentences(result):
    entries = []
    for item in result if isinstance(result, list) else [result]:
        if not isinstance(item, dict):
            continue
        sentences = item.get("sentence_info") or item.get("sentence_timestamp") or []
        for sentence in sentences:
            if not isinstance(sentence, dict):
                continue
            text = str(sentence.get("text") or "").strip()
            if not text:
                continue
            start = float(sentence.get("start") or 0) / 1000.0
            end = float(sentence.get("end") or sentence.get("start") or 0) / 1000.0
            if end <= start:
                end = start + max(0.6, min(6.0, len(text) * 0.18))
            entries.append({"start": start, "end": end, "text": text})
    return entries


def write_srt(path, entries):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        for index, entry in enumerate(entries, 1):
            handle.write(
                f"{index}\n{srt_time(entry['start'])} --> {srt_time(entry['end'])}\n"
                f"{entry['text']}\n\n"
            )


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prepare", action="store_true")
    parser.add_argument("--audio")
    parser.add_argument("--srt")
    args = parser.parse_args()
    model = build_model()
    if args.prepare:
        print(json.dumps({"ok": True, "prepared": True, "engine": "paraformer-zh"}))
        return
    if not args.audio or not os.path.isfile(args.audio) or not args.srt:
        raise ValueError("--audio and --srt are required")
    result = model.generate(
        input=args.audio,
        cache={},
        batch_size_s=300,
        sentence_timestamp=True,
        use_itn=True,
    )
    entries = normalize_sentences(result)
    if not entries:
        raw_text = " ".join(
            str(item.get("text") or "").strip()
            for item in result if isinstance(item, dict)
        ).strip()
        if raw_text:
            entries = [{"start": 0.0, "end": max(1.0, len(raw_text) * 0.18), "text": raw_text}]
    write_srt(args.srt, entries)
    confidences = []
    for item in result if isinstance(result, list) else []:
        score = item.get("score") if isinstance(item, dict) else None
        if isinstance(score, (int, float)):
            confidences.append(float(score))
    print(json.dumps({
        "ok": True,
        "language": "zh",
        "engine": "paraformer-zh",
        "segmentsCount": len(entries),
        "transcriptText": "\n".join(entry["text"] for entry in entries),
        "srtPath": args.srt,
        "averageConfidence": sum(confidences) / len(confidences) if confidences else None,
    }, ensure_ascii=False))


if __name__ == "__main__":
    main()
