import json
import os
import sys
import traceback
import re

import numpy as np
import soundfile as sf

os.environ.setdefault("LOG_LEVEL", "ERROR")

# Hardware Scaling Profiles for TTS
HARDWARE_PROFILE = os.environ.get("AI_VIDEO_STUDIO_HARDWARE_PROFILE", "high").lower()

if HARDWARE_PROFILE == "low":
    DEFAULT_THREADS = "1"
    MAX_PHONEMES = 200
elif HARDWARE_PROFILE == "medium":
    DEFAULT_THREADS = "2"
    MAX_PHONEMES = 400
else:
    DEFAULT_THREADS = "4"
    MAX_PHONEMES = 600

KOKORO_THREAD_COUNT = max(
    1,
    int(
        os.environ.get(
            "AI_VIDEO_STUDIO_KOKORO_THREADS",
            os.environ.get("AI_VIDEO_STUDIO_TTS_THREADS", DEFAULT_THREADS),
        )
        or DEFAULT_THREADS
    ),
)
for thread_env_name in (
    "ORT_NUM_THREADS",
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ.setdefault(thread_env_name, str(KOKORO_THREAD_COUNT))

from kokoro_onnx import Kokoro

def get_best_onnx_providers():
    try:
        import onnxruntime as ort
        available = set(ort.get_available_providers())
        providers = []
        if 'CUDAExecutionProvider' in available:
            providers.append(('CUDAExecutionProvider', {
                'device_id': 0,
                'arena_extend_strategy': 'kNextPowerOfTwo',
            }))
        if 'ROCMExecutionProvider' in available:
            providers.append('ROCMExecutionProvider')
        if 'DmlExecutionProvider' in available:
            providers.append('DmlExecutionProvider')
        if 'CoreMLExecutionProvider' in available:
            providers.append('CoreMLExecutionProvider')
        if 'OpenVINOExecutionProvider' in available:
            providers.append('OpenVINOExecutionProvider')
        providers.append('CPUExecutionProvider')
        return providers
    except Exception:
        return None

def init_kokoro_model(model_path: str, voices_path: str):
    providers = get_best_onnx_providers()
    if providers:
        try:
            return Kokoro(model_path, voices_path, providers=providers)
        except Exception:
            pass
    return Kokoro(model_path, voices_path)

from kokoro_onnx.trim import trim as trim_audio

SAMPLE_RATE = 24000
SENTENCE_GAP_MS = 70
EDGE_FADE_MS = 8
MAX_SAFE_PHONEME_BATCH = max(
    150,
    min(800, int(os.environ.get("AI_VIDEO_STUDIO_KOKORO_MAX_PHONEMES", str(MAX_PHONEMES)) or str(MAX_PHONEMES))),
)


if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")


def sanitize_text(value):
    text = str(value or "")
    return text.encode("utf-16", "surrogatepass").decode("utf-16", "replace")


def normalize_kokoro_text(value):
    text = sanitize_text(value)
    text = (
        text.replace("{", " ")
        .replace("}", " ")
        .replace("[", " ")
        .replace("]", " ")
        .replace("(", " ")
        .replace(")", " ")
        .replace("?", ".")
        .replace("!", ".")
        .replace("\uFF1F", ".")
        .replace("\uFF01", ".")
        .replace(",", ";")
        .replace("\uFF0C", ";")
        .replace("\u3001", ";")
        .replace(":", ";")
        .replace("\"", " ")
        .replace("\u201C", " ")
        .replace("\u201D", " ")
        .replace("\u2018", " ")
        .replace("\u2019", "'")
        .replace("\u2013", " ")
        .replace("\u2014", " ")
        .replace("-", " ")
    )
    return " ".join(text.split())


def split_text_by_sentence_boundary(value):
    text = normalize_kokoro_text(value)
    if not text:
        return []

    # Improved context-aware chunking.
    # Split text intelligently while preserving context, not blindly on characters.
    # We use lookbehinds and lookaheads to split by sentence terminators that are followed by spaces.
    parts = []
    for part in re.split(r"(?<=[.!?。！？])\s+", text):
        part = part.strip()
        if part:
            parts.append(part)
    return parts or [text]


def split_phonemes_safe(phonemes: str, max_len: int = 480):
    phonemes = str(phonemes or "").strip()
    if not phonemes:
        return []
    if len(phonemes) <= max_len:
        return [phonemes]

    punctuation = set(".!?\u3002\uFF01\uFF1F")
    chunks = []
    cursor = 0
    while cursor < len(phonemes):
        end = min(cursor + max_len, len(phonemes))
        split_at = end
        while split_at > cursor + 32 and phonemes[split_at - 1] not in punctuation:
            split_at -= 1
        if split_at <= cursor + 32:
            split_at = end
        chunk = phonemes[cursor:split_at].strip()
        if chunk:
            chunks.append(chunk)
        cursor = split_at
    return chunks


def split_phoneme_chunk_for_retry(phonemes: str):
    text = str(phonemes or "").strip()
    if len(text) <= 2:
        return []

    midpoint = len(text) // 2
    best_index = -1
    best_distance = len(text)
    punctuation = set(".!?;,\u3002\uFF01\uFF1F")

    for index, char in enumerate(text):
        if index < 24 or len(text) - index < 24:
            continue
        if char in punctuation or char.isspace():
            distance = abs(index - midpoint)
            if distance < best_distance:
                best_index = index + 1
                best_distance = distance

    if best_index <= 0 or best_index >= len(text):
        best_index = midpoint

    left = text[:best_index].strip()
    right = text[best_index:].strip()
    if not left or not right or left == text or right == text:
        return []
    return [left, right]


def apply_edge_fade(audio, sample_rate: int = SAMPLE_RATE, fade_ms: int = EDGE_FADE_MS):
    audio = np.asarray(audio, dtype=np.float32).reshape(-1)
    if audio.size <= 8:
        return audio
    fade_len = min(int(sample_rate * fade_ms / 1000), audio.size // 3)
    if fade_len <= 1:
        return audio
    faded = audio.copy()
    fade_in = np.linspace(0.0, 1.0, fade_len, dtype=np.float32)
    fade_out = np.linspace(1.0, 0.0, fade_len, dtype=np.float32)
    faded[:fade_len] *= fade_in
    faded[-fade_len:] *= fade_out
    return faded


def clean_audio_array(audio):
    audio = np.asarray(audio, dtype=np.float32).reshape(-1)
    if audio.size == 0:
        return audio
    if not np.isfinite(audio).all():
        audio = np.nan_to_num(audio, nan=0.0, posinf=0.0, neginf=0.0).astype(
            np.float32,
            copy=False,
        )
    return audio


def is_usable_audio(audio, min_samples: int = 240):
    audio = np.asarray(audio, dtype=np.float32).reshape(-1)
    if audio.size < min_samples:
        return False
    finite = audio[np.isfinite(audio)]
    if finite.size < min_samples:
        return False
    # Avoid dropping quiet audio (Kokoro can produce valid low volume or pauses).
    # Only verify we have valid numerical data.
    return True


def finalize_audio(audio):
    audio = clean_audio_array(audio)
    if audio.size == 0:
        return audio
    peak = float(np.max(np.abs(audio))) if audio.size else 0.0
    if peak > 0.98:
        audio = audio * (0.98 / peak)
    return apply_edge_fade(audio)


def make_silence(ms: int = SENTENCE_GAP_MS, sample_rate: int = SAMPLE_RATE):
    samples = max(0, int(sample_rate * ms / 1000))
    return np.zeros(samples, dtype=np.float32)


def unique_speeds(*values):
    speeds = []
    for value in values:
        try:
            speed = float(value)
        except (TypeError, ValueError):
            continue
        if speed <= 0:
            continue
        if not any(abs(speed - existing) < 0.015 for existing in speeds):
            speeds.append(speed)
    return speeds


def build_clause_rescue_candidates(text: str):
    clean = " ".join(str(text or "").split())
    if len(clean) < 24:
        return []

    candidates = []

    def add(parts):
        normalized_parts = [part.strip() for part in parts if part and part.strip()]
        if len(normalized_parts) > 1 and " ".join(normalized_parts) != clean:
            candidates.append(normalized_parts)

    special_patterns = [
        (r"\s+and\s+suddenly\s+", "and suddenly"),
        (r"\s+and\s+then\s+", "and then"),
    ]
    for pattern, connector in special_patterns:
        match = re.search(pattern, clean, flags=re.IGNORECASE)
        if match and match.start() > 8 and len(clean) - match.end() > 8:
            add([clean[: match.start()], connector, clean[match.end() :]])

    connector_patterns = [
        r"\s+so\s+",
        r"\s+that\s+",
        r"\s+while\s+",
        r"\s+but\s+",
        r"\s+because\s+",
    ]
    for pattern in connector_patterns:
        match = re.search(pattern, clean, flags=re.IGNORECASE)
        if match and match.start() > 8 and len(clean) - match.start() > 14:
            add([clean[: match.start()], clean[match.start() :]])

    and_match = re.search(r"\s+and\s+", clean, flags=re.IGNORECASE)
    if and_match and and_match.start() > 8 and len(clean) - and_match.end() > 8:
        add([clean[: and_match.start()], "and", clean[and_match.end() :]])

    return candidates


def get_speed_array(session, speed: float):
    speed_input = next((item for item in session.get_inputs() if item.name == "speed"), None)
    speed_type = getattr(speed_input, "type", "tensor(float)") if speed_input else "tensor(float)"
    if speed_type == "tensor(int32)":
        return np.array([round(speed)], dtype=np.int32)
    if speed_type == "tensor(int64)":
        return np.array([round(speed)], dtype=np.int64)
    return np.array([float(speed)], dtype=np.float32)


def synthesize_text_chunk(kokoro: Kokoro, text: str, voice_style, speed: float, lang: str):
    phonemes = kokoro.tokenizer.phonemize(text, lang)
    if not str(phonemes or "").strip():
        raise ValueError("Kokoro ONNX could not phonemize a text chunk.")
    phoneme_batches = split_phonemes_safe(phonemes)
    if not phoneme_batches:
        raise ValueError("Kokoro ONNX produced no phoneme batches for a text chunk.")
    audio_chunks = []

    for batch in phoneme_batches:
        audio_part = synthesize_phoneme_batch_resilient(
            kokoro,
            batch,
            voice_style,
            speed,
        )
        if not is_usable_audio(audio_part):
            continue
        audio_chunks.append(audio_part)

    if not audio_chunks:
        return np.zeros(0, dtype=np.float32)
    return np.concatenate(audio_chunks).astype(np.float32, copy=False)


def synthesize_phoneme_batch_once(kokoro: Kokoro, phonemes: str, voice_style, speed: float):
    batch = str(phonemes or "").strip()
    if not batch:
        return np.zeros(0, dtype=np.float32)

    input_names = [item.name for item in kokoro.sess.get_inputs()]
    tokens = np.array(kokoro.tokenizer.tokenize(batch), dtype=np.int64)
    if len(tokens) <= 0:
        return np.zeros(0, dtype=np.float32)
    style = np.array(voice_style[len(tokens)], dtype=np.float32)
    padded_tokens = np.array([[0, *tokens.tolist(), 0]], dtype=np.int64)

    if "input_ids" in input_names:
        inputs = {
            "input_ids": padded_tokens,
            "style": style,
            "speed": get_speed_array(kokoro.sess, speed),
        }
    else:
        inputs = {
            "tokens": padded_tokens,
            "style": style,
            "speed": np.ones(1, dtype=np.float32) * float(speed),
        }

    audio_part = kokoro.sess.run(None, inputs)[0]
    audio_part, _ = trim_audio(audio_part)
    return finalize_audio(audio_part)


def synthesize_phoneme_batch_resilient(
    kokoro: Kokoro,
    phonemes: str,
    voice_style,
    speed: float,
    depth: int = 0,
):
    batch = str(phonemes or "").strip()
    if not batch:
        return np.zeros(0, dtype=np.float32)

    audio = synthesize_phoneme_batch_once(kokoro, batch, voice_style, speed)
    if is_usable_audio(audio):
        return audio

    if depth >= 5 or len(batch) < 36:
        for speed_candidate in unique_speeds(1.0, 0.9):
            audio = synthesize_phoneme_batch_once(kokoro, batch, voice_style, speed_candidate)
            if is_usable_audio(audio):
                return audio
        # If all retries failed to produce audio, return last generated buffer even if poor.
        # Fallback to silence only if the engine literally crashed and gave NaNs.
        return audio if audio is not None and audio.size > 0 else np.zeros(0, dtype=np.float32)

    parts = split_phoneme_chunk_for_retry(batch)
    if not parts:
        return np.zeros(0, dtype=np.float32)

    audio_chunks = []
    for part_index, part in enumerate(parts):
        audio_part = synthesize_phoneme_batch_resilient(
            kokoro,
            part,
            voice_style,
            speed,
            depth + 1,
        )
        if not is_usable_audio(audio_part):
            return np.zeros(0, dtype=np.float32)
        audio_chunks.append(audio_part)
        if part_index < len(parts) - 1:
            audio_chunks.append(make_silence(35))

    return finalize_audio(np.concatenate(audio_chunks).astype(np.float32, copy=False))


def synthesize_text_chunk_resilient(
    kokoro: Kokoro,
    text: str,
    voice_style,
    speed: float,
    lang: str,
    depth: int = 0,
):
    speed_candidates = unique_speeds(speed, 0.9, 1.0)
    for speed_candidate in speed_candidates:
        audio = synthesize_text_chunk(kokoro, text, voice_style, speed_candidate, lang)
        if audio.size > 0:
            return audio

    if depth >= 2:
        return np.zeros(0, dtype=np.float32)

    for clause_parts in build_clause_rescue_candidates(text):
        rescued_parts = []
        failed = False
        for part in clause_parts:
            audio = synthesize_text_chunk_resilient(
                kokoro,
                part,
                voice_style,
                speed,
                lang,
                depth + 1,
            )
            if audio.size == 0:
                failed = True
                break
            rescued_parts.append(audio)
            rescued_parts.append(make_silence(20))
        if not failed and rescued_parts:
            return np.concatenate(rescued_parts[:-1]).astype(np.float32, copy=False)

    return np.zeros(0, dtype=np.float32)


def create_audio(kokoro: Kokoro, text: str, voice_name: str, speed: float, lang: str):
    clean_text = normalize_kokoro_text(text)
    if not clean_text:
        raise ValueError("Kokoro ONNX received an empty text segment.")
    voice_style = kokoro.get_voice_style(voice_name)
    phonemes = kokoro.tokenizer.phonemize(clean_text, lang)
    if not str(phonemes or "").strip():
        raise ValueError("Kokoro ONNX could not phonemize the text segment.")
    phoneme_chunks = split_phonemes_safe(phonemes, max_len=MAX_SAFE_PHONEME_BATCH)
    if not phoneme_chunks:
        raise ValueError("Kokoro ONNX produced no phoneme batches for the text segment.")
    audio_chunks = []

    for chunk_index, phoneme_chunk in enumerate(phoneme_chunks):
        audio_part = synthesize_phoneme_batch_resilient(
            kokoro,
            phoneme_chunk,
            voice_style,
            speed,
        )
        if not is_usable_audio(audio_part):
            raise ValueError(
                f'Kokoro ONNX produced an empty waveform for voice "{voice_name}" on phoneme batch {chunk_index + 1}/{len(phoneme_chunks)}.'
            )
        audio_chunks.append(audio_part)
        if chunk_index < len(phoneme_chunks) - 1:
            audio_chunks.append(make_silence())

    if not audio_chunks:
        raise ValueError(
            f'Kokoro ONNX produced an empty waveform for voice "{voice_name}".'
        )
    audio = finalize_audio(np.concatenate(audio_chunks).astype(np.float32, copy=False))
    if audio.size == 0 or not np.isfinite(audio).any():
        raise ValueError(
            f'Kokoro ONNX produced an invalid waveform for voice "{voice_name}".'
        )
    return audio


def emit_json_line(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def handle_payload(kokoro: Kokoro, payload):
    action = payload.get("action")

    if action == "voices":
        return {
            "ok": True,
            "voices": kokoro.get_voices(),
            "count": len(kokoro.get_voices()),
        }

    if action != "synthesize":
        raise ValueError(f"Unsupported action: {action}")

    results = []
    for segment in payload.get("segments", []):
        output_path = segment["outputPath"]
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            if os.path.exists(output_path):
                try:
                    os.remove(output_path)
                except OSError:
                    pass
            audio = create_audio(
                kokoro,
                sanitize_text(segment.get("text", "")),
                str(segment.get("voice", "")),
                float(segment.get("speed", 1.0)),
                str(segment.get("lang", "en-us")),
            )
            sample_rate = 24000
            sf.write(output_path, audio, sample_rate)
            file_size = os.path.getsize(output_path) if os.path.exists(output_path) else 0
            if len(audio) <= 0 or file_size <= 64:
                raise ValueError(
                    f'Kokoro ONNX wrote an empty audio file for voice "{segment.get("voice", "")}".'
                )
            results.append(
                {
                    "outputPath": output_path,
                    "sampleRate": sample_rate,
                    "sampleCount": int(len(audio)),
                    "fileSize": int(file_size),
                }
            )
        except Exception as exc:
            results.append(
                {
                    "outputPath": output_path,
                    "sampleRate": 24000,
                    "sampleCount": 0,
                    "fileSize": 0,
                    "error": str(exc),
                }
            )

    return {"ok": True, "results": results}


def run_once():
    payload = json.load(sys.stdin)
    model_path = payload.get("modelPath")
    voices_path = payload.get("voicesPath")
    kokoro = init_kokoro_model(model_path, voices_path)
    json.dump(handle_payload(kokoro, payload), sys.stdout, ensure_ascii=False)


def run_worker(model_path: str, voices_path: str):
    kokoro = init_kokoro_model(model_path, voices_path)
    emit_json_line({"ok": True, "type": "ready", "voicesCount": len(kokoro.get_voices())})

    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue

        request_id = None
        try:
            payload = json.loads(line)
            request_id = payload.get("id")
            response = handle_payload(kokoro, payload)
            if request_id is not None:
                response["id"] = request_id
            emit_json_line(response)
        except Exception as exc:
            error_payload = {
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
            if request_id is not None:
                error_payload["id"] = request_id
            emit_json_line(error_payload)


def main():
    try:
        if "--worker" in sys.argv:
            worker_index = sys.argv.index("--worker")
            try:
                model_path = sys.argv[worker_index + 1]
                voices_path = sys.argv[worker_index + 2]
            except IndexError as exc:
                raise ValueError("Worker mode requires model and voices paths") from exc
            run_worker(model_path, voices_path)
            return

        run_once()
    except Exception as exc:
        json.dump(
            {
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            },
            sys.stdout,
            ensure_ascii=False,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
