import json
import os
import sys
import tempfile
import traceback
import builtins

import numpy as np
import soundfile as sf

from phonemizer import phonemize

PIPER_THREAD_COUNT = max(
    1,
    int(
        os.environ.get(
            "AI_VIDEO_STUDIO_PIPER_THREADS",
            os.environ.get("AI_VIDEO_STUDIO_TTS_THREADS", "4"),
        )
        or "4"
    ),
)
for thread_env_name in (
    "ORT_NUM_THREADS",
    "OMP_NUM_THREADS",
    "MKL_NUM_THREADS",
    "OPENBLAS_NUM_THREADS",
    "NUMEXPR_NUM_THREADS",
):
    os.environ.setdefault(thread_env_name, str(PIPER_THREAD_COUNT))

from piper_onnx import Piper


if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")


def sanitize_text(value):
    text = str(value or "")
    return text.encode("utf-16", "surrogatepass").decode("utf-16", "replace")


def emit_error(error_message):
    json.dump(
        {
            "ok": False,
            "error": error_message,
            "traceback": traceback.format_exc(),
        },
        sys.stdout,
        ensure_ascii=False,
    )
    sys.exit(1)


def emit_json_line(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def build_length_scale(speed):
    normalized_speed = float(speed or 1.0)
    normalized_speed = max(0.5, min(2.5, normalized_speed))
    return max(0.2, min(2.0, 1.0 / normalized_speed))


def create_utf8_config_copy(config_path):
    with open(config_path, "rb") as raw_file:
        raw_bytes = raw_file.read()

    decoded_text = None
    for encoding in ("utf-8-sig", "utf-8", "utf-16"):
        try:
            decoded_text = raw_bytes.decode(encoding)
            break
        except UnicodeDecodeError:
            continue

    if decoded_text is None:
        decoded_text = raw_bytes.decode("utf-8", errors="replace")

    temp_handle = tempfile.NamedTemporaryFile(
        mode="w",
        encoding="utf-8",
        suffix=".json",
        prefix="piper_cfg_",
        delete=False,
    )
    try:
        temp_handle.write(decoded_text)
        return temp_handle.name
    finally:
        temp_handle.close()


def get_espeak_voice(piper):
    espeak_cfg = piper.config.get("espeak") if isinstance(piper.config, dict) else {}
    voice = ""
    if isinstance(espeak_cfg, dict):
        voice = str(espeak_cfg.get("voice") or "").strip()
    return voice or "en-us"


def create_piper_runtime(model_path, config_path):
    normalized_config_path = create_utf8_config_copy(config_path)
    original_open = builtins.open

    def patched_open(file, mode="r", *args, **kwargs):
        normalized_target = os.path.abspath(normalized_config_path)
        normalized_file = os.path.abspath(str(file))
        if (
            normalized_file == normalized_target
            and "b" not in str(mode or "")
            and "encoding" not in kwargs
        ):
            kwargs["encoding"] = "utf-8"
        return original_open(file, mode, *args, **kwargs)

    builtins.open = patched_open
    try:
        return Piper(model_path, normalized_config_path)
    finally:
        builtins.open = original_open
        if normalized_config_path and os.path.exists(normalized_config_path):
            try:
                os.remove(normalized_config_path)
            except OSError:
                pass


def synthesize_segment(piper, segment):
    output_path = segment["outputPath"]
    os.makedirs(os.path.dirname(output_path), exist_ok=True)

    text = sanitize_text(segment.get("text", ""))
    speaker_id = segment.get("speakerId", "default")
    length_scale = build_length_scale(segment.get("speed", 1.0))

    if not text.strip():
        audio = np.zeros(int(piper.sample_rate * 0.15), dtype=np.float32)
    else:
        phoneme_text = phonemize(
            text,
            language=get_espeak_voice(piper),
            backend="espeak",
        )
        audio, _ = piper.create(
            phoneme_text,
            speaker_id=speaker_id,
            length_scale=length_scale,
            is_phonemes=True,
        )
        audio = np.asarray(audio, dtype=np.float32).reshape(-1)

    sf.write(output_path, audio, piper.sample_rate, subtype="PCM_16")
    return {
        "outputPath": output_path,
        "sampleRate": int(piper.sample_rate),
        "sampleCount": int(len(audio)),
        "speakerId": speaker_id,
    }


def handle_payload(piper, payload):
    action = payload.get("action", "synthesize")
    if action == "warm":
        return {"ok": True, "warmed": True, "sampleRate": int(piper.sample_rate)}
    if action != "synthesize":
        raise ValueError(f"Unsupported action: {action}")

    results = []
    for segment in payload.get("segments", []):
        results.append(synthesize_segment(piper, segment))
    return {"ok": True, "results": results}


def get_cached_piper(cache, payload):
    model_path = str(payload.get("modelPath") or "").strip()
    config_path = str(payload.get("configPath") or "").strip()
    if not model_path or not os.path.exists(model_path):
        raise FileNotFoundError(f"External Piper model was not found: {model_path}")
    if not config_path or not os.path.exists(config_path):
        raise FileNotFoundError(f"External Piper config was not found: {config_path}")

    cache_key = f"{os.path.abspath(model_path)}::{os.path.abspath(config_path)}"
    piper = cache.get(cache_key)
    if piper is None:
        piper = create_piper_runtime(model_path, config_path)
        cache[cache_key] = piper
    return piper


def run_once():
    payload = json.load(sys.stdin)
    piper = get_cached_piper({}, payload)
    json.dump(handle_payload(piper, payload), sys.stdout, ensure_ascii=False)


def run_worker():
    runtime_cache = {}
    emit_json_line({"ok": True, "type": "ready"})

    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue

        request_id = None
        try:
            payload = json.loads(line)
            request_id = payload.get("id")
            piper = get_cached_piper(runtime_cache, payload)
            response = handle_payload(piper, payload)
            if request_id is not None:
                response["id"] = request_id
            emit_json_line(response)
        except Exception as exc:
            error_payload = {
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
            if request_id is not None:
                error_payload["id"] = request_id
            emit_json_line(error_payload)


def main():
    try:
        if "--worker" in sys.argv:
            run_worker()
            return
        run_once()
    except Exception as exc:
        emit_error(str(exc))


if __name__ == "__main__":
    main()
