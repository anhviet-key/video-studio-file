import json
import math
import os
import re
import shutil
import subprocess
import sys
import traceback
from pathlib import Path

os.environ.setdefault("PYTHONUTF8", "1")
os.environ.setdefault("HF_HUB_DISABLE_XET", "1")

if hasattr(sys.stdin, "reconfigure"):
    sys.stdin.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8", errors="backslashreplace")

from faster_whisper import WhisperModel

def resolve_best_whisper_config():
    env_device = os.environ.get("AI_VIDEO_STUDIO_WHISPER_DEVICE")
    env_compute = os.environ.get("AI_VIDEO_STUDIO_WHISPER_COMPUTE")
    if env_device:
        return env_device, env_compute or ("float16" if env_device == "cuda" else "int8")
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda", "float16"
    except Exception:
        pass
    return "cpu", "int8"



DEFAULT_MODEL = str(os.environ.get("AI_VIDEO_STUDIO_WHISPER_MODEL", "base") or "base")
DEFAULT_DEVICE, DEFAULT_COMPUTE_TYPE_AUTO = resolve_best_whisper_config()
DEFAULT_COMPUTE_TYPE = str(os.environ.get("AI_VIDEO_STUDIO_WHISPER_COMPUTE", DEFAULT_COMPUTE_TYPE_AUTO) or DEFAULT_COMPUTE_TYPE_AUTO)
DEFAULT_THREADS = max(
    1, int(os.environ.get("AI_VIDEO_STUDIO_WHISPER_THREADS", "4") or "4")
)
DEFAULT_MAX_WORDS = 7
MAX_CHUNK_DURATION_SEC = 6.0
HARD_WORD_GAP_SEC = 2.0
MIN_WORD_DURATION_SEC = 0.08
MIN_SUBTITLE_DURATION_SEC = 0.60
OPTIMAL_SUBTITLE_DURATION_SEC = 0.84
SINGLE_LINE_MAX_CHARS = 38
MIN_SECONDS_PER_WORD = 0.16
NEAR_DUPLICATE_GAP_SEC = 0.35
OPTIMAL_INTER_SUBTITLE_GAP_SEC = 0.06
LONG_MEDIA_THRESHOLD_SEC = 4 * 60
# Keep long-form checkpoints small enough that the desktop can show useful
# progress and recover a partial SRT without waiting through a dense six-minute
# dialogue block. This does not change the decoded audio quality.
LONG_MEDIA_CHUNK_SEC = 2 * 60
LONG_MEDIA_OVERLAP_SEC = 2.0
WHISPER_SAMPLE_RATE = 16000
SYSTRAN_MODEL_PREFIX = "faster-whisper-"
STRONG_TRAILING_PUNCTUATION = re.compile(r"[.!?…\u3002\uFF01\uFF1F][\"'”’)\]}]*$")
CLAUSE_TRAILING_PUNCTUATION = re.compile(r"[,;:\uFF0C\u3001\uFF1B\uFF1A\-–—][\"'”’)\]}]*$")

NO_BREAK_AFTER_TITLES = {
    "mr.", "mrs.", "ms.", "dr.", "prof.", "st.", "sr.", "jr.",
    "ts.", "ths.", "gs.", "pgs.", "bs.", "ds.", "ks.",
    "bác", "cô", "chú", "anh", "chị", "em", "ông", "bà", "thầy",
}

NO_BREAK_AFTER_DETERMINERS = {
    "the", "a", "an", "this", "that", "these", "those",
    "những", "các", "mỗi", "từng", "cái", "con", "chiếc", "mọi",
}

CONJUNCTION_PREFIXES = {
    "và", "nhưng", "hoặc", "vì", "bởi vì", "cho nên", "do đó", "tuy nhiên",
    "nếu", "khi", "để", "mà", "rằng", "với", "trong khi", "mặc dù",
    "thì", "lại", "rồi", "song", "ngoài ra",
    "and", "but", "or", "because", "so", "that", "which", "when",
    "where", "although", "if", "while", "after", "before", "though",
    "unless", "since", "until", "with", "for", "to",
}

NUMBER_MEASURE_UNITS = {
    "kg", "g", "mg", "km", "m", "cm", "mm", "l", "ml",
    "%", "s", "giây", "phút", "h", "giờ", "ngày", "tháng", "năm",
    "đ", "vnđ", "vnd", "usd", "eur", "triệu", "tỷ", "k", "nghìn",
}


def sanitize_text(value):
    text = str(value or "")
    return text.encode("utf-16", "surrogatepass").decode("utf-16", "replace")


def emit_json_line(payload):
    sys.stdout.write(json.dumps(payload, ensure_ascii=False) + "\n")
    sys.stdout.flush()


def format_srt_time(value):
    total_ms = max(0, int(round(float(value or 0) * 1000)))
    hours = total_ms // 3600000
    minutes = (total_ms % 3600000) // 60000
    seconds = (total_ms % 60000) // 1000
    milliseconds = total_ms % 1000
    return f"{hours:02d}:{minutes:02d}:{seconds:02d},{milliseconds:03d}"


def get_hf_cache_root():
    return Path(os.environ.get("HF_HOME") or "").expanduser()


def get_cached_model_snapshot(model_name):
    raw_name = sanitize_text(model_name or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    if os.path.exists(raw_name):
        return raw_name

    hf_root = get_hf_cache_root()
    if not hf_root:
        return None

    if "/" in raw_name:
        repo_cache_name = "models--" + raw_name.replace("/", "--")
    elif raw_name in ("large-v3-turbo", "turbo"):
        repo_cache_name = "models--mobiuslabsgmbh--faster-whisper-large-v3-turbo"
    elif raw_name in ("large", "large-v3"):
        repo_cache_name = "models--Systran--faster-whisper-large-v3"
    else:
        repo_cache_name = f"models--Systran--{SYSTRAN_MODEL_PREFIX}{raw_name}"

    snapshots_dir = hf_root / repo_cache_name / "snapshots"
    if not snapshots_dir.exists():
        snapshots_dir = hf_root / "hub" / repo_cache_name / "snapshots"
        if not snapshots_dir.exists():
            return None

    snapshots = sorted(
        (item for item in snapshots_dir.iterdir() if item.is_dir()),
        key=lambda item: item.stat().st_mtime,
        reverse=True,
    )
    for snapshot in snapshots:
        if (snapshot / "model.bin").exists() and (snapshot / "config.json").exists():
            return str(snapshot)
    return None


def resolve_whisper_repo_id(model_name):
    raw_name = sanitize_text(model_name or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    if "/" in raw_name:
        return raw_name
    if raw_name in ("large-v3-turbo", "turbo"):
        return "mobiuslabsgmbh/faster-whisper-large-v3-turbo"
    if raw_name in ("large", "large-v3"):
        return "Systran/faster-whisper-large-v3"
    return f"Systran/{SYSTRAN_MODEL_PREFIX}{raw_name}"


def build_model(model_name=None, device=None, compute_type=None):
    raw_name = sanitize_text(model_name or DEFAULT_MODEL).strip() or DEFAULT_MODEL
    resolved_model = (
        get_cached_model_snapshot(raw_name)
        or resolve_whisper_repo_id(raw_name)
        or raw_name
        or DEFAULT_MODEL
    )
    use_local_only = os.path.exists(str(resolved_model))
    return WhisperModel(
        resolved_model,
        device=device or DEFAULT_DEVICE,
        compute_type=compute_type or DEFAULT_COMPUTE_TYPE,
        cpu_threads=DEFAULT_THREADS,
        download_root=os.environ.get("HF_HOME") or None,
        local_files_only=use_local_only,
    )


def should_use_word_chunking(language_code):
    normalized = str(language_code or "").lower()
    return not (normalized.startswith("ja") or normalized.startswith("zh"))


def normalize_match_text(value):
    return re.sub(r"[^\w]+", "", sanitize_text(value).casefold(), flags=re.UNICODE)


def flush_entry(
    entries,
    start_sec,
    end_sec,
    text,
    last_end_sec,
    word_count=None,
    confidence=None,
):
    normalized_text = sanitize_text(text).strip()
    if not normalized_text:
        return last_end_sec

    safe_start = max(0.0, float(start_sec or 0))
    safe_end = max(safe_start, float(end_sec or safe_start))
    previous_end = max(0.0, float(last_end_sec or 0))

    # Word alignment may overlap by a few milliseconds at Whisper window
    # boundaries. Trim the overlap, but never manufacture a tiny subtitle
    # after an entry that already contains the same time range.
    if safe_start < previous_end:
        if safe_end <= previous_end + 0.02:
            return previous_end
        safe_start = previous_end
    if safe_end - safe_start < MIN_WORD_DURATION_SEC:
        return previous_end

    entry = {
        "start": safe_start,
        "end": safe_end,
        "text": normalized_text,
    }
    if word_count is not None:
        entry["wordCount"] = max(1, int(word_count))
    if confidence is not None and math.isfinite(float(confidence)):
        entry["confidence"] = max(0.0, min(1.0, float(confidence)))
    entries.append(entry)
    return safe_end


def get_timed_words(segments):
    timed_words = []
    for segment_index, segment in enumerate(segments):
        for item in getattr(segment, "words", None) or []:
            token = sanitize_text(getattr(item, "word", ""))
            if not token.strip():
                continue

            fallback_start = float(getattr(segment, "start", 0.0) or 0.0)
            token_start = float(getattr(item, "start", fallback_start) or fallback_start)
            token_end = float(getattr(item, "end", token_start) or token_start)
            if not math.isfinite(token_start) or not math.isfinite(token_end):
                continue
            if token_end - token_start < MIN_WORD_DURATION_SEC:
                token_end = token_start + MIN_WORD_DURATION_SEC

            raw_probability = getattr(item, "probability", None)
            probability = None
            if raw_probability is not None:
                try:
                    probability = float(raw_probability)
                except (TypeError, ValueError):
                    probability = None

            timed_words.append(
                {
                    "token": token,
                    "start": max(0.0, token_start),
                    "end": max(0.0, token_end),
                    "confidence": probability,
                    "segmentIndex": segment_index,
                }
            )

    # Faster-Whisper normally emits ordered words. A stable sort also protects
    # the SRT against rare timestamp regressions at consecutive 30 s windows.
    return sorted(
        timed_words,
        key=lambda word: (word["start"], word["end"], word["segmentIndex"]),
    )


def join_word_tokens(words):
    text = "".join(word["token"] for word in words).strip()
    if text:
        return text
    return " ".join(word["token"].strip() for word in words).strip()


def flush_word_buffer(entries, words, last_end_sec):
    if not words:
        return last_end_sec
    confidences = [
        word["confidence"]
        for word in words
        if word.get("confidence") is not None
        and math.isfinite(float(word["confidence"]))
    ]
    confidence = sum(confidences) / len(confidences) if confidences else None
    return flush_entry(
        entries,
        words[0]["start"],
        words[-1]["end"],
        join_word_tokens(words),
        last_end_sec,
        word_count=len(words),
        confidence=confidence,
    )


def auto_break_subtitle_line(text, language="vi", max_chars=SINGLE_LINE_MAX_CHARS):
    cleaned = sanitize_text(text).strip()
    if not cleaned or len(cleaned) <= max_chars:
        return cleaned

    is_cjk = str(language or "").lower().startswith(("zh", "ja", "ko", "c", "j", "k"))
    if is_cjk:
        if len(cleaned) <= 22:
            return cleaned
        mid = len(cleaned) // 2
        best_cut = mid
        best_score = -9999
        for i in range(max(1, mid - 6), min(len(cleaned), mid + 7)):
            prev_char = cleaned[i - 1]
            score = -abs(i - mid) * 2
            if prev_char in ("。", "！", "？", ".", "!", "?"):
                score += 30
            elif prev_char in ("，", "、", "；", "：", ",", ";", ":"):
                score += 15
            if score > best_score:
                best_score = score
                best_cut = i
        return f"{cleaned[:best_cut]}\n{cleaned[best_cut:]}"

    words = cleaned.split()
    if len(words) <= 1:
        return cleaned

    total_len = len(cleaned)
    ideal_first_len = int(round(total_len * 0.46))  # Bottom-Heavy preference
    best_cut = -1
    best_score = -float("inf")

    cum_len = 0
    for i in range(len(words) - 1):
        cum_len += len(words[i]) + (1 if i > 0 else 0)
        line1_len = cum_len
        line2_len = total_len - line1_len - 1

        prev_word = words[i]
        next_word = words[i + 1]
        prev_clean = re.sub(r"^[^\w]+|[^\w]+$", "", prev_word.lower())
        next_clean = re.sub(r"^[^\w]+|[^\w]+$", "", next_word.lower())

        score = 0
        if STRONG_TRAILING_PUNCTUATION.search(prev_word):
            score += 30
        elif CLAUSE_TRAILING_PUNCTUATION.search(prev_word):
            score += 18
        if next_word.startswith(("-", "–")):
            score += 25
        if next_clean in CONJUNCTION_PREFIXES:
            score += 10
        if prev_clean in NO_BREAK_AFTER_TITLES or prev_word.lower() in NO_BREAK_AFTER_TITLES:
            score -= 60
        if re.match(r"^\d+([.,]\d+)*%?$", prev_word) and next_clean in NUMBER_MEASURE_UNITS:
            score -= 60
        if prev_clean in NO_BREAK_AFTER_DETERMINERS:
            score -= 20
        if i == len(words) - 2 and len(next_word) <= 4:
            score -= 25
        if i == 0 and len(prev_word) <= 3:
            score -= 20

        balance_penalty = abs(line1_len - ideal_first_len) * 1.25
        overhang_penalty = 0
        if line1_len > max_chars:
            overhang_penalty += (line1_len - max_chars) * 4.5
        if line2_len > max_chars:
            overhang_penalty += (line2_len - max_chars) * 4.5

        total_cut_score = score - balance_penalty - overhang_penalty
        if total_cut_score > best_score:
            best_score = total_cut_score
            best_cut = i + 1

    if best_cut <= 0 or best_cut >= len(words):
        return cleaned

    line1 = " ".join(words[:best_cut])
    line2 = " ".join(words[best_cut:])
    return f"{line1}\n{line2}"


def choose_balanced_cut(words, chunks_left, max_words):
    word_count = len(words)
    if chunks_left <= 1 or word_count <= max_words:
        return word_count

    minimum_cut = max(1, word_count - (chunks_left - 1) * max_words)
    maximum_cut = min(max_words, word_count - (chunks_left - 1))
    ideal_cut = word_count / chunks_left

    def cut_score(cut_index):
        previous_word = words[cut_index - 1]
        next_word = words[cut_index]
        prev_clean = re.sub(r"^[^\w]+|[^\w]+$", "", previous_word["token"].strip().lower())
        next_clean = re.sub(r"^[^\w]+|[^\w]+$", "", next_word["token"].strip().lower())
        gap = max(0.0, next_word["start"] - previous_word["end"])

        pause_bonus = min(0.75, gap)
        punct_bonus = (
            2.5
            if STRONG_TRAILING_PUNCTUATION.search(previous_word["token"].strip())
            else (1.2 if CLAUSE_TRAILING_PUNCTUATION.search(previous_word["token"].strip()) else 0.0)
        )
        conj_bonus = 0.8 if next_clean in CONJUNCTION_PREFIXES else 0.0
        no_break_penalty = 2.0 if prev_clean in NO_BREAK_AFTER_TITLES else 0.0

        return abs(cut_index - ideal_cut) - punct_bonus - pause_bonus - conj_bonus + no_break_penalty

    return min(range(minimum_cut, maximum_cut + 1), key=cut_score)


def split_continuous_word_group(words, max_words):
    if not words:
        return []
    duration = max(0.0, words[-1]["end"] - words[0]["start"])
    chunks_needed = max(
        1,
        math.ceil(len(words) / max_words),
        math.ceil(duration / MAX_CHUNK_DURATION_SEC),
    )
    if chunks_needed <= 1:
        return [words]

    chunks = []
    remaining = list(words)
    while remaining and chunks_needed > 1:
        cut_index = choose_balanced_cut(remaining, chunks_needed, max_words)
        chunks.append(remaining[:cut_index])
        remaining = remaining[cut_index:]
        chunks_needed -= 1
    if remaining:
        chunks.append(remaining)
    return chunks


def split_words_at_long_pauses(words):
    groups = []
    current_group = []
    for word in words:
        if current_group:
            gap = max(0.0, word["start"] - current_group[-1]["end"])
            if gap >= HARD_WORD_GAP_SEC:
                groups.append(current_group)
                current_group = []
        current_group.append(word)
    if current_group:
        groups.append(current_group)
    return groups


def build_word_chunk_entries(segment, max_words, last_end_sec=0.0):
    entries = []
    word_items = get_timed_words([segment])
    if not word_items:
        return entries, last_end_sec

    for pause_group in split_words_at_long_pauses(word_items):
        for chunk_words in split_continuous_word_group(pause_group, max_words):
            last_end_sec = flush_word_buffer(entries, chunk_words, last_end_sec)

    return entries, last_end_sec


def build_subtitle_entries(segments, detected_language, max_words):
    raw_entries = []
    last_end_sec = 0.0
    can_chunk_words = should_use_word_chunking(detected_language)

    if can_chunk_words:
        for segment in segments:
            word_entries, last_end_sec = build_word_chunk_entries(
                segment,
                max_words,
                last_end_sec,
            )
            if word_entries:
                raw_entries.extend(word_entries)
                continue
            last_end_sec = flush_entry(
                raw_entries,
                getattr(segment, "start", 0.0),
                getattr(segment, "end", 0.0),
                getattr(segment, "text", ""),
                last_end_sec,
            )

    # Non-space-delimited languages use Whisper's own segment boundaries. The
    # same fallback also handles engines or old models without word timestamps.
    if not raw_entries:
        for segment in segments:
            last_end_sec = flush_entry(
                raw_entries,
                getattr(segment, "start", 0.0),
                getattr(segment, "end", 0.0),
                getattr(segment, "text", ""),
                last_end_sec,
            )

    # Khử trùng lặp hậu kỳ và loại bỏ các mốc thời gian bị sụp đổ (duration < 0.08s)
    entries = []
    previous_entry = None

    for entry in raw_entries:
        text = str(entry.get("text", "")).strip()
        start = float(entry.get("start", 0.0))
        end = float(entry.get("end", 0.0))
        duration = end - start

        # 1. Skip collapsed alignment entries.
        if duration < 0.08:
            continue

        # Context-aware decoding can occasionally copy a phrase into a tiny
        # alignment window. Such text cannot be read or spoken in the assigned
        # time and is safer to omit than to expose a false timestamp.
        word_count = int(entry.get("wordCount") or 0)
        if (
            word_count >= 4
            and duration / word_count < MIN_SECONDS_PER_WORD
        ):
            continue

        clean_text = normalize_match_text(text)
        if not clean_text:
            continue

        # 2. Remove only immediate alignment duplicates. Do not globally remove
        # repeated lines: choruses, slogans, and intentional repetition are valid.
        if previous_entry:
            previous_clean_text = normalize_match_text(previous_entry["text"])
            entry_gap = start - float(previous_entry["end"])
            if (
                clean_text == previous_clean_text
                and entry_gap <= NEAR_DUPLICATE_GAP_SEC
            ):
                previous_entry["end"] = max(float(previous_entry["end"]), end)
                continue

            # Repair a one-word fragment produced exactly at a model/window
            # boundary without joining across a real pause or sentence break.
            previous_word_count = int(previous_entry.get("wordCount") or 0)
            current_word_count = int(entry.get("wordCount") or 0)
            combined_duration = end - float(previous_entry["start"])
            if (
                current_word_count == 1
                and previous_word_count > 0
                and previous_word_count + current_word_count <= max_words
                and entry_gap <= 0.12
                and combined_duration <= MAX_CHUNK_DURATION_SEC
                and not STRONG_TRAILING_PUNCTUATION.search(
                    str(previous_entry["text"]).strip()
                )
            ):
                previous_entry["text"] = (
                    f'{previous_entry["text"]} {entry["text"]}'.strip()
                )
                previous_entry["end"] = end
                previous_entry["wordCount"] = previous_word_count + 1
                continue

        entries.append(entry)
        previous_entry = entry

    # 3. Post-processing: Duration extension into silence gaps and AutoBreakLine formatting
    processed_entries = []
    for idx, item in enumerate(entries):
        start = float(item["start"])
        end = float(item["end"])
        duration = end - start

        next_start = float(entries[idx + 1]["start"]) if idx < len(entries) - 1 else float("inf")
        if duration < OPTIMAL_SUBTITLE_DURATION_SEC and next_start > end + OPTIMAL_INTER_SUBTITLE_GAP_SEC:
            max_possible_end = next_start - OPTIMAL_INTER_SUBTITLE_GAP_SEC
            end = min(max_possible_end, start + OPTIMAL_SUBTITLE_DURATION_SEC)

        # Enforce minimum gap with previous item
        if processed_entries:
            prev = processed_entries[-1]
            if start < prev["end"] + OPTIMAL_INTER_SUBTITLE_GAP_SEC:
                if prev["end"] - prev["start"] > MIN_SUBTITLE_DURATION_SEC:
                    prev["end"] = max(prev["start"] + 0.3, start - OPTIMAL_INTER_SUBTITLE_GAP_SEC)
                else:
                    start = prev["end"] + OPTIMAL_INTER_SUBTITLE_GAP_SEC
                    if end <= start:
                        end = start + 0.3

        formatted_text = auto_break_subtitle_line(item["text"], detected_language)
        item_copy = dict(item)
        item_copy["start"] = round(start, 3)
        item_copy["end"] = round(end, 3)
        item_copy["text"] = formatted_text
        processed_entries.append(item_copy)

    return processed_entries


def get_media_duration_sec(audio_path):
    try:
        import av

        with av.open(audio_path, mode="r", metadata_errors="ignore") as container:
            if container.duration is not None:
                return max(0.0, float(container.duration) / float(av.time_base))
            audio_stream = next(
                (stream for stream in container.streams if stream.type == "audio"),
                None,
            )
            if (
                audio_stream is not None
                and audio_stream.duration is not None
                and audio_stream.time_base is not None
            ):
                return max(
                    0.0,
                    float(audio_stream.duration * audio_stream.time_base),
                )
    except Exception:
        pass
    return 0.0


def resolve_ffmpeg_executable():
    configured = sanitize_text(
        os.environ.get("AI_VIDEO_STUDIO_FFMPEG_PATH", "")
    ).strip()
    if configured and os.path.isfile(configured):
        return configured
    return shutil.which("ffmpeg") or shutil.which("ffmpeg.exe") or ""


def decode_audio_chunk(audio_path, start_sec, duration_sec):
    ffmpeg_executable = resolve_ffmpeg_executable()
    if not ffmpeg_executable:
        raise RuntimeError(
            "FFmpeg is required for memory-safe transcription of long media."
        )

    command = [
        ffmpeg_executable,
        "-hide_banner",
        "-loglevel",
        "error",
        "-ss",
        f"{max(0.0, float(start_sec)):.3f}",
        "-t",
        f"{max(0.1, float(duration_sec)):.3f}",
        "-i",
        audio_path,
        "-vn",
        "-ac",
        "1",
        "-ar",
        str(WHISPER_SAMPLE_RATE),
        "-f",
        "f32le",
        "pipe:1",
    ]
    creation_flags = (
        getattr(subprocess, "CREATE_NO_WINDOW", 0)
        if os.name == "nt"
        else 0
    )
    result = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        creationflags=creation_flags,
    )
    if result.returncode != 0:
        error_text = result.stderr.decode("utf-8", errors="replace").strip()
        raise RuntimeError(error_text or "FFmpeg could not decode the audio chunk.")
    if not result.stdout:
        raise RuntimeError("FFmpeg returned an empty audio chunk.")

    import numpy as np

    return np.frombuffer(result.stdout, dtype="<f4").copy()


def write_srt_entries(output_path, entries, partial=False):
    target_path = f"{output_path}.partial" if partial else output_path
    output_directory = os.path.dirname(target_path)
    if output_directory:
        os.makedirs(output_directory, exist_ok=True)
    with open(target_path, "w", encoding="utf-8") as handle:
        for index, entry in enumerate(entries, start=1):
            handle.write(f"{index}\n")
            handle.write(
                f"{format_srt_time(entry['start'])} --> "
                f"{format_srt_time(entry['end'])}\n"
            )
            handle.write(f"{entry['text']}\n\n")
    return target_path


def build_transcribe_options(language, word_timestamps, vad_filter):
    vad_parameters = (
        dict(
            # Singing and speech over music are less speech-like than studio
            # narration. A moderately lower threshold avoids deleting whole
            # lyric lines while the hallucination guard below handles silence.
            threshold=0.35,
            min_speech_duration_ms=160,
            max_speech_duration_s=float("inf"),
            min_silence_duration_ms=500,
            speech_pad_ms=350,
        )
        if vad_filter
        else None
    )
    return {
        "language": language,
        "beam_size": 5,
        "best_of": 5,
        "word_timestamps": word_timestamps,
        "vad_filter": vad_filter,
        "vad_parameters": vad_parameters,
        # Keep linguistic context inside each bounded transcription job. Long
        # media is split below, which naturally resets stale context.
        "condition_on_previous_text": True,
        "prompt_reset_on_temperature": 0.5,
        # Repeated choruses are legitimate. A large repetition penalty corrupts
        # later occurrences, so rely on bounded context and post-processing.
        "repetition_penalty": 1.0,
        "no_speech_threshold": 0.6,
        "temperature": (0.0, 0.2, 0.4),
        "compression_ratio_threshold": 2.4,
        "log_prob_threshold": -1.0,
        "hallucination_silence_threshold": 1.5 if word_timestamps else None,
    }


def transcribe_long_audio(
    model,
    audio_path,
    srt_path,
    language,
    word_timestamps,
    vad_filter,
    max_words,
    duration_sec,
    progress_callback=None,
):
    entries = []
    partial_path = f"{srt_path}.partial"
    chunk_count = max(1, math.ceil(duration_sec / LONG_MEDIA_CHUNK_SEC))
    detected_language = language or "auto"
    duration_after_vad_sec = 0.0

    for chunk_index in range(chunk_count):
        core_start = chunk_index * LONG_MEDIA_CHUNK_SEC
        core_end = min(duration_sec, core_start + LONG_MEDIA_CHUNK_SEC)
        decode_start = max(0.0, core_start - LONG_MEDIA_OVERLAP_SEC)
        decode_end = min(duration_sec, core_end + LONG_MEDIA_OVERLAP_SEC)
        audio_chunk = decode_audio_chunk(
            audio_path,
            decode_start,
            decode_end - decode_start,
        )
        chunk_language = (
            detected_language
            if detected_language and detected_language != "auto"
            else language
        )
        options = build_transcribe_options(
            chunk_language,
            word_timestamps,
            vad_filter,
        )
        chunk_segments, info = model.transcribe(audio_chunk, **options)
        chunk_segments = list(chunk_segments)
        info_language = sanitize_text(getattr(info, "language", "")).strip()
        if info_language:
            detected_language = info_language
        duration_after_vad_sec += max(
            0.0,
            float(getattr(info, "duration_after_vad", 0.0) or 0.0),
        )
        local_entries = build_subtitle_entries(
            chunk_segments,
            detected_language,
            max_words,
        )

        for entry in local_entries:
            global_entry = dict(entry)
            global_entry["start"] = float(entry["start"]) + decode_start
            global_entry["end"] = float(entry["end"]) + decode_start
            midpoint = (global_entry["start"] + global_entry["end"]) / 2.0
            if midpoint < core_start - 0.001:
                continue
            if chunk_index < chunk_count - 1 and midpoint >= core_end:
                continue
            if entries and global_entry["start"] < float(entries[-1]["end"]):
                global_entry["start"] = float(entries[-1]["end"])
            if global_entry["end"] - global_entry["start"] < MIN_SUBTITLE_DURATION_SEC:
                continue
            entries.append(global_entry)

        write_srt_entries(srt_path, entries, partial=True)
        if progress_callback:
            progress_callback(
                {
                    "progress": round(((chunk_index + 1) / chunk_count) * 100, 1),
                    "chunk": chunk_index + 1,
                    "chunkCount": chunk_count,
                    "processedSeconds": core_end,
                    "durationSeconds": duration_sec,
                    "partialSrtPath": partial_path,
                }
            )

    os.replace(partial_path, srt_path)
    return entries, detected_language, duration_after_vad_sec, chunk_count


def transcribe_audio(model, payload, progress_callback=None):
    audio_path = sanitize_text(payload.get("audioPath", "")).strip()
    srt_path = sanitize_text(payload.get("srtPath", "")).strip()
    raw_language = sanitize_text(payload.get("language", "")).strip()
    # Nếu language là 'auto' hoặc rỗng -> truyền None để Faster-Whisper tự động nhận diện
    language = (
        None
        if not raw_language or raw_language.lower() in ("auto", "none", "null")
        else raw_language
    )
    word_timestamps = bool(payload.get("wordTimestamps", True))
    vad_filter = bool(payload.get("vadFilter", True))
    max_words = max(
        1,
        min(
            20,
            int(
                payload.get("maxWordsPerSubtitle", DEFAULT_MAX_WORDS)
                or DEFAULT_MAX_WORDS
            ),
        ),
    )

    if not audio_path:
        raise ValueError("audioPath is required")
    if not os.path.exists(audio_path):
        raise FileNotFoundError(f"Audio file was not found: {audio_path}")
    if not srt_path:
        raise ValueError("srtPath is required")

    source_duration_sec = get_media_duration_sec(audio_path)
    is_long_media = source_duration_sec >= LONG_MEDIA_THRESHOLD_SEC
    duration_after_vad_sec = 0.0
    chunks_processed = 1

    if is_long_media:
        (
            subtitle_entries,
            detected_language,
            duration_after_vad_sec,
            chunks_processed,
        ) = transcribe_long_audio(
            model,
            audio_path,
            srt_path,
            language,
            word_timestamps,
            vad_filter,
            max_words,
            source_duration_sec,
            progress_callback,
        )
    else:
        options = build_transcribe_options(
            language,
            word_timestamps,
            vad_filter,
        )
        segments, info = model.transcribe(audio_path, **options)
        segments = list(segments)
        detected_language = (
            sanitize_text(getattr(info, "language", "")).strip()
            or language
            or "auto"
        )
        if source_duration_sec <= 0:
            source_duration_sec = max(
                0.0,
                float(getattr(info, "duration", 0.0) or 0.0),
            )
        duration_after_vad_sec = max(
            0.0,
            float(getattr(info, "duration_after_vad", 0.0) or 0.0),
        )
        subtitle_entries = build_subtitle_entries(
            segments,
            detected_language,
            max_words,
        )
        partial_path = write_srt_entries(srt_path, subtitle_entries, partial=True)
        os.replace(partial_path, srt_path)

    transcript_text = "\n".join(
        entry["text"] for entry in subtitle_entries if entry.get("text")
    ).strip()

    return {
        "ok": True,
        "language": detected_language,
        "segmentsCount": len(subtitle_entries),
        "subtitles": subtitle_entries,
        "transcriptText": transcript_text,
        "srtPath": srt_path,
        "sourceDurationSeconds": round(source_duration_sec, 3),
        "durationAfterVadSeconds": round(duration_after_vad_sec, 3),
        "lastSubtitleEndSeconds": round(
            float(subtitle_entries[-1]["end"]) if subtitle_entries else 0.0,
            3,
        ),
        "chunked": is_long_media,
        "chunksProcessed": chunks_processed,
        "partialSrtPath": "",
    }


def handle_payload(model, payload, progress_callback=None):
    action = payload.get("action", "transcribe")
    if action != "transcribe":
        raise ValueError(f"Unsupported action: {action}")
    return transcribe_audio(model, payload, progress_callback)


def run_once():
    payload = json.load(sys.stdin)
    model = build_model()
    json.dump(handle_payload(model, payload), sys.stdout, ensure_ascii=False)


def run_worker(model_name, device, compute_type):
    model = build_model(model_name, device, compute_type)
    emit_json_line(
        {
            "ok": True,
            "type": "ready",
            "model": model_name or DEFAULT_MODEL,
            "device": device or DEFAULT_DEVICE,
            "computeType": compute_type or DEFAULT_COMPUTE_TYPE,
        }
    )

    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue

        request_id = None
        try:
            payload = json.loads(line)
            request_id = payload.get("id")
            def report_progress(progress):
                if request_id is None:
                    return
                emit_json_line(
                    {
                        "ok": True,
                        "type": "progress",
                        "id": request_id,
                        **progress,
                    }
                )

            response = handle_payload(model, payload, report_progress)
            if request_id is not None:
                response["id"] = request_id
            emit_json_line(response)
        except Exception as exc:
            error_payload = {
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            }
            if request_id is not None:
                error_payload["id"] = request_id
            emit_json_line(error_payload)


def main():
    try:
        if "--worker" in sys.argv:
            worker_index = sys.argv.index("--worker")
            model_name = sys.argv[worker_index + 1] if len(sys.argv) > worker_index + 1 else DEFAULT_MODEL
            device = sys.argv[worker_index + 2] if len(sys.argv) > worker_index + 2 else DEFAULT_DEVICE
            compute_type = (
                sys.argv[worker_index + 3]
                if len(sys.argv) > worker_index + 3
                else DEFAULT_COMPUTE_TYPE
            )
            run_worker(model_name, device, compute_type)
            return

        run_once()
    except Exception as exc:
        json.dump(
            {
                "ok": False,
                "error": str(exc),
                "traceback": traceback.format_exc(),
            },
            sys.stdout,
            ensure_ascii=False,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
