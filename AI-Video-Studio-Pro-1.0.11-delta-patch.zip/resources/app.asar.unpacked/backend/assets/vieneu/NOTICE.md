VieNeu v3 preset pack

The 25 upstream profiles are from pnnbao97/VieNeu-TTS, revision
bd0f88eb8de7d560753a6172ba9c868f309a101c. Preserve UPSTREAM-LICENSE.txt
and provenance.json when redistributing. No SDK/model version is changed.

Nhật Phong is an additional profile and reference sample supplied from the
application owner's existing VieNeu clone, with explicit authorization to
distribute it with this app (2026-10-14). The original private clone registry
is not modified or bundled. This permission does not cover other user clones.
