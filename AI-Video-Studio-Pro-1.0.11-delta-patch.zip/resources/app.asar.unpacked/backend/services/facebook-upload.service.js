async function readFacebookResponse(response, operation) {
  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = {};
  }
  if (!response.ok || payload?.error) {
    const detail =
      payload?.error?.message || payload?.error?.code || text || response.status;
    throw new Error(`Facebook ${operation} failed: ${detail}`);
  }
  return payload;
}

async function validateFacebookPageConnection(pageConfig = {}, fetchImpl = fetch) {
  const pageId = String(pageConfig.pageId || '').trim();
  const token = String(pageConfig.pageAccessToken || pageConfig.accessToken || '').trim();
  if (!pageId || !token) return { valid: false, error: 'Facebook Page is not connected.' };
  try {
    const version = String(process.env.META_GRAPH_API_VERSION || 'v23.0')
      .replace(/[^a-zA-Z0-9.]/g, '');
    const response = await fetchImpl(
      `https://graph.facebook.com/${version}/${encodeURIComponent(pageId)}?fields=id,name`,
      { headers: { Authorization: `Bearer ${token}` }, signal: AbortSignal.timeout(12000) },
    );
    const data = await readFacebookResponse(response, 'account validation');
    if (String(data.id || '') !== pageId) {
      return { valid: false, error: 'Facebook returned a different Page identity.' };
    }
    return { valid: true, pageId, pageName: String(data.name || pageConfig.pageName || '').trim() };
  } catch (error) {
    return { valid: false, error: error.message || 'Facebook Page access could not be verified.' };
  }
}

function createFacebookUploader({
  fs,
  fetchImpl = fetch,
  getFacebookPageConfig = () => ({}),
}) {
  return async function uploadToFacebook(
    videoPath,
    thumbPath,
    metadata = {},
    appUserId = 'default',
    currentJob = {},
    abortSignal = null,
  ) {
    const config = currentJob?.config || {};
    const privacy = String(config.facebookPrivacy || metadata.facebookPrivacy || 'public').toLowerCase();
    if (privacy !== 'public') {
      throw new Error('Facebook Page Reels private publishing is not supported. Upload stopped before sending video data.');
    }
    const targetFormat = String(config.facebookFormat || 'reels').toLowerCase();
    if (targetFormat !== 'reels') {
      throw new Error(
        'Only Facebook Reels publishing is currently supported. Choose Reels in the Facebook API tab.',
      );
    }
    if (!fs.existsSync(videoPath)) {
      throw new Error(`Video file missing at path: ${videoPath}`);
    }

    const pageConfig = getFacebookPageConfig(appUserId) || {};
    const pageId = String(
      pageConfig?.pageId || process.env.FB_PAGE_ID || '',
    ).trim();
    const pageAccessToken = String(
      pageConfig?.pageAccessToken ||
        pageConfig?.accessToken ||
        process.env.FB_PAGE_ACCESS_TOKEN ||
        '',
    ).trim();
    if (!pageId || !pageAccessToken) {
      throw new Error(
        'Facebook Page is not connected. Add a valid Page ID and Page access token in the Facebook API tab.',
      );
    }
    const expectedPage = currentJob.publishTargets?.find((target) => target.platform === 'facebook')?.channelId;
    if (expectedPage && String(expectedPage) !== pageId) {
      throw new Error('The connected Facebook Page changed after this job was created. Upload stopped.');
    }

    const hashtags = String(config.facebookHashtags || '').trim();
    const titleText = String(metadata.title || 'AI Video Short').slice(0, 200);
    const descriptionText = String(metadata.description || '').slice(0, 5000);
    const aiDisclaimer = (config.facebookAiTag ?? true)
      ? 'This content was AI-assisted and may contain AI-generated voice or media. #AIgenerated'
      : '';
    const fullDescription = [descriptionText, hashtags, aiDisclaimer]
      .filter(Boolean)
      .join('\n')
      .slice(0, 5000)
      .trim();
    const graphVersion = String(
      process.env.META_GRAPH_API_VERSION || 'v23.0',
    ).replace(/[^a-zA-Z0-9.]/g, '');
    const reelsEndpoint =
      `https://graph.facebook.com/${graphVersion}/` +
      `${encodeURIComponent(pageId)}/video_reels`;

    currentJob.step = 'Starting Facebook Reels upload...';
    currentJob.log =
      (currentJob.log || '') +
      `[FACEBOOK] Starting Reels upload for Page ${pageId}.\n`;
    const startResponse = await fetchImpl(reelsEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: abortSignal,
      body: JSON.stringify({
        upload_phase: 'start',
        access_token: pageAccessToken,
      }),
    });
    const startData = await readFacebookResponse(startResponse, 'upload init');
    const videoId = String(startData?.video_id || '').trim();
    const uploadUrl = String(startData?.upload_url || '').trim();
    if (!videoId || !uploadUrl) {
      throw new Error(
        'Facebook upload init did not return a video ID and upload URL.',
      );
    }

    const videoSize = fs.statSync(videoPath).size; // Determine video size for upload header
    currentJob.step = 'Uploading video bytes to Facebook...';
    const uploadResponse = await fetchImpl(uploadUrl, {
      method: 'POST',
      headers: {
        Authorization: `OAuth ${pageAccessToken}`,
        Offset: '0',
        'File-Size': String(videoSize),
      },
      body: fs.createReadStream(videoPath),
      duplex: 'half',
      signal: abortSignal,
    });
    await readFacebookResponse(uploadResponse, 'video transfer');

    currentJob.step = 'Publishing Facebook Reel...';
    const publishResponse = await fetchImpl(reelsEndpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: abortSignal,
      body: JSON.stringify({
        upload_phase: 'finish',
        access_token: pageAccessToken,
        video_id: videoId,
        video_state: 'PUBLISHED',
        title: titleText,
        description: fullDescription || descriptionText,
      }),
    });
    const publishData = await readFacebookResponse(
      publishResponse,
      'publish phase',
    );
    if (publishData?.success !== true) {
      throw new Error(
        'Facebook did not confirm that the Reel publish request was accepted.',
      );
    }

    currentJob.facebookVideoId = videoId;
    currentJob.facebookPublishStatus = 'PUBLISH_SUBMITTED';
    currentJob.log +=
      `[FACEBOOK] Reels publish request accepted. Video ID: ${videoId}.\n`;
    return {
      confirmationId: videoId,
      status: 'submitted',
      pendingConfirmation: true,
      publishUrl: '',
      warning: 'Facebook accepted the publish request. Publication has not been independently confirmed; check the Page before retrying.',
    };
  };
}

module.exports = {
  createFacebookUploader,
  validateFacebookPageConnection,
};
