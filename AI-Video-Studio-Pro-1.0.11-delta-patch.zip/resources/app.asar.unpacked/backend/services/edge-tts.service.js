let edgeTtsRuntime = null;
let edgeTtsRuntimeError = null;

function getEdgeTtsRuntime() {
  if (edgeTtsRuntime) return edgeTtsRuntime;
  if (edgeTtsRuntimeError) return null;

  try {
    const runtime = require('msedge-tts');
    if (
      typeof runtime?.MsEdgeTTS !== 'function' ||
      !runtime?.OUTPUT_FORMAT?.AUDIO_24KHZ_48KBITRATE_MONO_MP3
    ) {
      throw new Error('The installed Edge TTS package does not expose the expected API.');
    }
    edgeTtsRuntime = runtime;
    return edgeTtsRuntime;
  } catch (error) {
    edgeTtsRuntimeError = error;
    console.warn(
      '[EDGE-TTS] Optional provider is unavailable. Core backend startup will continue:',
      error?.message || error,
    );
    return null;
  }
}

function getEdgeTtsRuntimeStatus() {
  const runtime = getEdgeTtsRuntime();
  return {
    available: Boolean(runtime),
    provider: 'microsoft-edge-tts',
    error: runtime
      ? ''
      : edgeTtsRuntimeError?.code === 'MODULE_NOT_FOUND'
        ? 'The optional Edge TTS provider is not installed.'
        : edgeTtsRuntimeError?.message || 'The optional Edge TTS provider is unavailable.',
  };
}

let cachedEdgeVoices = null;
let lastFetchTime = 0;

const POPULAR_VI_VOICES = [
  {
    id: 'edge_vi-VN-HoaiMyNeural',
    speaker: 'vi-VN-HoaiMyNeural',
    shortName: 'vi-VN-HoaiMyNeural',
    name: 'Hoài My (Nữ chuẩn Bắc)',
    gender: 'female',
    category: 'Popular',
    lang: 'vi',
    locale: 'vi-VN',
    description: 'Giọng đọc nữ tự nhiên, ngắt nghỉ câu chuẩn xác, rất được ưa chuộng cho video tin tức & tài liệu.',
    avatar: '🎙️',
  },
  {
    id: 'edge_vi-VN-NamMinhNeural',
    speaker: 'vi-VN-NamMinhNeural',
    shortName: 'vi-VN-NamMinhNeural',
    name: 'Nam Minh (Nam truyền cảm)',
    gender: 'male',
    category: 'Popular',
    lang: 'vi',
    locale: 'vi-VN',
    description: 'Giọng nam trầm ấm, phong cách phát thanh viên đài truyền hình, phù hợp phóng sự và review.',
    avatar: '🎬',
  },
];

function normalizeLangCode(locale = '') {
  const lower = String(locale).toLowerCase();
  if (lower.startsWith('vi')) return 'vi';
  if (lower === 'en-us') return 'en-us';
  if (lower === 'en-gb') return 'en-gb';
  if (lower.startsWith('en')) return 'en-us';
  if (lower.startsWith('ja')) return 'ja';
  if (lower.startsWith('ko')) return 'ko';
  if (lower.startsWith('zh')) return 'zh';
  if (lower.startsWith('fr')) return 'fr';
  if (lower.startsWith('de')) return 'de';
  if (lower.startsWith('es')) return 'es';
  if (lower.startsWith('it')) return 'it';
  if (lower.startsWith('ru')) return 'ru';
  if (lower.startsWith('pt')) return 'pt';
  if (lower.startsWith('th')) return 'th';
  if (lower.startsWith('id')) return 'id';
  return 'other';
}

function getAvatarForLang(lang = '') {
  switch (lang) {
    case 'vi': return '🇻🇳';
    case 'en-us': return '🇺🇸';
    case 'en-gb': return '🇬🇧';
    case 'ja': return '🇯🇵';
    case 'ko': return '🇰🇷';
    case 'zh': return '🇨🇳';
    case 'fr': return '🇫🇷';
    case 'de': return '🇩🇪';
    case 'es': return '🇪🇸';
    case 'it': return '🇮🇹';
    case 'ru': return '🇷🇺';
    case 'th': return '🇹🇭';
    default: return '🌐';
  }
}

// msedge-tts inserts input into an SSML document. Treat all user-provided text
// as text, never markup, so captions/scripts cannot alter the generated SSML.
function escapeXmlText(value = '') {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function collectAudioStream(audioStream) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    let settled = false;

    const finish = () => {
      if (settled) return;
      settled = true;
      resolve(Buffer.concat(chunks));
    };

    audioStream.on('data', (chunk) => chunks.push(Buffer.from(chunk)));
    audioStream.once('end', finish);
    audioStream.once('close', finish);
    audioStream.once('error', (error) => {
      if (settled) return;
      settled = true;
      reject(error);
    });
  });
}

// Bound the live catalogue fetch so a stalled network cannot hang the voices
// endpoint. Kept short: the fallback shortlist is good enough to render the UI,
// and a warm cache means this only runs on the first request.
const EDGE_TTS_VOICE_FETCH_TIMEOUT_MS = 6000;

async function getEdgeTtsVoices() {
  const now = Date.now();
  if (cachedEdgeVoices && now - lastFetchTime < 1000 * 60 * 60) {
    return cachedEdgeVoices;
  }

  const runtime = getEdgeTtsRuntime();
  if (!runtime) return POPULAR_VI_VOICES;

  const client = new runtime.MsEdgeTTS();
  try {
    // getVoices() reaches Microsoft's endpoint. Without a bound it can hang
    // indefinitely on a slow or filtered network, and a hung promise never
    // reaches the catch below, so the request just stalls. Race it against the
    // cached/shortlist instead of waiting forever for a list we already have a
    // usable fallback for.
    const rawVoices = await Promise.race([
      client.getVoices(),
      new Promise((resolve) => {
        const timer = setTimeout(() => {
          console.warn(
            `[EDGE-TTS] Voice list fetch exceeded ${EDGE_TTS_VOICE_FETCH_TIMEOUT_MS}ms, using defaults.`,
          );
          resolve(null);
        }, EDGE_TTS_VOICE_FETCH_TIMEOUT_MS);
        if (typeof timer.unref === 'function') timer.unref();
      }),
    ]);
    if (Array.isArray(rawVoices) && rawVoices.length > 0) {
      const normalized = rawVoices.map((v) => {
        const lang = normalizeLangCode(v.Locale);
        const isVi = lang === 'vi';
        const gender = (v.Gender || 'female').toLowerCase();
        
        let displayName = v.FriendlyName || v.ShortName;
        if (displayName.includes('Microsoft ') && displayName.includes(' Online')) {
          const match = displayName.match(/Microsoft\s+([A-Za-z0-9]+)\s+Online/);
          if (match) {
            displayName = `${match[1]} (${v.LocaleName || v.Locale})`;
          }
        }

        return {
          id: `edge_${v.ShortName}`,
          speaker: v.ShortName,
          shortName: v.ShortName,
          name: isVi ? (v.ShortName.includes('HoaiMy') ? 'Hoài My (Nữ chuẩn Bắc)' : 'Nam Minh (Nam truyền cảm)') : displayName,
          gender,
          category: isVi ? 'Popular' : 'Microsoft Neural',
          lang,
          locale: v.Locale,
          localeName: v.LocaleName,
          description: `${v.LocaleName || v.Locale} • Giọng đọc Neural tự nhiên chất lượng cao từ Microsoft.`,
          avatar: getAvatarForLang(lang),
        };
      });

      // Sort: Vietnamese first, then English, then others
      normalized.sort((a, b) => {
        if (a.lang === 'vi' && b.lang !== 'vi') return -1;
        if (b.lang === 'vi' && a.lang !== 'vi') return 1;
        if (a.lang === 'en-us' && b.lang !== 'en-us') return -1;
        if (b.lang === 'en-us' && a.lang !== 'en-us') return 1;
        return a.name.localeCompare(b.name);
      });

      cachedEdgeVoices = normalized;
      lastFetchTime = now;
      return cachedEdgeVoices;
    }
  } catch (err) {
    console.warn('[EDGE-TTS] Failed to fetch live voice list, using defaults:', err.message);
  } finally {
    client.close();
  }

  return POPULAR_VI_VOICES;
}

async function synthesizeEdgeTTS({ text, voice = 'vi-VN-HoaiMyNeural', rate = '+0%', pitch = '+0Hz', volume = '+0%' }) {
  const cleanText = String(text || '').trim();
  if (!cleanText) {
    throw new Error('Text is required for Edge-TTS synthesis.');
  }

  const runtime = getEdgeTtsRuntime();
  if (!runtime) {
    const error = new Error(getEdgeTtsRuntimeStatus().error);
    error.code = 'EDGE_TTS_RUNTIME_UNAVAILABLE';
    throw error;
  }

  const rawVoice = String(voice || 'vi-VN-HoaiMyNeural').replace(/^edge_/, '');
  const client = new runtime.MsEdgeTTS();
  try {
    await client.setMetadata(
      rawVoice,
      runtime.OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3,
    );
    const { audioStream } = client.toStream(escapeXmlText(cleanText), {
      rate: String(rate || '+0%'),
      pitch: String(pitch || '+0Hz'),
      volume: String(volume || '+0%'),
    });
    const audioBuffer = await collectAudioStream(audioStream);

    if (audioBuffer.length === 0) {
      throw new Error('Edge-TTS returned empty audio stream.');
    }

    return {
      success: true,
      audioBuffer,
      format: 'mp3',
      provider: 'microsoft-edge-tts',
      speaker: rawVoice,
      sizeBytes: audioBuffer.length,
    };
  } finally {
    client.close();
  }
}

module.exports = {
  getEdgeTtsRuntimeStatus,
  getEdgeTtsVoices,
  synthesizeEdgeTTS,
  POPULAR_VI_VOICES,
  _test: { escapeXmlText },
};
