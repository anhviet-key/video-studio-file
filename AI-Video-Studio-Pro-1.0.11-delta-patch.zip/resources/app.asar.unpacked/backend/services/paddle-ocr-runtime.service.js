const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');
const { execFile } = require('node:child_process');
const execute = require('node:util').promisify(execFile);

// ocr-core only: document parsers/multimodal extras are not needed for subtitles.
const PACKAGES = Object.freeze(['paddlepaddle==3.3.1', 'paddleocr==3.7.0', 'paddlex[ocr-core]==3.7.2']);
const REVISION = 'pp-ocrv5-mobile-cpu-1';
const MODEL_NAMES = ['PP-OCRv5_mobile_det', 'PP-OCRv5_mobile_rec', 'en_PP-OCRv5_mobile_rec'];
const BRIDGE = path.join(__dirname, '..', 'scripts', 'paddle_ocr_bridge.py');
function getPaddleRuntimeRoot() {
  return path.join(process.env.AI_VIDEO_STUDIO_APP_DATA_DIR || path.join(
    process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'), 'AI Video Studio',
  ), 'runtime', 'ocr-python');
}
function getPaddlePythonExe(root = getPaddleRuntimeRoot()) {
  return process.env.LOCAL_RUNTIME_OCR_PYTHON_EXE || path.join(root, 'venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
}
function getPaddleEnv(root = getPaddleRuntimeRoot()) {
  return { ...process.env, PYTHONUTF8: '1', FLAGS_use_onednn: '0',
    PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK: 'True',
    PADDLE_PDX_CACHE_HOME: path.join(root, 'models'),
    HF_HOME: path.join(root, 'hf-cache'),
  };
}
function markerPath(root) { return path.join(root, '.pp-ocrv5-mobile-ready.json'); }
function bridgeHash() { return crypto.createHash('sha256').update(fs.readFileSync(BRIDGE)).digest('hex'); }
function modelFiles(root) {
  return MODEL_NAMES.flatMap(name => ['inference.json', 'inference.pdiparams', 'inference.yml'].map(file => {
    const relative = path.join('models', 'official_models', name, file);
    const stat = fs.statSync(path.join(root, relative));
    if (!stat.isFile() || stat.size < 1) throw new Error(`OCR model file is missing: ${name}/${file}`);
    return { relative, bytes: stat.size, mtimeMs: stat.mtimeMs };
  }));
}
function isPaddleOcrAvailable(root = getPaddleRuntimeRoot()) {
  try {
    const marker = JSON.parse(fs.readFileSync(markerPath(root), 'utf8'));
    return fs.existsSync(getPaddlePythonExe(root)) && marker.revision === REVISION &&
      marker.bridgeSha256 === bridgeHash() && marker.languages?.includes('eng-strict') &&
      marker.languages?.includes('multilingual') &&
      JSON.stringify(marker.files) === JSON.stringify(modelFiles(root));
  } catch { return false; }
}

function createPaddleOcrRuntime({ runtimeRoot = getPaddleRuntimeRoot(), ensureVenv, installPackages,
  ensurePrerequisites = async () => {}, exec = execute, minimumFreeBytes = 3 * 1024 ** 3 } = {}) {
  let pending = null;
  let state = { isDownloading: false, downloadProgress: 0, downloadStep: '', downloadError: '' };
  const update = (downloadProgress, downloadStep) => { state = { ...state, downloadProgress, downloadStep }; };
  const status = () => {
    const isReady = isPaddleOcrAvailable(runtimeRoot);
    return { ...state, isReady, downloadProgress: isReady ? 100 : state.downloadProgress };
  };
  function start() {
    if (pending || isPaddleOcrAvailable(runtimeRoot)) return status();
    state = { isDownloading: true, downloadProgress: 2, downloadStep: 'Preparing OCR runtime', downloadError: '' };
    pending = (async () => {
      if (!ensureVenv || !installPackages) throw new Error('OCR runtime installer is unavailable. Please update the application.');
      fs.mkdirSync(runtimeRoot, { recursive: true });
      const disk = fs.statfsSync(runtimeRoot);
      if (disk.bavail * disk.bsize < minimumFreeBytes) {
        throw new Error('Not enough free disk space to install OCR. Free at least 3 GB on the application data drive and retry.');
      }
      await ensurePrerequisites();
      const python = getPaddlePythonExe(runtimeRoot);
      const env = getPaddleEnv(runtimeRoot);
      if (!fs.existsSync(python)) {
        update(8, 'Creating isolated OCR Python environment');
        await ensureVenv(path.join(runtimeRoot, 'venv'), { timeout: 5 * 60_000, env });
      }
      update(18, 'Installing CPU OCR dependencies');
      const versionProbe = 'from importlib.metadata import version; assert version("paddlepaddle")=="3.3.1"; assert version("paddleocr")=="3.7.0"; assert version("paddlex")=="3.7.2"; import paddle; from paddleocr import PaddleOCR';
      try { await exec(python, ['-c', versionProbe], { timeout: 60_000, windowsHide: true, env }); }
      catch {
        await installPackages(python, [...PACKAGES], { timeout: 30 * 60_000, env, forcePip: true });
        await exec(python, ['-c', versionProbe], { timeout: 60_000, windowsHide: true, env });
      }
      const languages = [];
      for (const language of ['multilingual', 'eng-strict']) {
        update(languages.length ? 75 : 40, `Downloading and testing OCR models (${language})`);
        const result = await exec(python, [BRIDGE, '--prepare', '--language', language], {
          encoding: 'utf8', windowsHide: true, timeout: 15 * 60_000, maxBuffer: 4 * 1024 * 1024, env,
        });
        const payload = JSON.parse(String(result.stdout || '').trim().split(/\r?\n/).at(-1));
        if (payload.ok !== true || payload.prepared !== true || payload.probeText?.replace(/\s/g, '') !== 'OCRREADY') {
          throw new Error(`OCR recognition probe failed (${language}); the model was not marked ready.`);
        }
        languages.push(language);
      }
      const marker = { revision: REVISION, engine: 'pp-ocrv5-mobile', languages,
        bridgeSha256: bridgeHash(), files: modelFiles(runtimeRoot), preparedAt: new Date().toISOString() };
      const temporary = `${markerPath(runtimeRoot)}.${crypto.randomUUID()}.tmp`;
      try {
        fs.writeFileSync(temporary, JSON.stringify(marker), { flag: 'wx' });
        fs.renameSync(temporary, markerPath(runtimeRoot));
      } finally { try { fs.unlinkSync(temporary); } catch {} }
      update(100, 'OCR is ready');
    })().catch(error => {
      // Retain successfully downloaded files for a retry, but never a false-ready marker.
      try { fs.unlinkSync(markerPath(runtimeRoot)); } catch {}
      state.downloadError = String(error?.message || 'OCR preparation failed.').slice(-1200);
      state.downloadStep = 'OCR preparation failed; retry is available';
    }).finally(() => { state.isDownloading = false; pending = null; });
    return status();
  }
  return { start, status, wait: () => pending || Promise.resolve() };
}
module.exports = { createPaddleOcrRuntime, isPaddleOcrAvailable, getPaddlePythonExe, getPaddleEnv, getPaddleRuntimeRoot, PACKAGES };
