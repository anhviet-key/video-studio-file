/**
 * AI Image Generation Service (FLUX.1 / SDXL / Turbo)
 * Supports multiple free models via Pollinations.ai,
 * multilingual prompt translation & context-aware art optimization,
 * fast fallback image endpoints,
 * and saving generated images to local storage.
 */
const fs = require('fs');
const path = require('path');
const https = require('https');
const http = require('http');

/**
 * Available free AI image models via Pollinations.ai
 */
const AI_IMAGE_MODELS = {
  'flux': { label: 'FLUX.1 Schnell', pollinationsModel: 'flux', quality: 'high' },
  'flux-realism': { label: 'FLUX Realism', pollinationsModel: 'flux-realism', quality: 'high' },
  'flux-anime': { label: 'FLUX Anime', pollinationsModel: 'flux-anime', quality: 'high' },
  'flux-3d': { label: 'FLUX 3D', pollinationsModel: 'flux-3d', quality: 'high' },
  'flux-cablyai': { label: 'FLUX CablyAI', pollinationsModel: 'flux-cablyai', quality: 'high' },
  'turbo': { label: 'SDXL Turbo (Fast)', pollinationsModel: 'turbo', quality: 'fast' },
};

const DEFAULT_MODEL = 'flux';

function getStorageOutputDir() {
  if (process.env.APP_STORAGE_DIR) {
    const p = path.join(process.env.APP_STORAGE_DIR, 'outputs');
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
    return p;
  }
  const customDataDir = process.env.APP_DATA_DIR;
  if (customDataDir) {
    const p = path.join(customDataDir, 'storage', 'outputs');
    if (!fs.existsSync(p)) fs.mkdirSync(p, { recursive: true });
    return p;
  }
  const fallback = path.join(__dirname, '..', 'storage', 'outputs');
  if (!fs.existsSync(fallback)) fs.mkdirSync(fallback, { recursive: true });
  return fallback;
}

function downloadImage(url, destPath) {
  return new Promise((resolve, reject) => {
    const client = url.startsWith('https') ? https : http;
    const req = client.get(url, { headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' } }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        return downloadImage(res.headers.location, destPath).then(resolve).catch(reject);
      }
      if (res.statusCode !== 200) {
        return reject(new Error(`Failed to download image, status code: ${res.statusCode}`));
      }
      const fileStream = fs.createWriteStream(destPath);
      res.pipe(fileStream);
      fileStream.on('finish', () => {
        fileStream.close();
        resolve(destPath);
      });
      fileStream.on('error', reject);
    });
    req.on('error', reject);
    req.setTimeout(45000, () => {
      req.destroy();
      reject(new Error('Image generation request timeout'));
    });
  });
}

/**
 * Smart multilingual visual concept mapping & English prompt translation.
 * Translates/detects core themes from Vietnamese, English, Japanese, Korean, French, German, Spanish, etc.
 * into professional, high-end English AI art generation prompts.
 */
function buildScenePrompt(rawText, style = 'cinematic') {
  const textStr = String(rawText || '').trim();
  let themeSnippet = 'cinematic scenery background';

  // Multilingual keyword patterns
  const isCostaRica = /costa rica|rainforest|waterfall|ceviche|jungle/i.test(textStr);
  const isHolidayTravel = /holiday|vacation|adventure|culture|travel|explore|destination|resort|du lịch|kỳ nghỉ|thám hiểm|văn hóa|nghỉ dưỡng/i.test(textStr);
  const isWaterfallNature = /waterfall|river|stream|cascade|thác nước|dòng sông|suối/i.test(textStr);
  const isFoodCulinary = /food|ceviche|cuisine|dish|delicious|fresh|món ăn|ẩm thực|đặc sản/i.test(textStr);

  const isSports = /sport|athlete|stadium|olympic|championship|thể thao|vận động viên|sân vận động|スポーツ|競技|選手|スタジアム|스포츠|경기장|선수|athlète|stade|deporte|estadio/i.test(textStr);
  const isTech = /tech|ai|robot|cyber|future|code|công nghệ|trí tuệ nhân tạo|技術|ロボット|人工知能|AI|기술|인공지능|로봇|technologie|tecnología/i.test(textStr);
  const isSunset = /sunset|golden hour|dusk|hoàng hôn|nắng chiều|夕日|夕焼け|일몰|석양|coucher de soleil|atardecer/i.test(textStr);
  const isSunrise = /sunrise|morning|dawn|bình minh|sáng sớm|朝日|朝|일출|아침|lever du soleil|amanecer/i.test(textStr);
  const isRain = /rain|storm|wet|mưa|bão|雨|嵐|비|폭풍|pluie|lluvia/i.test(textStr);
  const isNight = /night|star|moon|dark|đêm|trăng|sao|夜|月|星|밤|달|별|nuit|noche/i.test(textStr);
  const isOcean = /ocean|beach|sea|water|wave|biển|sóng|đảo|海|ビーチ|海岸|바다|해변|océan|mar/i.test(textStr);
  const isMountain = /mountain|forest|nature|tree|núi|rừng|cây|山|森|自然|산|숲|자연|montagne|forêt/i.test(textStr);
  const isCity = /city|street|urban|building|phố|thành phố|xe|街|都市|通り|도시|거리|ville|ciudad/i.test(textStr);
  const isOffice = /office|desk|workspace|work|văn phòng|bàn làm việc|học|オフィス|デスク|오피스|사무실|bureau|oficina/i.test(textStr);

  if (isCostaRica) {
    themeSnippet = 'exotic tropical Costa Rica rainforest, lush jungle greenery, breathtaking waterfall, serene nature paradise, peaceful holiday destination';
  } else if (isWaterfallNature) {
    themeSnippet = 'breathtaking tropical waterfall cascading over lush jungle rocks, mist atmosphere, serene mountain rainforest';
  } else if (isFoodCulinary) {
    themeSnippet = 'gourmet fresh seafood ceviche dish, beautifully presented tropical culinary dining experience, aesthetic restaurant background';
  } else if (isHolidayTravel) {
    themeSnippet = 'scenic tropical resort holiday destination, traveler exploring exotic ancient landmarks, vibrant local cultural atmosphere';
  } else if (isSports) {
    themeSnippet = 'futuristic modern sports stadium, world class athletes competing, energetic stadium lighting, championship atmosphere';
  } else if (isTech) {
    themeSnippet = 'futuristic high tech artificial intelligence laboratory, glowing holograms, cyberpunk data streams, advanced technology';
  } else if (isSunset) {
    themeSnippet = 'peaceful sunset golden hour, warm sunlight fading over horizon, serene scenic landscape';
  } else if (isSunrise) {
    themeSnippet = 'fresh morning sunrise, soft golden sunlight, morning fog over beautiful scenery';
  } else if (isRain) {
    themeSnippet = 'moody rainy atmosphere, wet reflective streets, cinematic storm lighting';
  } else if (isNight) {
    themeSnippet = 'peaceful starry night sky, full moon light atmosphere, dramatic dark blue ambiance';
  } else if (isOcean) {
    themeSnippet = 'breathtaking ocean beach, turquoise crystal water, coastal nature scenery';
  } else if (isMountain) {
    themeSnippet = 'lush green forest mountain peak, dramatic nature landscape, atmospheric fog';
  } else if (isCity) {
    themeSnippet = 'modern city street aesthetic, cozy urban skyline atmosphere, detailed architecture';
  } else if (isOffice) {
    themeSnippet = 'cozy modern workspace interior, warm ambient room lighting, aesthetic desk setup';
  } else {
    const cleaned = textStr
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[^\w\s,.-]/gi, ' ')
      .replace(/\s+/g, ' ')
      .trim();

    if (cleaned.length >= 3) {
      themeSnippet = `${cleaned.substring(0, 100)}, highly detailed visual scene`;
    } else {
      themeSnippet = 'breathtaking cinematic scenery, masterpiece wallpaper';
    }
  }

  const stylePrompts = {
    cinematic: `Cinematic 4K movie shot, 8k resolution, photorealistic, dramatic lighting, professional photography, ${themeSnippet}, detailed depth of field, masterpiece`,
    anime: `Beautiful anime illustration, Studio Ghibli style, detailed background, ${themeSnippet}, vibrant colors, dramatic sky, cel shading, masterpiece`,
    cyberpunk: `Cyberpunk futuristic scenery, neon lights, rain-soaked reflection, ${themeSnippet}, ultra detailed, volumetric fog, octane render`,
    '3d_render': `3D Pixar style animation render, soft studio lighting, cute detailed environment, ${themeSnippet}, octane render 8k`,
    fantasy: `Epic fantasy concept art, magical atmosphere, ethereal glow, ${themeSnippet}, digital matte painting, trending on artstation`,
    vintage: `Vintage 35mm film photograph, retro 1990s color grading, film grain, ${themeSnippet}, nostalgic aesthetic`,
    nature: `Breathtaking nature landscape, golden hour, dramatic clouds, ${themeSnippet}, National Geographic quality, 8K resolution`,
    minimal: `Minimalist design, clean composition, soft gradients, ${themeSnippet}, modern aesthetic, professional photography`,
  };

  return stylePrompts[style] || stylePrompts.cinematic;
}

async function generateSceneImage({ prompt, scriptText, model = DEFAULT_MODEL, style = 'cinematic', width = 1920, height = 1080 }) {
  const outputDir = getStorageOutputDir();
  const rawPrompt = String(prompt || scriptText || '').trim();

  // Build optimized prompt translated to descriptive English
  const scenePrompt = rawPrompt
    ? buildScenePrompt(rawPrompt, style)
    : 'Cinematic 4K wallpaper, dramatic lighting, professional photography, beautiful landscape, volumetric fog';

  const sanitizedPrompt = encodeURIComponent(
    scenePrompt
      .replace(/[^\w\s,.-]/gi, ' ')
      .replace(/\s+/g, ' ')
      .substring(0, 300)
      .trim() || 'cinematic wallpaper',
  );
  const filename = `scene_img_${Date.now()}_${Math.random().toString(36).substring(2, 8)}.jpg`;
  const destPath = path.join(outputDir, filename);

  const modelConfig = AI_IMAGE_MODELS[model] || AI_IMAGE_MODELS[DEFAULT_MODEL];
  const pollinationsModel = modelConfig ? modelConfig.pollinationsModel : DEFAULT_MODEL;

  const seed = Math.floor(Math.random() * 1000000);
  const primaryUrl = `https://image.pollinations.ai/prompt/${sanitizedPrompt}?width=${width}&height=${height}&model=${pollinationsModel}&nologo=true&seed=${seed}`;
  const fallbackUrl = `https://image.pollinations.ai/prompt/${sanitizedPrompt}?width=${width}&height=${height}&model=turbo&nologo=true&seed=${seed}`;

  try {
    try {
      await downloadImage(primaryUrl, destPath);
    } catch (err) {
      console.warn(`Primary ${pollinationsModel} image generation failed, trying fallback turbo...`, err.message);
      await downloadImage(fallbackUrl, destPath);
    }

    const mirrorDirs = [
      path.join(__dirname, '..', 'storage', 'outputs'),
      path.join(__dirname, '..', 'outputs'),
    ];
    for (const dir of mirrorDirs) {
      try {
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
        const targetFile = path.join(dir, filename);
        if (targetFile !== destPath && !fs.existsSync(targetFile)) {
          fs.copyFileSync(destPath, targetFile);
        }
      } catch (e) {
        // ignore copy warning
      }
    }

    return {
      success: true,
      filename,
      localPath: destPath,
      imagePath: destPath,
      url: `/outputs/${filename}`,
      imageUrl: `/outputs/${filename}`,
      prompt: scenePrompt,
      model: pollinationsModel,
    };
  } catch (error) {
    console.error('AI Image generation failed:', error.message);
    return {
      success: false,
      error: error.message,
      prompt: scenePrompt,
    };
  }
}

module.exports = {
  generateSceneImage,
  AI_IMAGE_MODELS,
};
