const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const lockfile = require('proper-lockfile');
const { policy, accessError } = require('../utils/access-policy');

function signedLedgerMatches(stored, key) {
  if (!key || stored?.data?.version !== 1 || !/^[a-f0-9]{64}$/.test(stored?.mac || '')) return false;
  const expected = crypto.createHmac('sha256', key).update(JSON.stringify(stored.data)).digest();
  return crypto.timingSafeEqual(Buffer.from(stored.mac, 'hex'), expected);
}

function storageFailure(reason) {
  const messages = {
    'integrity-mismatch': 'Usage storage does not match its saved integrity key. Existing usage was preserved; restore the original key before retrying.',
    'missing-ledger': 'Previously initialized usage storage is missing. Restore the original usage file; usage will not be reset.',
    'missing-key': 'The original usage integrity key is unavailable. Restore it before retrying; existing usage was preserved.',
  };
  return Object.assign(accessError('QUOTA_STORAGE_UNAVAILABLE', messages[reason] ||
    'Usage storage could not be read or saved. Check file access and restart the app; existing usage will not be reset.', 503), { quotaStorageReason: reason });
}

// Web and Electron share the same ledger, so its signing key must live beside
// it too. Electron's previous store key is only a migration candidate: accept
// it only when it verifies the existing ledger, never re-sign unverified data.
function createStoredQuotaLedger({ filePath, preferredKey, requireExisting = false, ...options } = {}) {
  if (!path.isAbsolute(filePath || '')) throw new Error('An absolute quota path is required.');
  const keyPath = filePath.replace(/\.json$/, '') + '.key';
  return createQuotaLedger({
    ...options, filePath, requireExisting: requireExisting || fs.existsSync(keyPath),
    resolveKey(stored) {
      const keyExists = fs.existsSync(keyPath);
      let savedKey = '';
      if (keyExists) {
        if (fs.statSync(keyPath).size > 1024) throw storageFailure('invalid-key');
        savedKey = fs.readFileSync(keyPath, 'utf8').trim();
      }
      if (!stored && keyExists) throw storageFailure('missing-ledger');
      const key = stored
        ? [savedKey, preferredKey].find(candidate => signedLedgerMatches(stored, candidate))
        : preferredKey || crypto.randomBytes(32).toString('hex');
      if (!key) throw storageFailure(keyExists || preferredKey ? 'integrity-mismatch' : 'missing-key');
      if (savedKey !== key) {
        const temporary = `${keyPath}.${process.pid}.${crypto.randomUUID()}.tmp`;
        try {
          fs.writeFileSync(temporary, key, { flag: 'wx', mode: 0o600 });
          fs.renameSync(temporary, keyPath);
        } finally {
          try { fs.unlinkSync(temporary); } catch (error) { if (error.code !== 'ENOENT') throw error; }
        }
      }
      return key;
    },
  });
}

// No renderer-provided counter/date is accepted. Transactions are synchronous,
// file-locked and signed; an unreadable/tampered ledger is never reset to zero.
function createQuotaLedger({ filePath, key, resolveKey, now = Date.now, requireExisting = false,
  onInitialized = () => {}, onDiagnostic = () => {} } = {}) {
  if (!path.isAbsolute(filePath || '') || (!key && typeof resolveKey !== 'function')) throw new Error('A trusted quota path and integrity key are required.');
  const diagnose = (reason, error) => {
    // No keys, signed payloads, media paths or account identifiers in logs.
    try { onDiagnostic({ reason, storageCode: /^[A-Z_]+$/.test(error?.code || '') ? error.code : null }); } catch {}
  };
  let reportedInitialized = false;
  function transaction(action) {
    try { fs.mkdirSync(path.dirname(filePath), { recursive: true }); }
    catch (error) { diagnose('directory-unavailable', error); throw storageFailure('directory-unavailable'); }
    let release;
    try { release = lockfile.lockSync(filePath, { realpath: false, stale: 120000, retries: 0 }); }
    catch (error) {
      if (error.code === 'ELOCKED') throw accessError('QUOTA_BUSY', 'Usage storage is busy. Retry without starting another operation.', 503);
      diagnose('lock-unavailable', error); throw storageFailure('lock-unavailable');
    }
    let temporary;
    let stage = 'read';
    try {
      const current = Number(now());
      let state = { version: 1, lastTrustedAt: current, trialUsed: 0, days: {}, operations: {} };
      let stored = null;
      if (!fs.existsSync(filePath) && requireExisting) throw storageFailure('missing-ledger');
      if (fs.existsSync(filePath)) {
        if (fs.statSync(filePath).size > 8 * 1024 * 1024) throw new Error('Quota ledger exceeds the safe storage limit.');
        stored = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        if (!stored || typeof stored !== 'object' || Array.isArray(stored) || !stored.data) throw storageFailure('integrity-mismatch');
      }
      stage = 'verify';
      const signingKey = resolveKey ? resolveKey(stored) : key;
      const sign = data => crypto.createHmac('sha256', signingKey).update(JSON.stringify(data)).digest('hex');
      if (stored) {
        if (!signedLedgerMatches(stored, signingKey)) throw storageFailure('integrity-mismatch');
        state = stored.data;
      }
      if (!Number.isFinite(current) || current + 5 * 60_000 < state.lastTrustedAt) {
        throw accessError('CLOCK_ROLLBACK', 'The system clock moved backwards. Correct the clock before creating new work.');
      }
      state.lastTrustedAt = Math.max(current, state.lastTrustedAt);
      // Recover only pre-publication work owned by a demonstrably dead process.
      // An uncertain upload is never refunded automatically after a restart.
      for (const entry of Object.values(state.operations)) {
        if (entry.status !== 'reserved' || entry.feature === 'youtubeUpload' || !entry.ownerPid || entry.ownerPid === process.pid) continue;
        try { process.kill(entry.ownerPid, 0); }
        catch (error) { if (error.code === 'ESRCH') entry.status = 'released'; }
      }
      const date = new Date(state.lastTrustedAt).toISOString().slice(0, 10);
      state.days[date] ||= {};
      const result = action(state, date);
      // Ordinary completed daily records expire; publication IDs/effects are
      // durable replay guards, not disposable daily counters. Never let an old
      // workflow publish twice merely because its daily count has aged out.
      const cutoff = state.lastTrustedAt - 7 * 86400_000;
      for (const [id, entry] of Object.entries(state.operations)) {
        if (entry.status === 'released' || (entry.status === 'committed' && !entry.trial && entry.feature !== 'youtubeUpload' && entry.at < cutoff)) delete state.operations[id];
      }
      for (const day of Object.keys(state.days)) if (day < new Date(cutoff).toISOString().slice(0, 10)) delete state.days[day];
      stage = 'write';
      temporary = `${filePath}.${process.pid}.${crypto.randomUUID()}.tmp`;
      fs.writeFileSync(temporary, JSON.stringify({ data: state, mac: sign(state) }), { flag: 'wx', mode: 0o600 });
      fs.renameSync(temporary, filePath);
      temporary = null;
      requireExisting = true;
      // A web-created ledger must also set Electron's restart guard. A failed
      // IPC notification cannot undo a durable reservation or hide its ID;
      // retain the on-disk guard and retry notification next transaction.
      if (!reportedInitialized) {
        try { onInitialized(); reportedInitialized = true; }
        catch (error) { diagnose('initialization-notification-failed', error); }
      }
      return result;
    } catch (error) {
      if (error.quotaStorageReason) diagnose(error.quotaStorageReason, error);
      if (error.entitlementBlocked) throw error;
      diagnose(`${stage}-failed`, error);
      throw storageFailure(`${stage}-failed`);
    } finally {
      if (temporary) { try { fs.unlinkSync(temporary); } catch (error) { if (error.code !== 'ENOENT') diagnose('temporary-cleanup-failed', error); } }
      try { release(); } catch (error) { diagnose('lock-release-failed', error); }
    }
  }
  function reserve(id, feature, context, { trial = false, binding = '' } = {}) {
    if (typeof id !== 'string' || !/^[a-zA-Z0-9:_-]{1,180}$/.test(id) || !Object.hasOwn(policy.plans.basic.daily, feature)) throw new Error('Invalid quota operation.');
    return transaction((state, date) => {
      const existing = state.operations[id];
      if (existing) {
        if (existing.feature !== feature || existing.trial !== trial || (existing.binding || '') !== binding) throw accessError('QUOTA_OPERATION_CONFLICT', 'This operation has a different usage scope or media identity.', 409);
        return { ...existing, id };
      }
      const limits = policy.plans[context.planId] || policy.plans.basic;
      const limit = limits.daily[feature] === null ? Infinity : limits.daily[feature];
      const pending = Object.values(state.operations).filter(entry => entry.status === 'reserved' && entry.date === date && entry.feature === feature).length;
      if ((state.days[date][feature] || 0) + pending >= limit) throw accessError('DAILY_QUOTA_EXCEEDED', `The daily ${feature} allowance is exhausted. Finish or cancel pending work, or upgrade your plan.`, 429);
      if (trial) {
        state.trialUsed = Math.max(state.trialUsed, policy.trialLimit - Math.max(0, Number(context.trialRemain) || 0));
        const reservedTrials = Object.values(state.operations).filter(entry => entry.status === 'reserved' && entry.trial).length;
        if (state.trialUsed + reservedTrials >= policy.trialLimit) throw accessError('TRIAL_EXHAUSTED', 'The trial allowance is exhausted. Activate a license to continue.');
      }
      const entry = { feature, date, trial, binding, status: 'reserved', at: state.lastTrustedAt, ownerPid: process.pid };
      state.operations[id] = entry;
      return { ...entry, id };
    });
  }
  function finish(id, commit) {
    return transaction(state => {
      const entry = state.operations[id];
      if (!entry || entry.status !== 'reserved') return entry ? { ...entry, id, trialUsed: state.trialUsed } : null;
      if (!commit && Object.values(entry.effects || {}).some(effect => ['started', 'completed'].includes(effect.status))) {
        return { ...entry, id, trialUsed: state.trialUsed };
      }
      entry.status = commit ? 'committed' : 'released';
      if (commit) {
        state.days[entry.date] ||= {};
        state.days[entry.date][entry.feature] = (state.days[entry.date][entry.feature] || 0) + 1;
        if (entry.trial) state.trialUsed++;
      }
      return { ...entry, id, trialUsed: state.trialUsed };
    });
  }
  function beginEffect(id, platform, binding) {
    if (!['youtube', 'tiktok', 'facebook'].includes(platform)) throw new Error('Invalid publish scope.');
    return transaction(state => {
      const entry = state.operations[id];
      if (!entry || !['reserved', 'committed'].includes(entry.status) || entry.feature !== 'youtubeUpload') throw accessError('QUOTA_OPERATION_CONFLICT', 'No reserved publish workflow.', 409);
      entry.effects ||= {};
      const existing = entry.effects[platform];
      if (existing) {
        if (existing.binding !== binding) throw accessError('QUOTA_OPERATION_CONFLICT', 'This workflow is already bound to another account.', 409);
        if (existing.status === 'completed') return { replay: true, result: existing.result };
        throw accessError('PUBLISH_REVIEW_REQUIRED', 'This platform upload is in progress or its outcome needs review. Check the account before starting another upload.', 409);
      }
      entry.effects[platform] = { binding, status: 'started', at: state.lastTrustedAt };
      return { replay: false };
    });
  }
  function completeEffect(id, platform, result) {
    return transaction(state => {
      const effect = state.operations[id]?.effects?.[platform];
      if (!effect) throw accessError('QUOTA_OPERATION_CONFLICT', 'Publish scope was not reserved.', 409);
      effect.status = 'completed'; effect.result = result;
    });
  }
  return { reserve, commit: id => finish(id, true), release: id => finish(id, false),
    beginEffect, completeEffect,
    snapshot: () => transaction((state, date) => ({ date, counts: { ...state.days[date] }, trialUsed: state.trialUsed,
      reserved: Object.values(state.operations).filter(entry => entry.status === 'reserved' && entry.date === date).reduce((counts, entry) => {
        counts[entry.feature] = (counts[entry.feature] || 0) + 1; return counts;
      }, {}),
      pending: Object.values(state.operations).filter(entry => entry.status === 'reserved').length })) };
}
module.exports = { createQuotaLedger, createStoredQuotaLedger };
