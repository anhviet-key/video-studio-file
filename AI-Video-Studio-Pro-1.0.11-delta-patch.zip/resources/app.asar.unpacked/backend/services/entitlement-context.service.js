const crypto = require('crypto');
const { normalizeContext, accessError } = require('../utils/access-policy');

function createEntitlementContextService({ transport = process, timeoutMs = 5000 } = {}) {
  const pending = new Map();
  transport.on?.('message', message => {
    if (message?.type !== 'entitlement-context-response') return;
    const request = pending.get(message.id);
    if (!request) return;
    pending.delete(message.id);
    clearTimeout(request.timer);
    if (message.ok !== true) request.reject(accessError('LICENSE_UNAVAILABLE', 'License verification is unavailable. Retry after reconnecting.', 503));
    else request.resolve(normalizeContext(message.context));
  });
  const rejectPending = () => {
    for (const request of pending.values()) {
      clearTimeout(request.timer);
      request.reject(accessError('LICENSE_UNAVAILABLE', 'The trusted license connection was closed.', 503));
    }
    pending.clear();
  };
  transport.on?.('disconnect', rejectPending);
  return {
    getCurrent() {
      if (typeof transport.send !== 'function' || transport.connected === false) {
        return Promise.reject(accessError('LICENSE_UNAVAILABLE', 'A trusted desktop license session is required for scheduled work.', 503));
      }
      const id = crypto.randomUUID();
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          pending.delete(id);
          reject(accessError('LICENSE_UNAVAILABLE', 'License verification timed out. No publishing was started.', 503));
        }, timeoutMs);
        pending.set(id, { resolve, reject, timer });
        try {
          transport.send({ type: 'entitlement-context-request', id }, error => {
            if (error && pending.has(id)) {
              pending.delete(id); clearTimeout(timer);
              reject(accessError('LICENSE_UNAVAILABLE', 'Unable to contact the trusted license session.', 503));
            }
          });
        } catch {
          pending.delete(id); clearTimeout(timer);
          reject(accessError('LICENSE_UNAVAILABLE', 'Unable to contact the trusted license session.', 503));
        }
      });
    },
  };
}
module.exports = { createEntitlementContextService };
