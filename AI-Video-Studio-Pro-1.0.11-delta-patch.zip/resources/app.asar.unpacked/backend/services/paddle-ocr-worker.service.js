const { spawn } = require('child_process');

function normalizeConfidencePercent(value) {
  const confidence = Number(value);
  if (!Number.isFinite(confidence)) return value;
  return confidence >= 0 && confidence <= 1
    ? confidence * 100
    : confidence;
}

function normalizePaddleOcrData(data = {}) {
  return {
    ...data,
    confidence: normalizeConfidencePercent(data.confidence),
    words: Array.isArray(data.words)
      ? data.words.map((word) => ({
          ...word,
          confidence: normalizeConfidencePercent(word?.confidence),
        }))
      : data.words,
  };
}

function createPaddleOcrWorker({ pythonPath, scriptPath, language = 'multilingual', env = process.env }) {
  let child = null;
  let sequence = 0;
  let stdoutBuffer = '';
  let stderrBuffer = '';
  let readyResolve;
  let readyReject;
  let closed = false;
  const pending = new Map();
  const ready = new Promise((resolve, reject) => {
    readyResolve = resolve;
    readyReject = reject;
  });

  child = spawn(pythonPath, [scriptPath, '--language', String(language || 'multilingual')], {
    env: {
      ...process.env,
      ...env,
      FLAGS_use_onednn: '0',
      PYTHONUTF8: '1',
    },
    windowsHide: true,
    stdio: ['pipe', 'pipe', 'pipe'],
  });

  const rejectAll = (error) => {
    for (const request of pending.values()) request.reject(error);
    pending.clear();
  };
  const startupTimer = setTimeout(() => {
    const error = new Error('PP-OCRv5 mobile worker startup timed out.');
    readyReject(error);
    rejectAll(error);
    try { child.kill(); } catch {}
  }, 5 * 60 * 1000);

  child.stdout.on('data', (chunk) => {
    stdoutBuffer += chunk.toString();
    let newlineIndex = stdoutBuffer.indexOf('\n');
    while (newlineIndex >= 0) {
      const line = stdoutBuffer.slice(0, newlineIndex).trim();
      stdoutBuffer = stdoutBuffer.slice(newlineIndex + 1);
      newlineIndex = stdoutBuffer.indexOf('\n');
      if (!line) continue;
      let message;
      try {
        message = JSON.parse(line);
      } catch {
        stderrBuffer += `${stderrBuffer ? '\n' : ''}[stdout] ${line}`;
        continue;
      }
      if (message.ready) {
        clearTimeout(startupTimer);
        readyResolve(message);
        continue;
      }
      if (message.id !== undefined && pending.has(message.id)) {
        const request = pending.get(message.id);
        pending.delete(message.id);
        if (message.ok) {
          const data = message.data || {};
          request.resolve({
            data: normalizePaddleOcrData(data),
          });
        }
        else request.reject(new Error(message.error || 'PP-OCRv5 recognition failed.'));
      }
    }
  });
  child.stderr.on('data', (chunk) => {
    stderrBuffer += chunk.toString();
  });
  child.on('error', (error) => {
    clearTimeout(startupTimer);
    readyReject(error);
    rejectAll(error);
  });
  child.on('close', (code) => {
    closed = true;
    clearTimeout(startupTimer);
    const error = new Error(
      stderrBuffer.trim() || `PP-OCRv5 worker exited with code ${code ?? 'unknown'}.`,
    );
    readyReject(error);
    rejectAll(error);
  });

  return {
    engine: 'pp-ocrv5-mobile',
    async setParameters() {},
    async recognize(imagePath) {
      await ready;
      if (closed || !child?.stdin || child.stdin.destroyed) {
        throw new Error('PP-OCRv5 worker is unavailable.');
      }
      const id = ++sequence;
      return new Promise((resolve, reject) => {
        pending.set(id, { resolve, reject });
        try {
          child.stdin.write(`${JSON.stringify({ id, action: 'recognize', imagePath })}\n`);
        } catch (error) {
          pending.delete(id);
          reject(error);
        }
      });
    },
    async terminate() {
      if (closed) return;
      try {
        child.stdin.write(`${JSON.stringify({ id: ++sequence, action: 'shutdown' })}\n`);
      } catch {}
      await new Promise((resolve) => {
        const timer = setTimeout(() => {
          try { child.kill(); } catch {}
          resolve();
        }, 2000);
        child.once('close', () => {
          clearTimeout(timer);
          resolve();
        });
      });
    },
  };
}

module.exports = {
  createPaddleOcrWorker,
  normalizeConfidencePercent,
  normalizePaddleOcrData,
};
