const fs = require('fs');
const path = require('path');
const os = require('os');
const { spawn } = require('child_process');
const sharp = require('sharp');
const { postProcessSubtitles } = require('../utils/subtitle-formatter');
// tesseract.js is an optional dependency. Requiring it at module load made its
// absence fatal to the entire backend: backend/routes/video-ocr.routes.js is
// mounted from server.js, so a missing package meant no app at all, not just no
// OCR. Resolve it on first use instead, and let only OCR fail - with a message
// that says what to do.
let tesseractCreateWorker = null;
function getTesseractCreateWorker() {
  if (!tesseractCreateWorker) {
    let tesseract;
    try {
      // eslint-disable-next-line global-require
      tesseract = require('tesseract.js');
    } catch (error) {
      throw new Error(
        'Video OCR needs the optional tesseract.js package, which is not installed. ' +
          'Reinstall backend dependencies with: npm --prefix backend ci --include=optional ' +
          `(${error.message})`,
      );
    }
    tesseractCreateWorker = tesseract.createWorker;
  }
  return tesseractCreateWorker;
}

const DEFAULT_ROI = {
  x: 0.05,
  y: 0.72,
  width: 0.9,
  height: 0.22,
};
const OCR_CHUNK_DURATION_SECONDS = 5 * 60;
const OCR_MAX_UNKNOWN_DURATION_CHUNKS = 24 * 60 * 60 / OCR_CHUNK_DURATION_SECONDS;
const OCR_LANGUAGE_ALIASES = Object.freeze({
  a: 'eng',
  b: 'eng',
  'eng-strict': 'eng',
  c: 'chi_sim',
  v: 'vie',
  j: 'jpn',
  ko: 'kor',
});
const SUPPORTED_OCR_LANGUAGES = new Set([
  'ara', 'ben', 'ces', 'chi_sim', 'dan', 'deu', 'ell', 'eng', 'fas', 'fin',
  'fra', 'heb', 'hin', 'hun', 'ind', 'ita', 'jpn', 'kor', 'mar', 'msa',
  'nld', 'nor', 'pol', 'por', 'ron', 'rus', 'spa', 'swa', 'swe', 'tam',
  'tel', 'tha', 'tur', 'ukr', 'urd', 'vie',
]);

function normalizeOcrLanguage(language = 'multilingual') {
  const raw = String(language || '').trim().toLowerCase();
  if (!raw || raw === 'auto' || raw === 'multilingual') {
    return 'multilingual';
  }
  const normalized = raw
    .split('+')
    .map((part) => OCR_LANGUAGE_ALIASES[part] || part)
    .filter((part) => SUPPORTED_OCR_LANGUAGES.has(part));
  const uniqueLanguages = [...new Set(normalized)];
  return uniqueLanguages.length > 0 ? uniqueLanguages.join('+') : 'vie+eng';
}

function normalizeRoi(roi, videoWidth = 1920, videoHeight = 1080) {
  let effectiveRoi = roi;
  if (typeof effectiveRoi === 'string' && effectiveRoi !== 'full') {
    try {
      effectiveRoi = JSON.parse(effectiveRoi);
    } catch {}
  }

  const safeW = Math.max(16, Number(videoWidth) || 1920);
  const safeH = Math.max(16, Number(videoHeight) || 1080);

  if (
    effectiveRoi === 'full' ||
    effectiveRoi?.fullScreen ||
    (effectiveRoi &&
      Number(effectiveRoi.x) === 0 &&
      Number(effectiveRoi.y) === 0 &&
      Number(effectiveRoi.width ?? effectiveRoi.w) >= 1 &&
      Number(effectiveRoi.height ?? effectiveRoi.h) >= 1)
  ) {
    let cropW = safeW;
    let cropH = safeH;
    if (cropW % 2 !== 0) cropW -= 1;
    if (cropH % 2 !== 0) cropH -= 1;
    return { cropW, cropH, cropX: 0, cropY: 0 };
  }

  const rawX = Number(effectiveRoi?.x ?? DEFAULT_ROI.x);
  const rawY = Number(effectiveRoi?.y ?? DEFAULT_ROI.y);
  const rawW = Number(effectiveRoi?.width ?? effectiveRoi?.w ?? DEFAULT_ROI.width);
  const rawH = Number(effectiveRoi?.height ?? effectiveRoi?.h ?? DEFAULT_ROI.height);

  // If coordinates are fractions (0.0 - 1.0), multiply by video dimensions
  const normX = rawX <= 1.0 ? rawX * safeW : rawX;
  const normY = rawY <= 1.0 ? rawY * safeH : rawY;
  const normW = rawW <= 1.0 ? rawW * safeW : rawW;
  const normH = rawH <= 1.0 ? rawH * safeH : rawH;

  let cropW = Math.max(16, Math.min(safeW, Math.round(normW)));
  let cropH = Math.max(16, Math.min(safeH, Math.round(normH)));
  let cropX = Math.max(0, Math.min(safeW - cropW, Math.round(normX)));
  let cropY = Math.max(0, Math.min(safeH - cropH, Math.round(normY)));

  // FFmpeg requires even dimensions
  if (cropW % 2 !== 0) cropW -= 1;
  if (cropH % 2 !== 0) cropH -= 1;
  if (cropX % 2 !== 0) cropX = Math.max(0, cropX - 1);
  if (cropY % 2 !== 0) cropY = Math.max(0, cropY - 1);

  return { cropW, cropH, cropX, cropY };
}

function formatSrtTimestamp(totalSeconds) {
  const safeSec = Math.max(0, Number(totalSeconds) || 0);
  const hours = Math.floor(safeSec / 3600);
  const minutes = Math.floor((safeSec % 3600) / 60);
  const seconds = Math.floor(safeSec % 60);
  const millis = Math.floor((safeSec % 1) * 1000);

  const pad = (n, len = 2) => String(n).padStart(len, '0');
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)},${pad(millis, 3)}`;
}

function isCjkChar(ch) {
  if (!ch) return false;
  return /[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]/.test(ch);
}

const WATERMARK_PATTERNS = [
  /transla[ti]e[da]?\s*(by|oy)/i,
  /official\s*website/i,
  /donghua\s*stream/i,
  /9anime/i,
  /bilibili/i,
  /wetv/i,
  /iqiyi/i,
  /\b(https?:\/\/|[a-z0-9-]+\.(com|net|org|tv|me|io|xyz|cc))\b/i,
  /^[0-9\s.,:;!?'"()\-—–/\\=_+~`@#$%^&*]+$/,
  /^\d+([.-]\d+)+$/,
  /^[b-df-hj-np-tv-z]{1,3}$/i,
];

function isWatermarkOrSpamText(text) {
  if (!text) return true;
  const s = String(text).trim();
  if (!s) return true;
  for (const pattern of WATERMARK_PATTERNS) {
    if (pattern.test(s)) return true;
  }
  return false;
}

function cleanSubtitleText(rawText) {
  if (!rawText || typeof rawText !== 'string') return '';
  const lines = rawText
    .normalize('NFC')
    .replace(/[\r\t]+/g, ' ')
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => {
      // Remove lines that are purely punctuation, stray OCR noise, or watermarks
      if (!line) return false;
      if (/^[~`!@#$%^&*()_+=|\\{}[\]:;"'<>,.?/\s-]+$/.test(line)) return false;
      if (isWatermarkOrSpamText(line)) return false;
      return (
        line.length >= 2 ||
        /^[\p{L}\p{N}]$/u.test(line) ||
        /[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]/.test(line)
      );
    });

  if (lines.length === 0) return '';

  let result = lines[0];
  for (let i = 1; i < lines.length; i++) {
    const prevLast = result.slice(-1);
    const currFirst = lines[i].slice(0, 1);
    if (isCjkChar(prevLast) && isCjkChar(currFirst)) {
      result += lines[i];
    } else {
      result += ` ${lines[i]}`;
    }
  }
  return result.replace(/\s{2,}/g, ' ').trim();
}

function calculateStringSimilarity(str1, str2) {
  const s1 = String(str1 || '').toLowerCase().trim();
  const s2 = String(str2 || '').toLowerCase().trim();
  if (s1 === s2) return 1.0;
  if (!s1 || !s2) return 0.0;

  const longer = s1.length > s2.length ? s1 : s2;
  const shorter = s1.length > s2.length ? s2 : s1;
  if (longer.includes(shorter)) {
    return shorter.length / longer.length;
  }

  // Fast Levenshtein distance
  const costs = [];
  for (let i = 0; i <= s1.length; i++) {
    let lastValue = i;
    for (let j = 0; j <= s2.length; j++) {
      if (i === 0) {
        costs[j] = j;
      } else if (j > 0) {
        let newValue = costs[j - 1];
        if (s1.charAt(i - 1) !== s2.charAt(j - 1)) {
          newValue = Math.min(Math.min(newValue, lastValue), costs[j]) + 1;
        }
        costs[j - 1] = lastValue;
        lastValue = newValue;
      }
    }
    if (i > 0) costs[s2.length] = lastValue;
  }
  const distance = costs[s2.length];
  return Math.max(0, 1 - distance / longer.length);
}

function areSubtitleTextsEquivalent(leftText, rightText) {
  const left = cleanSubtitleText(leftText).toLowerCase();
  const right = cleanSubtitleText(rightText).toLowerCase();
  if (!left || !right) return false;
  const similarity = calculateStringSimilarity(left, right);
  if (similarity >= 0.72) return true;
  const shorter = left.length <= right.length ? left : right;
  const longer = left.length > right.length ? left : right;
  if (
    shorter.length >= 4 &&
    longer.includes(shorter) &&
    shorter.length / longer.length >= 0.45
  ) {
    return true;
  }
  const leftTokens = new Set(left.match(/[\p{L}\p{N}]+/gu) || []);
  const rightTokens = new Set(right.match(/[\p{L}\p{N}]+/gu) || []);
  const sharedTokens = [...leftTokens].filter(
    (token) => token.length >= 3 && rightTokens.has(token),
  );
  const overlap =
    sharedTokens.length / Math.max(1, Math.min(leftTokens.size, rightTokens.size));
  return (
    (sharedTokens.length >= 2 && overlap >= 0.5) ||
    (leftTokens.size <= 2 &&
      rightTokens.size <= 2 &&
      sharedTokens.some((token) => token.length >= 4))
  );
}

async function computeFrameHash(imagePath, exactPixels = false) {
  try {
    if (exactPixels) {
      // Tone marks can change while a coarse 64x12 average barely changes.
      // The lightweight VI worker can afford conservative, exact-pixel reuse.
      return await sharp(imagePath).grayscale().raw().toBuffer();
    }
    const rawBuffer = await sharp(imagePath)
      .grayscale()
      .normalize()
      .threshold(175)
      .resize(64, 12, { fit: 'fill' })
      .raw()
      .toBuffer();
    return rawBuffer;
  } catch {
    return null;
  }
}

function extractHighConfidenceSubtitleText(ocrData = {}) {
  const normalizeRecognizedText = (value) =>
    cleanSubtitleText(value).replace(
      /\b(are|is|do|did|can|could|would|will|have|has)(you|we|they|he|she|it)\b/gi,
      '$1 $2',
    );
  const tsv = String(ocrData?.tsv || '').trim();
  if (!tsv) {
    const fallbackText = normalizeRecognizedText(ocrData?.text || '');
    const confidence = Number(ocrData?.confidence);
    return !Number.isFinite(confidence) || confidence >= 60 ? fallbackText : '';
  }

  const lines = new Map();
  const rows = tsv.split(/\r?\n/).slice(1);
  for (const row of rows) {
    const columns = row.split('\t');
    if (columns.length < 12 || columns[0] !== '5') continue;
    const rawText = String(columns.slice(11).join('\t') || '').trim();
    const lexicalText = rawText.replace(/[^\p{L}\p{N}]+/gu, '');
    const confidence = Number(columns[10]);
    if (!lexicalText || !Number.isFinite(confidence) || confidence < 45) continue;
    if (/^[a-z0-9]$/i.test(lexicalText) && !/^[ai]$/i.test(lexicalText)) {
      continue;
    }
    const word = {
      text: rawText,
      confidence,
      left: Math.max(0, Number(columns[6]) || 0),
      top: Math.max(0, Number(columns[7]) || 0),
      width: Math.max(1, Number(columns[8]) || 1),
      height: Math.max(1, Number(columns[9]) || 1),
    };
    const lineKey = `${columns[2] || 0}:${columns[3] || 0}:${columns[4] || 0}`;
    const words = lines.get(lineKey) || [];
    words.push(word);
    lines.set(lineKey, words);
  }

  const clusters = [];
  for (const words of lines.values()) {
    words.sort((left, right) => left.left - right.left);
    let cluster = [];
    const flushCluster = () => {
      if (cluster.length === 0) return;
      const averageConfidence =
        cluster.reduce((sum, word) => sum + word.confidence, 0) / cluster.length;
      const hasStrongWord = cluster.some((word) => word.confidence >= 72);
      if (hasStrongWord && (cluster.length > 1 || averageConfidence >= 72)) {
        clusters.push({
          text: normalizeRecognizedText(
            cluster.map((word) => word.text).join(' '),
          ),
          top: Math.min(...cluster.map((word) => word.top)),
          score:
            cluster.reduce((sum, word) => sum + word.confidence, 0) +
            cluster.length * 15,
        });
      }
      cluster = [];
    };

    for (const word of words) {
      const previous = cluster[cluster.length - 1];
      const gap = previous
        ? word.left - (previous.left + previous.width)
        : 0;
      const allowedGap = previous
        ? Math.max(80, Math.max(previous.height, word.height) * 2.5)
        : Number.POSITIVE_INFINITY;
      if (previous && gap > allowedGap) flushCluster();
      cluster.push(word);
    }
    flushCluster();
  }

  if (clusters.length === 0) return '';
  const strongestScore = Math.max(...clusters.map((cluster) => cluster.score));
  return normalizeRecognizedText(
    clusters
      .filter((cluster) => cluster.score >= Math.max(85, strongestScore * 0.55))
      .sort((left, right) => left.top - right.top)
      .map((cluster) => cluster.text)
      .filter(Boolean)
      .join('\n'),
  );
}

function joinPaddleOcrWords(words = [], minimumConfidence = 30, language = '') {
  const normLang = String(language || '').toLowerCase().trim();
  const isChinese = ['chi_sim', 'c', 'zh', 'chinese', 'chi'].some(
    (k) => normLang === k || normLang.startsWith(k + '+') || normLang.includes('chi_sim'),
  );
  const isEnglish = ['eng', 'a', 'english', 'en'].some(
    (k) => normLang === k || normLang === 'eng-strict',
  );
  const isVietnamese = normLang.split('+').some((k) => ['vie', 'v', 'vietnamese', 'vi'].includes(k));
  const isJapanese = ['jpn', 'j', 'japanese', 'ja'].some((k) => normLang === k);
  const isKorean = ['kor', 'ko', 'korean'].some((k) => normLang === k);

  const normalizedWords = (Array.isArray(words) ? words : [])
    .map((word) => {
      const text = String(word?.text || '').trim();
      const confidence = Number(word?.confidence);
      return {
        text,
        confidence,
        x0: Number(word?.x0) || 0,
        y0: Number(word?.y0) || 0,
        x1: Number(word?.x1) || 0,
        y1: Number(word?.y1) || 0,
      };
    })
    .filter((word) => {
      if (!word.text) return false;
      if (Number.isFinite(word.confidence) && word.confidence < minimumConfidence) return false;
      // Filter single-character low-confidence noise
      if (word.text.length === 1 && Number.isFinite(word.confidence)) {
        if (!isCjkChar(word.text) && word.confidence < 75) return false;
        if (isCjkChar(word.text) && word.confidence < 60) return false;
      }
      // Drop obvious website / fan-sub watermark tokens immediately
      if (/donghuastream|officialwebsite|\.com\b|\.net\b/i.test(word.text)) return false;
      return true;
    });

  if (normalizedWords.length === 0) return '';

  // Sort words vertically by line, then horizontally
  normalizedWords.sort((a, b) => {
    const aY = a.y0;
    const bY = b.y0;
    const aH = Math.max(1, a.y1 - a.y0);
    const bH = Math.max(1, b.y1 - b.y0);
    const lineTol = Math.max(8, Math.min(aH, bH) * 0.55);
    return Math.abs(aY - bY) <= lineTol ? a.x0 - b.x0 : aY - bY;
  });

  // Group into lines based on vertical overlap
  const lines = [];
  let currentLine = [];
  for (const word of normalizedWords) {
    if (currentLine.length === 0) {
      currentLine.push(word);
      continue;
    }
    const prev = currentLine[currentLine.length - 1];
    const prevH = Math.max(1, prev.y1 - prev.y0);
    const currH = Math.max(1, word.y1 - word.y0);
    const sameLine =
      Math.abs((prev.y0 + prev.y1) / 2 - (word.y0 + word.y1) / 2) <=
      Math.max(prevH, currH) * 0.6;
    if (sameLine) {
      currentLine.push(word);
    } else {
      lines.push(currentLine);
      currentLine = [word];
    }
  }
  if (currentLine.length > 0) lines.push(currentLine);

  // Render each line with smart inter-word spacing
  const renderedLines = lines
    .map((lineWords) => {
      lineWords.sort((a, b) => a.x0 - b.x0);
      let lineText = '';
      let prevWord = null;

      for (const word of lineWords) {
        if (!prevWord) {
          lineText = word.text;
          prevWord = word;
          continue;
        }

        const prevLastChar = prevWord.text.slice(-1);
        const currFirstChar = word.text.slice(0, 1);
        const bothCjk = isCjkChar(prevLastChar) && isCjkChar(currFirstChar);
        const isPunct = /^[.,!?:;'")\]}\uFF0C\u3002\uFF01\uFF1F\uFF1B\uFF1A\u3001\uFF09\u3011\u300B]/.test(
          word.text,
        );
        const prevOpenPunct = /[("'[{\uFF08\u3010\u300A]$/.test(prevWord.text);

        if (bothCjk) {
          // In CJK, characters/ideographs never have spaces between them
          lineText += word.text;
        } else if (isPunct || prevOpenPunct) {
          // Punctuation attaches cleanly
          lineText += word.text;
        } else {
          // Latin / Alphanumeric spacing
          const prevGlyphCount = Math.max(1, prevWord.text.replace(/\s+/g, '').length);
          const currGlyphCount = Math.max(1, word.text.replace(/\s+/g, '').length);
          const prevGlyphWidth =
            Math.max(1, (prevWord.x1 || 0) - (prevWord.x0 || 0)) / prevGlyphCount;
          const currGlyphWidth =
            Math.max(1, (word.x1 || 0) - (word.x0 || 0)) / currGlyphCount;
          const gap = (word.x0 || 0) - (prevWord.x1 || 0);

          // Sub-glyph fragment gap: true syllable fragments have gap <= 2.5px
          const fragmentGapThreshold = Math.max(
            2,
            Math.min(prevGlyphWidth, currGlyphWidth) * 0.45,
          );
          // If both tokens are complete words (length >= 3) and gap > 2.5px, ALWAYS space!
          const bothFullWords = prevWord.text.length >= 3 && word.text.length >= 3 && gap > 2.5;

          if (bothFullWords || gap > fragmentGapThreshold) {
            lineText += ` ${word.text}`;
          } else {
            lineText += word.text;
          }
        }
        prevWord = word;
      }

      const cleanText = lineText.trim();
      const avgScore =
        lineWords.reduce((sum, w) => sum + (w.confidence || 0), 0) / lineWords.length;
      const cjkCount = (cleanText.match(/[\u4e00-\u9fff]/g) || []).length;
      const latinCount = (cleanText.match(/[a-zA-Z\u00C0-\u1EF9]/g) || []).length;
      const kanaCount = (cleanText.match(/[\u3040-\u30ff]/g) || []).length;
      const hangulCount = (cleanText.match(/[\uac00-\ud7af]/g) || []).length;

      return {
        text: cleanText,
        score: avgScore,
        cjkCount,
        latinCount,
        kanaCount,
        hangulCount,
      };
    })
    .filter((l) => l.text && !isWatermarkOrSpamText(l.text));

  if (renderedLines.length === 0) return '';

  // Language Filtering based on user's target language
  let output = '';

  if (isChinese) {
    // Only accept lines that are predominantly Chinese!
    // An English line with an OCR misrecognized CJK glyph (e.g. Wi咖Dneverlet) has latinCount >> cjkCount.
    const chineseLines = renderedLines.filter(
      (l) => l.cjkCount >= 1 && (l.latinCount === 0 || l.cjkCount >= l.latinCount),
    );
    if (chineseLines.length === 0) return '';
    output = chineseLines
      .map((l) => {
        return l.text
          .replace(/\b[b-df-hj-np-tv-z]{1,4}\b/gi, '')
          .replace(/^[^\u4e00-\u9fff\u3000-\u303f\uff00-\uffef\d\w\s]+/, '')
          .replace(/[^\u4e00-\u9fff\u3000-\u303f\uff00-\uffef\d\w\s]+$/, '')
          .trim();
      })
      .filter(Boolean)
      .join('\n');
  } else if (isEnglish) {
    const englishLines = renderedLines.filter((l) => l.latinCount >= 1 && l.cjkCount === 0);
    if (englishLines.length === 0) {
      const candidate = renderedLines.filter((l) => l.latinCount > l.cjkCount);
      output = candidate
        .map((l) =>
          l.text.replace(/[\u4e00-\u9fff\u3040-\u30ff\uac00-\ud7af]/g, '').trim(),
        )
        .filter(Boolean)
        .join('\n');
    } else {
      output = englishLines.map((l) => l.text).join('\n');
    }
  } else if (isVietnamese) {
    const viLines = renderedLines.filter((l) => l.latinCount >= 1 && l.cjkCount === 0);
    output = viLines.length > 0 ? viLines.map((l) => l.text).join('\n') : renderedLines.map((l) => l.text).join('\n');
  } else if (isJapanese) {
    const jpnLines = renderedLines.filter((l) => l.kanaCount >= 1 || l.cjkCount >= 1);
    output = jpnLines.length > 0 ? jpnLines.map((l) => l.text).join('\n') : '';
  } else if (isKorean) {
    const korLines = renderedLines.filter((l) => l.hangulCount >= 1);
    output = korLines.length > 0 ? korLines.map((l) => l.text).join('\n') : '';
  } else {
    // Multilingual / Auto mode:
    // If dual subtitles are present (English line + Chinese line),
    // prioritize the native Chinese subtitle line if Chinese characters >= 1!
    const hasChinese = renderedLines.some((l) => l.cjkCount >= 1);
    const hasEnglish = renderedLines.some((l) => l.latinCount >= 3);
    if (hasChinese && hasEnglish) {
      const bestChinese = renderedLines.filter(
        (l) => l.cjkCount >= 1 && (l.latinCount === 0 || l.cjkCount >= l.latinCount),
      );
      if (bestChinese.length > 0) {
        output = bestChinese
          .map((l) => {
            return l.text
              .replace(/\b[b-df-hj-np-tv-z]{1,4}\b/gi, '')
              .replace(/^[^\u4e00-\u9fff\u3000-\u303f\uff00-\uffef\d\w\s]+/, '')
              .replace(/[^\u4e00-\u9fff\u3000-\u303f\uff00-\uffef\d\w\s]+$/, '')
              .trim();
          })
          .filter(Boolean)
          .join('\n');
      } else {
        output = renderedLines.map((l) => l.text).join('\n');
      }
    } else {
      output = renderedLines.map((l) => l.text).join('\n');
    }
  }

  // Post-process ungluing and typography cleanup
  return output
    .replace(
      /\b(I|you|we|they|he|she|it)(can't|won't|don't|didn't|isn't|aren't|wasn't|weren't|haven't|hasn't|hadn't|couldn't|wouldn't|shouldn't)\b/gi,
      '$1 $2',
    )
    .replace(
      /\b(I|you|we|they|he|she|it)(will|would|can|could|did|do|was|is|am|are|had|has|have)\b/gi,
      '$1 $2',
    )
    .replace(/\b(in|on|at|to|by|from|with|into|onto|outof)(the|a|an)\b/gi, '$1 $2')
    .replace(/\b(out)(of)\b/gi, '$1 $2')
    .replace(/\b(tenthousand|tenthousandyears)\b/gi, 'ten thousand years')
    .replace(/\b(oneinch|twoinch)\b/gi, 'one inch')
    .replace(/\b(oneinchlonger)\b/gi, 'one inch longer')
    .replace(/\b(oneinchstronger)\b/gi, 'one inch stronger')
    .replace(/\b(soulpossession)\b/gi, 'soul possession')
    .replace(/\b(HundredFlowersValley)\b/gi, 'Hundred Flowers Valley')
    .replace(/\b(DivineDemonMausoleum|DivineDémonMausoleum)\b/gi, 'Divine Demon Mausoleum')
    .replace(/\b(EasternChu)\b/gi, 'Eastern Chu')
    .replace(/\bsstep\b/gi, 'step')
    .replace(
      /\b(longer|still|also|already|never|ever)(have|has|had|remember|know|see|hear)\b/gi,
      '$1 $2',
    )
    .replace(/^[=~_@]\s*/, '')
    .trim();
}

function areFramesSimilar(hash1, hash2, threshold = 12) {
  if (!hash1 || !hash2 || hash1.length !== hash2.length) return false;
  let totalDiff = 0;
  for (let i = 0; i < hash1.length; i++) {
    totalDiff += Math.abs(hash1[i] - hash2[i]);
  }
  const avgDiff = totalDiff / hash1.length;
  return avgDiff <= threshold;
}

function extractFramesWithFfmpeg({
  ffmpegPath,
  videoPath,
  cropW,
  cropH,
  cropX,
  cropY,
  fps = 2,
  startTime = 0,
  duration = 0,
  outputPattern,
  signal,
}) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) {
      return reject(new Error('OCR frame extraction cancelled.'));
    }

    const args = [
      '-y',
      '-hide_banner',
      '-loglevel',
      'error',
      ...(Number(startTime) > 0
        ? ['-ss', Number(startTime).toFixed(3)]
        : []),
      '-i',
      videoPath,
      ...(Number(duration) > 0
        ? ['-t', Number(duration).toFixed(3)]
        : []),
      '-vf',
      `fps=${fps},crop=${cropW}:${cropH}:${cropX}:${cropY},scale='min(1920,iw)':-2:flags=lanczos`,
      '-fps_mode',
      'vfr',
      '-start_number',
      '1',
      outputPattern,
    ];

    const child = spawn(ffmpegPath || 'ffmpeg', args, {
      windowsHide: true,
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stderr = '';
    child.stderr.on('data', (d) => {
      stderr += d.toString();
    });

    const abortHandler = () => {
      try {
        child.kill('SIGKILL');
      } catch {}
      reject(new Error('OCR frame extraction cancelled.'));
    };

    if (signal) {
      signal.addEventListener('abort', abortHandler, { once: true });
    }

    child.on('close', (code) => {
      if (signal) {
        signal.removeEventListener('abort', abortHandler);
      }
      if (signal?.aborted) {
        return reject(new Error('OCR frame extraction cancelled.'));
      }
      if (code === 0) {
        resolve();
      } else {
        reject(
          new Error(
            `FFmpeg frame extraction exited with code ${code}: ${stderr.slice(-300)}`,
          ),
        );
      }
    });

    child.on('error', (err) => {
      if (signal) {
        signal.removeEventListener('abort', abortHandler);
      }
      reject(err);
    });
  });
}

function mergeFramesToSubtitles(frameResults, fps = 2) {
  const frameInterval = 1 / fps;
  const subtitles = [];
  let currentSub = null;

  for (let i = 0; i < frameResults.length; i++) {
    const frame = frameResults[i];
    const explicitTime = Number(frame.time);
    const frameTime = Number.isFinite(explicitTime)
      ? Math.max(0, explicitTime)
      : (frame.index - 1) * frameInterval;
    const text = cleanSubtitleText(frame.text);

    if (!text) {
      // Empty text marks end of current subtitle
      if (currentSub) {
        subtitles.push({ ...currentSub });
        currentSub = null;
      }
      continue;
    }

    if (!currentSub) {
      currentSub = {
        startTime: frameTime,
        endTime: frameTime + frameInterval,
        text,
      };
    } else {
      if (areSubtitleTextsEquivalent(currentSub.text, text)) {
        // Same subtitle continuing - update end time and adopt the longer/cleaner text
        currentSub.endTime = frameTime + frameInterval;
        if (text.length > currentSub.text.length) {
          currentSub.text = text;
        }
      } else {
        // New subtitle starting
        subtitles.push({ ...currentSub });
        currentSub = {
          startTime: frameTime,
          endTime: frameTime + frameInterval,
          text,
        };
      }
    }
  }

  if (currentSub) {
    subtitles.push({ ...currentSub });
  }

  // Ensure minimum display duration (at least 0.6s) and smooth gaps
  const normalizedSubtitles = subtitles
    .filter((s) => s.text && s.text.length > 0)
    .map((s, idx) => {
      let duration = s.endTime - s.startTime;
      if (duration < 0.6) {
        s.endTime = s.startTime + 0.6;
      }
      return {
        id: idx + 1,
        startTime: Number(s.startTime.toFixed(3)),
        endTime: Number(s.endTime.toFixed(3)),
        text: s.text,
      };
    });
  for (let index = 0; index < normalizedSubtitles.length - 1; index += 1) {
    const current = normalizedSubtitles[index];
    const next = normalizedSubtitles[index + 1];
    if (current.endTime > next.startTime) {
      current.endTime = Math.max(current.startTime + 0.12, next.startTime);
    }
  }
  return normalizedSubtitles.filter(
    (subtitle) => subtitle.endTime - subtitle.startTime >= 0.12,
  );
}

function mergeSubtitleChunks(existingSubtitles, nextSubtitles, fps = 2) {
  const merged = Array.isArray(existingSubtitles)
    ? existingSubtitles.map((subtitle) => ({ ...subtitle }))
    : [];
  const frameInterval = 1 / Math.max(0.1, Number(fps) || 2);

  for (const subtitle of Array.isArray(nextSubtitles) ? nextSubtitles : []) {
    const next = { ...subtitle };
    const previous = merged[merged.length - 1];
    const gap = previous
      ? Number(next.startTime) - Number(previous.endTime)
      : Number.POSITIVE_INFINITY;
    if (
      previous &&
      gap <= frameInterval * 1.5 &&
      areSubtitleTextsEquivalent(previous.text, next.text)
    ) {
      previous.endTime = Math.max(
        Number(previous.endTime) || 0,
        Number(next.endTime) || 0,
      );
      if (String(next.text || '').length > String(previous.text || '').length) {
        previous.text = next.text;
      }
      continue;
    }
    merged.push(next);
  }

  return merged.map((subtitle, index) => ({
    ...subtitle,
    id: index + 1,
  }));
}

function writeSrtCheckpoint(srtOutputPath, subtitles, language = 'eng') {
  if (!srtOutputPath) return '';
  const partialPath = `${srtOutputPath}.partial`;
  const temporaryPath = `${partialPath}.tmp`;
  fs.mkdirSync(path.dirname(srtOutputPath), { recursive: true });
  const isCjk = ['chi_sim', 'cjk', 'jpn', 'kor', 'c', 'j', 'ko', 'zh'].some(
    (k) => String(language || '').toLowerCase().includes(k),
  );
  const formatted = postProcessSubtitles(subtitles, {
    maxCharactersPerLine: isCjk ? 22 : 40,
    maxLines: 2,
    language,
    minDurationSec: 0.84,
    minGapSec: 0.06,
  });
  fs.writeFileSync(temporaryPath, buildSrtContent(formatted), 'utf8');
  try {
    if (fs.existsSync(partialPath)) fs.unlinkSync(partialPath);
    fs.renameSync(temporaryPath, partialPath);
  } catch (error) {
    try {
      if (fs.existsSync(temporaryPath)) fs.unlinkSync(temporaryPath);
    } catch {}
    throw error;
  }
  return partialPath;
}

function buildSrtContent(subtitles) {
  return subtitles
    .map((sub, index) => {
      const start = formatSrtTimestamp(sub.startTime);
      const end = formatSrtTimestamp(sub.endTime);
      return `${index + 1}\n${start} --> ${end}\n${sub.text}\n`;
    })
    .join('\n');
}

function buildTranscriptText(subtitles) {
  if (!Array.isArray(subtitles) || subtitles.length === 0) return '';
  return subtitles.map((s) => s.text).join('\n\n');
}

async function transcribeVideoWithOcr({
  videoPath,
  roi = DEFAULT_ROI,
  language = 'vie+eng',
  fps = 1.5,
  videoWidth = 0,
  videoHeight = 0,
  videoDuration = 0,
  srtOutputPath,
  ffmpegPath = 'ffmpeg',
  tempBaseDir = os.tmpdir(),
  onProgress = null,
  signal = null,
  chunkDurationSeconds = OCR_CHUNK_DURATION_SECONDS,
  extractFrames = extractFramesWithFfmpeg,
  createOcrWorker = null,
  requestedOcrEngine = 'tesseract',
}) {
  if (!videoPath || !fs.existsSync(videoPath)) {
    throw new Error('Video file not found for OCR transcription.');
  }

  // Fail fast on a missing optional dependency, before spending time on ffmpeg.
  const ocrWorkerFactory = createOcrWorker || getTesseractCreateWorker();

  const workDir = path.join(
    tempBaseDir,
    `ocr-work-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
  );
  fs.mkdirSync(workDir, { recursive: true });

  let worker = null;

  try {
    if (signal?.aborted) throw new Error('OCR transcription cancelled.');

    let effectiveWidth = Number(videoWidth) || 0;
    let effectiveHeight = Number(videoHeight) || 0;
    let effectiveDuration = Number(videoDuration) || 0;
    if (!effectiveWidth || !effectiveHeight) {
      try {
        const { spawnSync } = require('child_process');
        const probe = spawnSync(ffmpegPath || 'ffmpeg', ['-i', videoPath], {
          encoding: 'utf8',
          windowsHide: true,
        });
        const info = `${probe.stderr || ''}${probe.stdout || ''}`;
        const size = /\b(\d{2,5})x(\d{2,5})\b/.exec(info);
        if (size) {
          effectiveWidth = Number(size[1]) || 1920;
          effectiveHeight = Number(size[2]) || 1080;
        }
        if (!effectiveDuration) {
          const durMatch = /Duration:\s*(\d+):(\d+):([\d.]+)/.exec(info);
          if (durMatch) {
            effectiveDuration = Number(durMatch[1]) * 3600 + Number(durMatch[2]) * 60 + Number(durMatch[3]);
          }
        }
      } catch {}
    }

    const { cropW, cropH, cropX, cropY } = normalizeRoi(
      roi,
      effectiveWidth || 1920,
      effectiveHeight || 1080,
    );

    const normalizedFps = Math.max(0.25, Math.min(4, Number(fps) || 1.5));
    const normalizedDuration = Math.max(0, Number(effectiveDuration) || 0);
    const normalizedChunkDuration = Math.max(
      30,
      Math.min(15 * 60, Number(chunkDurationSeconds) || OCR_CHUNK_DURATION_SECONDS),
    );
    const hasKnownDuration = normalizedDuration > 0;
    const plannedChunkCount = hasKnownDuration
      ? Math.max(1, Math.ceil(normalizedDuration / normalizedChunkDuration))
      : OCR_MAX_UNKNOWN_DURATION_CHUNKS;
    const estimatedTotalFrames = hasKnownDuration
      ? Math.max(1, Math.ceil(normalizedDuration * normalizedFps))
      : 0;
    const safeLang = normalizeOcrLanguage(language);
    let subtitles = [];
    let processedFrames = 0;
    let chunksProcessed = 0;
    let lastHash = null;
    let lastText = '';
    let framesSinceLastRecognition = 0;
    let partialSrtPath = '';

    for (let chunkIndex = 0; chunkIndex < plannedChunkCount; chunkIndex += 1) {
      if (signal?.aborted) throw new Error('OCR transcription cancelled.');

      const chunkStart = chunkIndex * normalizedChunkDuration;
      if (hasKnownDuration && chunkStart >= normalizedDuration) break;
      const currentChunkDuration = hasKnownDuration
        ? Math.min(normalizedChunkDuration, normalizedDuration - chunkStart)
        : normalizedChunkDuration;
      const chunkDir = path.join(
        workDir,
        `chunk_${String(chunkIndex + 1).padStart(4, '0')}`,
      );
      fs.mkdirSync(chunkDir, { recursive: true });

      const totalFramesForProgress = estimatedTotalFrames || processedFrames;
      if (onProgress) {
        const extractionProgress = hasKnownDuration
          ? Math.round(5 + (chunkIndex / plannedChunkCount) * 10)
          : 5;
        onProgress({
          step: 'extracting',
          progress: extractionProgress,
          currentFrame: processedFrames,
          totalFrames: totalFramesForProgress,
          currentChunk: chunkIndex + 1,
          chunkCount: hasKnownDuration ? plannedChunkCount : 0,
          processedSeconds: chunkStart,
          durationSeconds: normalizedDuration,
          partialSrtPath,
          message: `Extracting subtitle frames for chunk ${chunkIndex + 1}${
            hasKnownDuration ? `/${plannedChunkCount}` : ''
          }...`,
        });
      }

      const outputPattern = path.join(chunkDir, 'frame_%06d.png');
      await extractFrames({
        ffmpegPath,
        videoPath,
        cropW,
        cropH,
        cropX,
        cropY,
        fps: normalizedFps,
        startTime: chunkStart,
        duration: currentChunkDuration,
        outputPattern,
        signal,
      });

      if (signal?.aborted) throw new Error('OCR transcription cancelled.');

      const frameFiles = fs
        .readdirSync(chunkDir)
        .filter((fileName) => fileName.startsWith('frame_') && fileName.endsWith('.png'))
        .sort();
      if (frameFiles.length === 0) {
        try {
          fs.rmSync(chunkDir, { recursive: true, force: true });
        } catch {}
        if (processedFrames === 0) {
          throw new Error('No frames were extracted from the video.');
        }
        break;
      }

      if (!worker) {
        if (onProgress) {
          onProgress({
            step: 'initializing-ocr',
            progress: 15,
            currentFrame: processedFrames,
            totalFrames: estimatedTotalFrames || frameFiles.length,
            currentChunk: chunkIndex + 1,
            chunkCount: hasKnownDuration ? plannedChunkCount : 0,
            message: 'Initializing OCR engine...',
          });
        }
        if (typeof createOcrWorker === 'function') {
          try {
            worker = await createOcrWorker(safeLang);
          } catch (initErr) {
            if (requestedOcrEngine === 'paddle' || requestedOcrEngine === 'tesseract-vie-lstm') throw initErr;
            console.warn('[OCR WORKER FALLBACK] Custom worker init failed, using tesseract:', initErr.message);
            const fallbackFactory = getTesseractCreateWorker();
            const tesseractLang = safeLang === 'multilingual' ? 'vie+eng' : safeLang;
            worker = await fallbackFactory(tesseractLang, 1, { errorHandler: () => {} });
          }
        } else {
          const tesseractLang = safeLang === 'multilingual' ? 'vie+eng' : safeLang;
          worker = await ocrWorkerFactory(tesseractLang, 1, {
            errorHandler: () => {},
          });
        }
        if (worker && typeof worker.setParameters === 'function') {
          await worker.setParameters({
            tessedit_pageseg_mode:
              worker.engine === 'tesseract-vie-lstm' ? '6' :
                cropH / Math.max(1, Number(videoHeight) || 1) <= 0.12 ? '7' : '6',
            user_defined_dpi: '300',
            preserve_interword_spaces: '1',
          }).catch(() => {});
        }
      }

      const chunkFrameResults = [];
      try {
        for (let frameOffset = 0; frameOffset < frameFiles.length; frameOffset += 1) {
          if (signal?.aborted) throw new Error('OCR transcription cancelled.');

          const filename = frameFiles[frameOffset];
          const framePath = path.join(chunkDir, filename);
          const frameIndex = processedFrames + frameOffset + 1;
          const frameTime = chunkStart + frameOffset / normalizedFps;
          const isVietnameseWorker = worker?.engine === 'tesseract-vie-lstm';
          const currentHash = await computeFrameHash(framePath, isVietnameseWorker);
          let text = '';

          if (
            lastHash &&
            (isVietnameseWorker ? lastHash.equals(currentHash || Buffer.alloc(0)) : areFramesSimilar(lastHash, currentHash)) &&
            framesSinceLastRecognition < Math.max(2, Math.round(normalizedFps * 2))
          ) {
            text = lastText;
            framesSinceLastRecognition += 1;
          } else {
            const isPaddle = worker?.engine && (worker.engine.includes('pp-ocr') || worker.engine.includes('paddle'));
            if (isPaddle) {
              const paddleInputPath =
                cropW < 1200
                  ? path.join(chunkDir, `paddle_${filename}`)
                  : framePath;
              try {
                if (paddleInputPath !== framePath) {
                  await sharp(framePath)
                    .resize({
                      width: Math.max(1200, Math.min(2000, Math.round(cropW * 2))),
                      fit: 'inside',
                      kernel: sharp.kernel.lanczos3,
                    })
                    .sharpen()
                    .toFile(paddleInputPath);
                }
                const ocrResult = await worker.recognize(paddleInputPath);
                const data = ocrResult?.data || {};
                if (Array.isArray(data.words) && data.words.length > 0) {
                  text = cleanSubtitleText(joinPaddleOcrWords(data.words, 30, safeLang));
                } else {
                  text = cleanSubtitleText(data.text || '');
                }
              } catch (paddleErr) {
                console.warn('[PADDLE OCR FRAME ERROR]', paddleErr.message);
                text = '';
              } finally {
                if (paddleInputPath !== framePath) {
                  try {
                    if (fs.existsSync(paddleInputPath)) fs.unlinkSync(paddleInputPath);
                  } catch {}
                }
              }
            } else {
              const preprocessedPath = path.join(chunkDir, `proc_${filename}`);
              try {
                const targetWidth = Math.max(
                  900,
                  Math.min(2400, Math.round(cropW * (cropW < 1800 ? 1.35 : 0.75))),
                );
                const preprocessing = sharp(framePath)
                  .resize({
                    width: targetWidth,
                    fit: 'inside',
                  })
                  .grayscale()
                  .normalize()
                  .sharpen();
                // Hard thresholding erases thin Vietnamese tone marks. Keep
                // continuous greyscale for VI; other languages are unchanged.
                if (worker?.engine !== 'tesseract-vie-lstm') preprocessing.threshold(175);
                await preprocessing
                  .withMetadata({ density: 300 })
                  .toFile(preprocessedPath);

                const ocrResult = await worker.recognize(
                  preprocessedPath,
                  {},
                  { tsv: true },
                );
                text = extractHighConfidenceSubtitleText(ocrResult?.data || {});
              } finally {
                try {
                  if (fs.existsSync(preprocessedPath)) fs.unlinkSync(preprocessedPath);
                } catch {}
              }
            }

            lastHash = currentHash;
            lastText = text;
            framesSinceLastRecognition = 0;
          }

          chunkFrameResults.push({
            index: frameIndex,
            time: frameTime,
            text,
          });

          if (
            onProgress &&
            (frameOffset % 2 === 0 || frameOffset === frameFiles.length - 1)
          ) {
            const completedFrames = processedFrames + frameOffset + 1;
            const denominator = Math.max(
              completedFrames,
              estimatedTotalFrames || completedFrames,
            );
            const pct = Math.min(
              95,
              Math.round(15 + (completedFrames / denominator) * 80),
            );
            onProgress({
              step: 'scanning',
              currentFrame: completedFrames,
              totalFrames: denominator,
              currentChunk: chunkIndex + 1,
              chunkCount: hasKnownDuration ? plannedChunkCount : 0,
              processedSeconds: Math.min(
                normalizedDuration || frameTime,
                frameTime,
              ),
              durationSeconds: normalizedDuration,
              progress: pct,
              currentText: text,
              partialSrtPath,
              message: `Recognizing subtitle frame ${completedFrames}/${denominator}...`,
            });
          }
        }

        const chunkSubtitles = mergeFramesToSubtitles(
          chunkFrameResults,
          normalizedFps,
        );
        subtitles = mergeSubtitleChunks(subtitles, chunkSubtitles, normalizedFps);
        processedFrames += frameFiles.length;
        chunksProcessed += 1;
        partialSrtPath = writeSrtCheckpoint(srtOutputPath, subtitles, safeLang);
      } finally {
        try {
          fs.rmSync(chunkDir, { recursive: true, force: true });
        } catch {}
      }

      if (
        !hasKnownDuration &&
        frameFiles.length < Math.max(1, currentChunkDuration * normalizedFps * 0.5)
      ) {
        break;
      }
    }

    if (processedFrames === 0) {
      throw new Error('No frames were extracted from the video.');
    }

    const isCjk = ['chi_sim', 'cjk', 'jpn', 'kor', 'c', 'j', 'ko', 'zh'].some(
      (k) => String(safeLang || '').toLowerCase().includes(k),
    );
    const formattedSubtitles = postProcessSubtitles(subtitles, {
      maxCharactersPerLine: isCjk ? 22 : 40,
      maxLines: 2,
      language: safeLang,
      minDurationSec: 0.84,
      minGapSec: 0.06,
    });
    const srtContent = buildSrtContent(formattedSubtitles);
    const transcriptText = buildTranscriptText(formattedSubtitles);

    if (srtOutputPath) {
      fs.mkdirSync(path.dirname(srtOutputPath), { recursive: true });
      fs.writeFileSync(srtOutputPath, srtContent, 'utf8');
      try {
        if (partialSrtPath && fs.existsSync(partialSrtPath)) fs.unlinkSync(partialSrtPath);
      } catch {}
    }

    if (onProgress) {
      onProgress({
        step: 'completed',
        progress: 100,
        currentFrame: processedFrames,
        totalFrames: processedFrames,
        currentChunk: chunksProcessed,
        chunkCount: hasKnownDuration ? plannedChunkCount : chunksProcessed,
        processedSeconds: normalizedDuration,
        durationSeconds: normalizedDuration,
        segmentsCount: formattedSubtitles.length,
      });
    }

    return {
      srtContent,
      srtPath: srtOutputPath || '',
      transcriptText,
      subtitles: formattedSubtitles,
      segmentsCount: formattedSubtitles.length,
      detectedLanguage: safeLang.toUpperCase(),
      totalFrames: processedFrames,
      chunked: chunksProcessed > 1,
      chunksProcessed,
      chunkDurationSeconds: normalizedChunkDuration,
      ocrEngine: String(worker?.engine || requestedOcrEngine || 'tesseract'),
      ocrComparison: worker?.comparison || null,
    };
  } finally {
    if (worker) {
      try {
        await worker.terminate();
      } catch {}
    }
    // Clean up temporary extracted frames
    try {
      if (fs.existsSync(workDir)) {
        fs.rmSync(workDir, { recursive: true, force: true });
      }
    } catch {}
  }
}

module.exports = {
  DEFAULT_ROI,
  OCR_CHUNK_DURATION_SECONDS,
  normalizeRoi,
  normalizeOcrLanguage,
  formatSrtTimestamp,
  cleanSubtitleText,
  computeFrameHash,
  extractHighConfidenceSubtitleText,
  joinPaddleOcrWords,
  calculateStringSimilarity,
  areSubtitleTextsEquivalent,
  mergeFramesToSubtitles,
  mergeSubtitleChunks,
  buildSrtContent,
  buildTranscriptText,
  transcribeVideoWithOcr,
};
