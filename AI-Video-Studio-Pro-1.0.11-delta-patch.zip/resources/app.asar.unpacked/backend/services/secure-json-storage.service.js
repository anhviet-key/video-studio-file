const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const ENVELOPE_VERSION = 1;
const ALGORITHM = 'aes-256-gcm';

function decodeKey(value = '') {
  try {
    const key = Buffer.from(String(value || '').trim(), 'base64');
    return key.length === 32 ? key : null;
  } catch {
    return null;
  }
}

function encryptJson(data, key) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv(ALGORITHM, key, iv);
  const plaintext = Buffer.from(JSON.stringify(data), 'utf8');
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  return {
    version: ENVELOPE_VERSION,
    algorithm: ALGORITHM,
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    ciphertext: ciphertext.toString('base64'),
  };
}

function decryptJson(envelope, key) {
  if (
    !envelope ||
    envelope.version !== ENVELOPE_VERSION ||
    envelope.algorithm !== ALGORITHM
  ) {
    throw new Error('Unsupported encrypted storage envelope.');
  }
  const decipher = crypto.createDecipheriv(
    ALGORITHM,
    key,
    Buffer.from(envelope.iv, 'base64'),
  );
  decipher.setAuthTag(Buffer.from(envelope.tag, 'base64'));
  const plaintext = Buffer.concat([
    decipher.update(Buffer.from(envelope.ciphertext, 'base64')),
    decipher.final(),
  ]);
  const parsed = JSON.parse(plaintext.toString('utf8'));
  return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
}

function writeJsonAtomic(filePath, value) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const tempPath = `${filePath}.tmp-${process.pid}-${Date.now()}`;
  fs.writeFileSync(tempPath, JSON.stringify(value, null, 2), {
    encoding: 'utf8',
    mode: 0o600,
  });
  fs.renameSync(tempPath, filePath);
}

function createSecureJsonStorage({ filePath, encryptionKey, logger = console }) {
  const key = decodeKey(encryptionKey);
  let memoryData = {};
  let loaded = false;

  function persist(data) {
    memoryData = data;
    if (!key) return false;
    writeJsonAtomic(filePath, encryptJson(data, key));
    return true;
  }

  function load() {
    if (loaded) return memoryData;
    loaded = true;
    if (!key) {
      logger.warn?.(
        '[SECURITY] Platform credentials are session-only because no OS-wrapped data key is available.',
      );
      return memoryData;
    }
    if (!fs.existsSync(filePath)) return memoryData;
    try {
      const parsed = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      if (parsed?.version === ENVELOPE_VERSION && parsed?.algorithm === ALGORITHM) {
        memoryData = decryptJson(parsed, key);
        return memoryData;
      }

      // One-time migration from the legacy plaintext object. The rewrite is
      // atomic; the original file remains intact if encryption cannot finish.
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        memoryData = parsed;
        persist(memoryData);
        return memoryData;
      }
      throw new Error('Legacy credential file is not an object.');
    } catch (error) {
      logger.warn?.('[SECURITY] Platform credential storage could not be opened.');
      memoryData = {};
      return memoryData;
    }
  }

  return {
    isPersistent: Boolean(key),
    get(keyName) {
      const data = load();
      return Object.prototype.hasOwnProperty.call(data, keyName)
        ? data[keyName]
        : null;
    },
    set(keyName, value) {
      const data = { ...load(), [keyName]: value };
      persist(data);
      return true;
    },
    remove(keyName) {
      const data = { ...load() };
      delete data[keyName];
      persist(data);
      return true;
    },
  };
}

module.exports = {
  ALGORITHM,
  ENVELOPE_VERSION,
  createSecureJsonStorage,
  decodeKey,
  decryptJson,
  encryptJson,
};
