const fs = require('fs');
const path = require('path');

function writeHuggingFaceCacheRef(refsPath, snapshotId) {
  const normalizedRefsPath = path.resolve(String(refsPath || ''));
  const normalizedSnapshotId = String(snapshotId || '').trim();
  if (!normalizedSnapshotId) {
    throw new Error('Hugging Face snapshot id is required.');
  }

  fs.mkdirSync(path.dirname(normalizedRefsPath), { recursive: true });
  let currentRef = '';
  try {
    currentRef = fs.readFileSync(normalizedRefsPath, 'utf8');
  } catch {}
  if (currentRef === normalizedSnapshotId) return false;

  // huggingface_hub reads refs verbatim. A trailing newline makes an otherwise
  // valid offline snapshot resolve to a non-existent directory.
  fs.writeFileSync(normalizedRefsPath, normalizedSnapshotId, 'utf8');
  return true;
}

module.exports = {
  writeHuggingFaceCacheRef,
};
