const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const BUILTIN_PLUGINS = [
  {
    id: 'capcut-tts',
    name: 'CapCut & TikTok TTS Engine',
    version: '1.0.6',
    author: 'K07VN / Community',
    type: 'tts',
    category: 'Voice & Speech',
    description: 'Tích hợp trọn bộ giọng đọc lồng tiếng HOT Trend tiếng Việt & Quốc tế từ CapCut / TikTok với cơ chế Native Signed Engine tự động không cần key.',
    icon: '🎙️',
    enabled: false,
    isBuiltin: true,
    githubUrl: 'https://github.com/K07VN/capcut-tts-api',
    features: ['127+ Giọng Đa Quốc Gia', 'Test Sandbox Âm thanh', 'Native Signed Engine Tự Động'],
  },
  {
    id: 'edge-tts',
    name: 'Microsoft Edge-TTS Free',
    version: '1.0.0',
    author: 'Microsoft / Community',
    type: 'tts',
    category: 'Voice & Speech',
    description: 'Bộ hơn 320+ giọng đọc Neural chất lượng phát thanh viên đa quốc gia hoàn toàn miễn phí không cần API key.',
    icon: '⚡',
    enabled: false,
    isBuiltin: true,
    githubUrl: 'https://github.com/rany2/edge-tts',
    features: ['320+ Giọng Đa Ngôn Ngữ', 'Giọng Hoài My & Nam Minh', 'Miễn phí 100% Không Cần Key'],
  },
];

function getPluginStorageDir(appStorageDir) {
  const baseDir = appStorageDir || path.join(__dirname, '..', '..', 'storage');
  const pluginsDir = path.join(baseDir, 'plugins');
  try {
    if (!fs.existsSync(pluginsDir)) {
      fs.mkdirSync(pluginsDir, { recursive: true });
    }
  } catch {}
  return pluginsDir;
}

function getInstalledPlugins(appStorageDir) {
  const pluginsDir = getPluginStorageDir(appStorageDir);
  const registryFile = path.join(pluginsDir, 'installed_plugins.json');

  let customPlugins = [];
  try {
    if (fs.existsSync(registryFile)) {
      const parsed = JSON.parse(fs.readFileSync(registryFile, 'utf8'));
      if (Array.isArray(parsed)) customPlugins = parsed;
    }
  } catch (err) {
    console.warn('[PLUGIN MANAGER] Failed to read registry:', err.message);
  }

  // If registry file exists, use it directly (preserving deletions and custom states)
  if (fs.existsSync(registryFile) && Array.isArray(customPlugins) && customPlugins.length > 0) {
    return customPlugins.filter((p) => !p.deleted);
  }

  // Initial default: all built-in plugins disabled by default
  return [...BUILTIN_PLUGINS];
}

function saveInstalledPlugins(appStorageDir, pluginsList) {
  const pluginsDir = getPluginStorageDir(appStorageDir);
  const registryFile = path.join(pluginsDir, 'installed_plugins.json');
  try {
    fs.writeFileSync(registryFile, JSON.stringify(pluginsList, null, 2), 'utf8');
    return true;
  } catch (err) {
    console.warn('[PLUGIN MANAGER] Failed to save registry:', err.message);
    return false;
  }
}

function togglePlugin(appStorageDir, pluginId, desiredState) {
  const list = getInstalledPlugins(appStorageDir);
  const target = list.find((p) => p.id === pluginId);
  if (!target) {
    throw new Error(`Plugin "${pluginId}" không tồn tại.`);
  }

  const newState = typeof desiredState === 'boolean' ? desiredState : !target.enabled;
  target.enabled = newState;
  saveInstalledPlugins(appStorageDir, list);
  return { success: true, plugin: target, enabled: newState };
}

const togglePluginState = togglePlugin;

function deletePlugin(appStorageDir, pluginId) {
  const list = getInstalledPlugins(appStorageDir);
  const targetIndex = list.findIndex((p) => p.id === pluginId);
  if (targetIndex < 0) {
    throw new Error(`Plugin "${pluginId}" không tồn tại.`);
  }

  const target = list[targetIndex];

  // Remove plugin directory if it exists
  const pluginsDir = getPluginStorageDir(appStorageDir);
  const targetPluginDir = path.join(pluginsDir, pluginId);
  try {
    if (fs.existsSync(targetPluginDir)) {
      fs.rmSync(targetPluginDir, { recursive: true, force: true });
    }
  } catch (err) {
    console.warn(`[PLUGIN] Failed to delete folder for ${pluginId}:`, err.message);
  }

  // Remove from installed list
  list.splice(targetIndex, 1);
  saveInstalledPlugins(appStorageDir, list);

  return { success: true, message: `Đã xóa plugin "${target.name}" thành công!` };
}

function updatePluginConfig(appStorageDir, pluginId, newConfig = {}) {
  const list = getInstalledPlugins(appStorageDir);
  const target = list.find((p) => p.id === pluginId);
  if (!target) {
    throw new Error(`Plugin "${pluginId}" không tồn tại.`);
  }

  target.config = { ...(target.config || {}), ...newConfig };
  saveInstalledPlugins(appStorageDir, list);
  return { success: true, plugin: target, config: target.config };
}

function importPluginFromManifest(appStorageDir, manifest) {
  if (!manifest || typeof manifest !== 'object') {
    throw new Error('Tệp manifest của plugin không hợp lệ.');
  }

  const id = String(manifest.id || manifest.name || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '-');
  if (!id) {
    throw new Error('Plugin thiếu thông tin ID hoặc Tên hợp lệ.');
  }

  const list = getInstalledPlugins(appStorageDir);
  const existingIndex = list.findIndex((p) => p.id === id);

  const newPluginRecord = {
    id,
    name: String(manifest.name || id).trim(),
    version: String(manifest.version || '1.0.0').trim(),
    author: String(manifest.author || 'Community Developer').trim(),
    type: String(manifest.type || 'tts').trim(),
    category: String(manifest.category || 'General Extension').trim(),
    description: String(manifest.description || 'Custom plugin extension.').trim(),
    icon: String(manifest.icon || '🧩').trim(),
    enabled: true,
    isBuiltin: false,
    installedAt: new Date().toISOString(),
    githubUrl: manifest.githubUrl || manifest.homepage || '',
    features: Array.isArray(manifest.features) ? manifest.features : ['Cài đặt từ tệp Import'],
    config: manifest.config || {},
    voices: Array.isArray(manifest.voices) ? manifest.voices : [],
  };

  if (existingIndex >= 0) {
    list[existingIndex] = { ...list[existingIndex], ...newPluginRecord };
  } else {
    list.push(newPluginRecord);
  }

  saveInstalledPlugins(appStorageDir, list);
  return newPluginRecord;
}

/**
 * Install a packaged plugin from a ZIP archive buffer or file path.
 * The ZIP must contain a plugin.json (or manifest.json) and can contain index.js, assets, etc.
 */
function installPluginPackage(appStorageDir, zipInput) {
  const AdmZip = require('adm-zip');
  let zip;
  try {
    zip = typeof zipInput === 'string' ? new AdmZip(zipInput) : new AdmZip(zipInput);
  } catch (err) {
    throw new Error(`Không thể giải nén tệp Package: ${err.message}`);
  }

  const zipEntries = zip.getEntries();
  if (!zipEntries || zipEntries.length === 0) {
    throw new Error('Tệp Package ZIP trống hoặc bị lỗi.');
  }

  // 1. Find plugin.json or manifest.json in root or first folder
  let manifestEntry = zipEntries.find(
    (e) => !e.isDirectory && (e.entryName.toLowerCase() === 'plugin.json' || e.entryName.toLowerCase().endsWith('/plugin.json') || e.entryName.toLowerCase() === 'manifest.json' || e.entryName.toLowerCase().endsWith('/manifest.json')),
  );

  if (!manifestEntry) {
    throw new Error('Package thiếu tệp cấu hình "plugin.json" hoặc "manifest.json".');
  }

  let manifest;
  try {
    const rawContent = manifestEntry.getData().toString('utf8');
    manifest = JSON.parse(rawContent);
  } catch (err) {
    throw new Error(`Tệp plugin.json trong package không hợp lệ: ${err.message}`);
  }

  const id = String(manifest.id || manifest.name || '')
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_-]/g, '-');
  if (!id) {
    throw new Error('Plugin thiếu thông tin ID hoặc Tên hợp lệ.');
  }

  const pluginsDir = getPluginStorageDir(appStorageDir);
  const targetPluginDir = path.join(pluginsDir, id);

  try {
    if (!fs.existsSync(targetPluginDir)) {
      fs.mkdirSync(targetPluginDir, { recursive: true });
    }
  } catch {}

  // 2. Extract files into storage/plugins/<id>/
  try {
    zip.extractAllTo(targetPluginDir, true);
  } catch (err) {
    throw new Error(`Lỗi giải nén vào thư mục plugin: ${err.message}`);
  }

  // List all extracted files
  const fileList = zipEntries.map((e) => e.entryName);

  // 3. Register in installed_plugins.json
  const list = getInstalledPlugins(appStorageDir);
  const existingIndex = list.findIndex((p) => p.id === id);

  const newPluginRecord = {
    id,
    name: String(manifest.name || id).trim(),
    version: String(manifest.version || '1.0.0').trim(),
    author: String(manifest.author || 'Community Developer').trim(),
    type: String(manifest.type || 'tts').trim(),
    category: String(manifest.category || 'General Extension').trim(),
    description: String(manifest.description || 'Custom packaged plugin.').trim(),
    icon: String(manifest.icon || '📦').trim(),
    enabled: true,
    isBuiltin: false,
    isPackage: true,
    packageDir: targetPluginDir,
    files: fileList,
    installedAt: new Date().toISOString(),
    githubUrl: manifest.githubUrl || manifest.homepage || '',
    features: Array.isArray(manifest.features) ? manifest.features : ['Đóng gói dạng ZIP Package'],
    config: manifest.config || {},
    voices: Array.isArray(manifest.voices) ? manifest.voices : [],
  };

  if (existingIndex >= 0) {
    list[existingIndex] = { ...list[existingIndex], ...newPluginRecord };
  } else {
    list.push(newPluginRecord);
  }

  saveInstalledPlugins(appStorageDir, list);
  return { plugin: newPluginRecord, extractedFiles: fileList, dir: targetPluginDir };
}

/**
 * Export any installed plugin into a downloadable .plugin.zip package buffer.
 */
function exportPluginAsPackage(appStorageDir, pluginId) {
  const AdmZip = require('adm-zip');
  const list = getInstalledPlugins(appStorageDir);
  const target = list.find((p) => p.id === pluginId);
  if (!target) {
    throw new Error(`Plugin "${pluginId}" không tồn tại.`);
  }

  const zip = new AdmZip();
  const pluginsDir = getPluginStorageDir(appStorageDir);
  const targetPluginDir = path.join(pluginsDir, pluginId);

  if (fs.existsSync(targetPluginDir)) {
    // Add existing files from plugin directory
    zip.addLocalFolder(targetPluginDir);
  } else {
    // Generate plugin.json manifest
    const manifest = {
      id: target.id,
      name: target.name,
      version: target.version || '1.0.0',
      author: target.author || 'AI Studio Developer',
      type: target.type || 'tts',
      category: target.category || 'General Extension',
      description: target.description || '',
      icon: target.icon || '🧩',
      githubUrl: target.githubUrl || '',
      features: target.features || [],
      config: target.config || {},
      voices: target.voices || [],
    };
    zip.addFile('plugin.json', Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'));

    // Generate boilerplate index.js
    const sampleCode = `/**
 * Plugin Entrypoint: ${target.name}
 * Type: ${target.type}
 */
module.exports = {
  id: "${target.id}",
  name: "${target.name}",
  async initialize(context) {
    console.log('[PLUGIN] Initialized ${target.name}');
  },
  async getVoices() {
    return [];
  },
  async onExecute(payload) {
    return { success: true };
  }
};
`;
    zip.addFile('index.js', Buffer.from(sampleCode, 'utf8'));
    zip.addFile('README.md', Buffer.from(`# ${target.name}\n\n${target.description}\n`, 'utf8'));
  }

  return zip.toBuffer();
}

/**
 * Generate starter template package for a given plugin type (tts, render, media, script).
 */
function createPluginPackageTemplate(type = 'tts') {
  const AdmZip = require('adm-zip');
  const zip = new AdmZip();

  const typeNameMap = {
    tts: {
      name: 'Custom TTS Voice Pack',
      category: 'Voice & Speech',
      icon: '🎙️',
      description: 'Gói plugin tích hợp giọng đọc AI mới đóng gói dạng ZIP.',
      features: ['Hỗ trợ giọng tùy biến', 'Tích hợp tự động vào Studio'],
      voices: [
        {
          id: 'custom_voice_01',
          name: 'Giọng Studio Pro (Mẫu)',
          speaker: 'spk_01',
          langCode: 'v',
          gender: 'female',
          description: 'Giọng đọc Studio chất lượng cao đóng gói từ plugin.',
        },
      ],
    },
    render: {
      name: 'Cloud Fast GPU Render',
      category: 'Render & Engine',
      icon: '⚡',
      description: 'Gói plugin tăng tốc Render video qua máy chủ GPU.',
      features: ['Render GPU NVENC', 'Hỗ trợ 4K 60fps'],
      voices: [],
    },
    media: {
      name: 'Pixabay Stock Media Provider',
      category: 'Stock Media',
      icon: '🎬',
      description: 'Gói plugin tự động tải video B-Roll minh họa.',
      features: ['Tìm kiếm video tự động', 'Chất lượng Full HD'],
      voices: [],
    },
    script: {
      name: 'Viral Script Doctor AI',
      category: 'AI Tools',
      icon: '✨',
      description: 'Gói plugin tối ưu câu Hook và kịch bản giữ chân người xem.',
      features: ['Phân tích Hook Score', 'Chèn CTA tự động'],
      voices: [],
    },
  };

  const meta = typeNameMap[type] || typeNameMap.tts;
  const manifest = {
    id: `custom-${type}-plugin`,
    name: meta.name,
    version: '1.0.0',
    author: 'Community Developer',
    type,
    category: meta.category,
    description: meta.description,
    icon: meta.icon,
    entry: 'index.js',
    features: meta.features,
    voices: meta.voices,
    config: {
      endpointUrl: 'http://127.0.0.1:8000',
      apiKey: '',
    },
  };

  zip.addFile('plugin.json', Buffer.from(JSON.stringify(manifest, null, 2), 'utf8'));

  const handlerCode = `/**
 * Plugin: ${manifest.name}
 * Entrypoint Handler
 */
module.exports = {
  id: "${manifest.id}",
  type: "${manifest.type}",

  // Hook 1: Khởi tạo
  async initialize(context) {
    console.log('[PLUGIN] Initialized ${manifest.name}');
  },

  // Hook 2: Trả về danh sách giọng đọc nếu là TTS
  async getVoices() {
    return ${JSON.stringify(meta.voices, null, 2)};
  },

  // Hook 3: Xử lý chức năng chính
  async execute(params) {
    console.log('[PLUGIN] Executing task with params:', params);
    return { success: true, message: 'Executed successfully.' };
  }
};
`;

  zip.addFile('index.js', Buffer.from(handlerCode, 'utf8'));
  zip.addFile(
    'README.md',
    Buffer.from(
      `# ${manifest.name}\n\n${manifest.description}\n\n## Cấu trúc Package\n- \`plugin.json\`: Manifest mô tả thông tin và cấu hình.\n- \`index.js\`: Mã nguồn xử lý chính.\n`,
      'utf8',
    ),
  );

  return zip.toBuffer();
}

module.exports = {
  BUILTIN_PLUGINS,
  getInstalledPlugins,
  saveInstalledPlugins,
  togglePlugin,
  deletePlugin,
  updatePluginConfig,
  importPluginFromManifest,
  installPluginPackage,
  exportPluginAsPackage,
  createPluginPackageTemplate,
};

