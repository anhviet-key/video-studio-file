const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const crypto = require('node:crypto');

// Integer LSTM weights: compatible with the shipped Tesseract.js WASM core.
// Do not replace these with floating-point tessdata_best without a runtime probe.
const MODEL_REVISION = '87416418657359cb625c412a48b6e1d6d41c29bd';
const ENGINE = 'tesseract-vie-lstm';
const MODELS = Object.freeze([
  { language: 'vie', bytes: 531275, sha256: '79df64caf7bcfb2a27df5042ecb6121e196eada34da774956995747636d5bfa1' },
  { language: 'eng', bytes: 4113088, sha256: '7d4322bd2a7749724879683fc3912cb542f19906c83bcc1a52132556427170b2' },
]);
const preparations = new Map();

function isVietnameseOcrLanguage(language) {
  const tokens = String(language || '').trim().toLowerCase().split('+');
  return tokens.some(token => ['vie', 'vi', 'v', 'vietnamese'].includes(token));
}

function getVietnameseOcrModelDir() {
  return path.resolve(process.env.LOCAL_RUNTIME_VIETNAMESE_OCR_MODEL_DIR || path.join(
    process.env.LOCALAPPDATA || path.join(os.homedir(), 'AppData', 'Local'),
    'AI Video Studio', 'runtime', 'ocr-vietnamese',
  ));
}

function verifiedModel(modelDir, model) {
  try {
    const data = fs.readFileSync(path.join(modelDir, `${model.language}.traineddata`));
    return data.length === model.bytes && crypto.createHash('sha256').update(data).digest('hex') === model.sha256;
  } catch { return false; }
}

function isVietnameseOcrAvailable(modelDir = getVietnameseOcrModelDir()) {
  try {
    const marker = JSON.parse(fs.readFileSync(path.join(modelDir, '.ready.json'), 'utf8'));
    return marker.engine === ENGINE && marker.revision === MODEL_REVISION && MODELS.every(model => verifiedModel(modelDir, model));
  } catch { return false; }
}

async function createVietnameseOcrWorker({ modelDir = getVietnameseOcrModelDir(), requirePrepared = true, createWorker } = {}) {
  if (!(requirePrepared ? isVietnameseOcrAvailable(modelDir) : MODELS.every(model => verifiedModel(modelDir, model)))) {
    throw new Error('Vietnamese OCR model is not ready. Select VI and initialize the OCR model in Settings.');
  }
  const factory = createWorker || require('tesseract.js').createWorker;
  const worker = await factory('vie+eng', 1, {
    langPath: modelDir, gzip: false, cacheMethod: 'none', errorHandler: () => {},
  });
  try {
    // Read both subtitle lines. A narrow ROI does not prove there is only one.
    await worker.setParameters({ tessedit_pageseg_mode: '6', user_defined_dpi: '300', preserve_interword_spaces: '1' });
    worker.engine = ENGINE;
    return worker;
  } catch (error) {
    await worker.terminate().catch(() => {});
    throw error;
  }
}

async function prepareVietnameseOcr({ modelDir = getVietnameseOcrModelDir(), fetchModel = globalThis.fetch, createWorker } = {}) {
  if (isVietnameseOcrAvailable(modelDir)) return { engine: ENGINE, bytes: MODELS.reduce((sum, model) => sum + model.bytes, 0) };
  if (preparations.has(modelDir)) return preparations.get(modelDir);
  const pending = (async () => {
    fs.mkdirSync(modelDir, { recursive: true });
    for (const model of MODELS) {
      if (verifiedModel(modelDir, model)) continue;
      const url = `https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/${MODEL_REVISION}/${model.language}.traineddata`;
      const response = await fetchModel(url, { signal: AbortSignal.timeout(90000), redirect: 'error' });
      if (!response.ok) throw new Error(`Vietnamese OCR model download failed (HTTP ${response.status}).`);
      const reader = response.body.getReader();
      const chunks = []; let total = 0;
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          total += value.byteLength;
          if (total > model.bytes) throw new Error('Vietnamese OCR model has an unexpected size.');
          chunks.push(Buffer.from(value));
        }
      } finally { await reader.cancel().catch(() => {}); }
      const data = Buffer.concat(chunks);
      if (data.length !== model.bytes || crypto.createHash('sha256').update(data).digest('hex') !== model.sha256) {
        throw new Error('Vietnamese OCR model integrity verification failed.');
      }
      const target = path.join(modelDir, `${model.language}.traineddata`);
      const temporary = `${target}.${crypto.randomUUID()}.tmp`;
      try {
        fs.writeFileSync(temporary, data, { flag: 'wx' });
        fs.renameSync(temporary, target);
      } finally { try { fs.unlinkSync(temporary); } catch {} }
    }
    const worker = await createVietnameseOcrWorker({ modelDir, requirePrepared: false, createWorker });
    try {
      const sharp = require('sharp');
      const expected = 'Hệ thống hỗ trợ phụ đề và lồng tiếng.';
      const image = await sharp(Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="120"><rect width="1100" height="120" fill="white"/><text x="40" y="76" font-family="Arial, sans-serif" font-size="36" fill="black">${expected}</text></svg>`)).png().toBuffer();
      const result = await worker.recognize(image);
      const text = String(result?.data?.text || '').normalize('NFC').replace(/\s+/g, ' ').trim();
      if (text !== expected) throw new Error('Vietnamese OCR recognition probe failed; the model was not marked ready.');
      const marker = path.join(modelDir, '.ready.json');
      const temporary = `${marker}.${crypto.randomUUID()}.tmp`;
      try {
        fs.writeFileSync(temporary, JSON.stringify({ engine: ENGINE, revision: MODEL_REVISION, preparedAt: new Date().toISOString() }), { flag: 'wx' });
        fs.renameSync(temporary, marker);
      } finally { try { fs.unlinkSync(temporary); } catch {} }
      return { engine: ENGINE, bytes: MODELS.reduce((sum, model) => sum + model.bytes, 0) };
    } finally { await worker.terminate().catch(() => {}); }
  })();
  preparations.set(modelDir, pending);
  try { return await pending; } finally { preparations.delete(modelDir); }
}

module.exports = { ENGINE, MODELS, MODEL_REVISION, isVietnameseOcrLanguage, getVietnameseOcrModelDir, isVietnameseOcrAvailable, createVietnameseOcrWorker, prepareVietnameseOcr };
