const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const zlib = require('zlib');

const CAPCUT_VOICES = [
  // --- VIETNAMESE (v) ---
  {
    id: 'capcut_vi_female_1',
    speaker: 'bv001_streaming',
    name: 'Nữ chuẩn CapCut (TikTok)',
    gender: 'female',
    category: 'Popular',
    lang: 'vi',
    description: 'Giọng nữ đọc nhẹ nhàng, ấm áp, phổ biến nhất trên TikTok & CapCut.',
    avatar: '🎙️',
  },
  {
    id: 'capcut_vi_male_1',
    speaker: 'bv002_streaming',
    name: 'Nam truyền cảm MC (CapCut)',
    gender: 'male',
    category: 'Popular',
    lang: 'vi',
    description: 'Giọng nam truyền cảm, phong cách kể chuyện và review phim.',
    avatar: '🎬',
  },
  {
    id: 'capcut_vi_kid_1',
    speaker: 'bv523_streaming',
    name: 'Nữ tâm sự ngọt ngào (CapCut)',
    gender: 'female',
    category: 'Storytelling',
    lang: 'vi',
    description: 'Giọng nữ ngọt ngào, mượt mà, chuyên tâm sự và đọc truyện.',
    avatar: '💖',
  },
  {
    id: 'capcut_bv001',
    speaker: 'bv001_streaming',
    name: 'Nữ Google chuẩn (TikTok)',
    gender: 'female',
    category: 'News & Info',
    lang: 'vi',
    description: 'Giọng nữ Google quen thuộc trên các video tin tức ngắn.',
    avatar: '📰',
  },
  {
    id: 'capcut_bv002',
    speaker: 'bv002_streaming',
    name: 'Nam tin tức MC (TikTok)',
    gender: 'male',
    category: 'News & Info',
    lang: 'vi',
    description: 'Giọng nam đọc thời sự, phong cách phát thanh viên chuyên nghiệp.',
    avatar: '📻',
  },
  {
    id: 'capcut_bv523',
    speaker: 'bv523_streaming',
    name: 'Nữ ngọt ngào (TikTok)',
    gender: 'female',
    category: 'Storytelling',
    lang: 'vi',
    description: 'Giọng nữ ngọt ngào, mượt mà, chuyên tâm sự và đọc truyện.',
    avatar: '💖',
  },
  {
    id: 'capcut_bv524',
    speaker: 'bv524_streaming',
    name: 'Nam sảng khoái (TikTok)',
    gender: 'male',
    category: 'Storytelling',
    lang: 'vi',
    description: 'Giọng nam trẻ trung, năng động, phong cách Vlogger.',
    avatar: '⚡',
  },
  {
    id: 'capcut_bv066',
    speaker: 'bv066_streaming',
    name: 'Nữ vui vẻ (TikTok)',
    gender: 'female',
    category: 'Anime & Fun',
    lang: 'vi',
    description: 'Giọng nữ hoạt bát, vui nhộn cho video giải trí.',
    avatar: '✨',
  },
  {
    id: 'capcut_bv063',
    speaker: 'bv063_streaming',
    name: 'Nam tâm sự (TikTok)',
    gender: 'male',
    category: 'Storytelling',
    lang: 'vi',
    description: 'Giọng nam trầm ấm, suy tư, lắng đọng.',
    avatar: '🌙',
  },

  // --- ENGLISH US (a) ---
  {
    id: 'capcut_en_us_001',
    speaker: 'en_us_001',
    name: 'Jessie (US Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'en-us',
    description: 'The iconic US female TikTok voice for vlog and shorts.',
    avatar: '👩',
  },
  {
    id: 'capcut_en_us_002',
    speaker: 'en_us_002',
    name: 'Alicia (US Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'en-us',
    description: 'Friendly and energetic American female narrator.',
    avatar: '🌟',
  },
  {
    id: 'capcut_en_us_006',
    speaker: 'en_us_006',
    name: 'Joey (US Male)',
    gender: 'male',
    category: 'Popular',
    lang: 'en-us',
    description: 'Natural, confident young American male voice.',
    avatar: '👦',
  },
  {
    id: 'capcut_en_us_007',
    speaker: 'en_us_007',
    name: 'Professor (US Male)',
    gender: 'male',
    category: 'News & Info',
    lang: 'en-us',
    description: 'Deep, authoritative tone suitable for educational content.',
    avatar: '🎓',
  },
  {
    id: 'capcut_en_us_009',
    speaker: 'en_us_009',
    name: 'Scientist (US Male)',
    gender: 'male',
    category: 'News & Info',
    lang: 'en-us',
    description: 'Smart and engaging male presenter voice.',
    avatar: '🔬',
  },
  {
    id: 'capcut_en_us_010',
    speaker: 'en_us_010',
    name: 'Confidence (US Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'en-us',
    description: 'Smooth and crisp female voice for commercial ads.',
    avatar: '💼',
  },
  {
    id: 'capcut_en_female_emotional',
    speaker: 'en_female_emotional',
    name: 'Peaceful (US Female)',
    gender: 'female',
    category: 'Storytelling',
    lang: 'en-us',
    description: 'Gentle, soothing voice for meditation and storytelling.',
    avatar: '🕊️',
  },
  {
    id: 'capcut_en_male_m03_lobby',
    speaker: 'en_male_m03_lobby',
    name: 'Storyteller (US Male)',
    gender: 'male',
    category: 'Storytelling',
    lang: 'en-us',
    description: 'Classic cinematic story narrator with rich bass.',
    avatar: '📖',
  },
  {
    id: 'capcut_en_male_funny',
    speaker: 'en_male_funny',
    name: 'Wacky (US Male)',
    gender: 'male',
    category: 'Anime & Fun',
    lang: 'en-us',
    description: 'Humorous, expressive cartoon-style voice.',
    avatar: '🤪',
  },

  // --- ENGLISH UK (b) ---
  {
    id: 'capcut_en_uk_001',
    speaker: 'en_uk_001',
    name: 'Narrator (UK Male)',
    gender: 'male',
    category: 'Popular',
    lang: 'en-uk',
    description: 'Classic British male narrator for documentaries.',
    avatar: '🎩',
  },
  {
    id: 'capcut_en_uk_003',
    speaker: 'en_uk_003',
    name: 'Warm Male (UK)',
    gender: 'male',
    category: 'Storytelling',
    lang: 'en-uk',
    description: 'Pleasant British male accent, great for guides and reviews.',
    avatar: '☕',
  },

  // --- JAPANESE (j) ---
  {
    id: 'capcut_jp_001',
    speaker: 'jp_001',
    name: 'Miho (JP Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'ja',
    description: 'Cute and polite Japanese female voice.',
    avatar: '🌸',
  },
  {
    id: 'capcut_jp_003',
    speaker: 'jp_003',
    name: 'Keiko (JP Female Anime)',
    gender: 'female',
    category: 'Anime & Fun',
    lang: 'ja',
    description: 'High-pitched anime girl voice.',
    avatar: '🎀',
  },
  {
    id: 'capcut_jp_005',
    speaker: 'jp_005',
    name: 'Kenichi (JP Male)',
    gender: 'male',
    category: 'Popular',
    lang: 'ja',
    description: 'Calm and steady Japanese male voice.',
    avatar: '🏯',
  },

  // --- KOREAN (ko) ---
  {
    id: 'capcut_kr_002',
    speaker: 'kr_002',
    name: 'Yuna (KR Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'ko',
    description: 'Sweet and clear Korean female K-Drama style.',
    avatar: '🌺',
  },
  {
    id: 'capcut_kr_003',
    speaker: 'kr_003',
    name: 'Minho (KR Male)',
    gender: 'male',
    category: 'Popular',
    lang: 'ko',
    description: 'Youthful Korean male voice for trends and vlogs.',
    avatar: '🎧',
  },

  // --- CHINESE (c) ---
  {
    id: 'capcut_zh_female_xiaoxiao',
    speaker: 'zh_female_xiaoxiao',
    name: 'Xiaoxiao (CN Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'zh',
    description: 'Standard Mandarin sweet female narrator.',
    avatar: '🏮',
  },
  {
    id: 'capcut_zh_male_yunxi',
    speaker: 'zh_male_yunxi',
    name: 'Yunxi (CN Male)',
    gender: 'male',
    category: 'Popular',
    lang: 'zh',
    description: 'Smooth and pleasant Mandarin male presenter.',
    avatar: '🐉',
  },

  // --- SPANISH (e) ---
  {
    id: 'capcut_es_002',
    speaker: 'es_002',
    name: 'Sofia (ES Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'es',
    description: 'Lively Spanish female voice for general content.',
    avatar: '💃',
  },
  {
    id: 'capcut_es_male_m3',
    speaker: 'es_male_m3',
    name: 'Carlos (ES Male)',
    gender: 'male',
    category: 'Popular',
    lang: 'es',
    description: 'Warm and expressive Spanish male voice.',
    avatar: '🎸',
  },

  // --- FRENCH (f) ---
  {
    id: 'capcut_fr_001',
    speaker: 'fr_001',
    name: 'Amelie (FR Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'fr',
    description: 'Elegant Parisian French female narrator.',
    avatar: '🥐',
  },

  // --- GERMAN (d) ---
  {
    id: 'capcut_de_001',
    speaker: 'de_001',
    name: 'Greta (DE Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'de',
    description: 'Clear and articulate German female voice.',
    avatar: '🏰',
  },

  // --- PORTUGUESE (p) ---
  {
    id: 'capcut_pt_001',
    speaker: 'pt_001',
    name: 'Luana (BR Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'pt',
    description: 'Vibrant Brazilian Portuguese female voice.',
    avatar: '🌴',
  },

  // --- INDONESIAN (id) ---
  {
    id: 'capcut_id_001',
    speaker: 'id_001',
    name: 'Putri (ID Female)',
    gender: 'female',
    category: 'Popular',
    lang: 'id',
    description: 'Natural and friendly Indonesian female voice.',
    avatar: '🏝️',
  },
];

let loadedCatalogVoices = null;

function loadVoiceCatalogFromJson() {
  if (loadedCatalogVoices && loadedCatalogVoices.length > 0) {
    return loadedCatalogVoices;
  }
  const candidatePaths = [
    path.join(__dirname, 'Voice.json'),
    path.join(__dirname, '..', 'storage', 'Voice.json'),
    path.join(__dirname, '..', '..', 'tools', 'capcut-tts-api', 'Voice.json'),
  ];
  for (const p of candidatePaths) {
    try {
      if (fs.existsSync(p)) {
        const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (Array.isArray(raw) && raw.length > 0) {
          const seen = new Set();
          const parsed = [];
          for (const item of raw) {
            const speakerCode = String(item.voice_type || '').trim();
            if (!speakerCode || seen.has(speakerCode)) continue;
            seen.add(speakerCode);

            const rawLang = String(item.lan || item.lang || 'vi').toLowerCase();
            const cleanLang = rawLang.includes('vi')
              ? 'vi'
              : rawLang.includes('th')
                ? 'th'
                : rawLang.includes('zh') || rawLang.includes('cn')
                  ? 'zh'
                  : rawLang.includes('ja') || rawLang.includes('jp')
                    ? 'ja'
                    : rawLang.includes('ko') || rawLang.includes('kr')
                      ? 'ko'
                      : rawLang.includes('es')
                        ? 'es'
                        : rawLang.includes('fr')
                          ? 'fr'
                          : rawLang.includes('de')
                            ? 'de'
                            : rawLang.includes('pt') || rawLang.includes('br')
                              ? 'pt'
                              : rawLang.includes('id')
                                ? 'id'
                                : 'en-us';
            const dispName = item.display_name || '';
            const combinedText = `${speakerCode} ${dispName}`.toLowerCase();
            let gender = 'female';
            if (/nam\b|giọng nam|nam bản tin|nam minh|thanh niên|alex|kenny|felipe|demon/i.test(combinedText)) {
              gender = 'male';
            } else if (/(?:^|_)female(?:_|$)|gai|nu|girl|sweet|mai|huong|sisi|peiqi|kiwi|nữ|cô\b/i.test(combinedText)) {
              gender = 'female';
            } else if (/(?:^|_)male(?:_|$)|boy|chàng|anh\b/i.test(combinedText)) {
              gender = 'male';
            }
            parsed.push({
              id: `capcut_${speakerCode}`,
              speaker: speakerCode,
              resource_id: item.resource_id,
              name: item.display_name || speakerCode,
              gender,
              category: cleanLang === 'vi' ? 'Vietnamese' : 'Popular',
              lang: cleanLang,
              description: `Giọng CapCut chính hãng: ${item.display_name || speakerCode}`,
              avatar: gender === 'female' ? '👩' : '👨',
            });
          }
          loadedCatalogVoices = parsed;
          return loadedCatalogVoices;
        }
      }
    } catch {}
  }
  return null;
}

async function fetchImpl(url, options = {}) {
  if (typeof globalThis.fetch === 'function') {
    return globalThis.fetch(url, options);
  }
  const nodeFetch = require('node-fetch');
  return nodeFetch(url, options);
}

function getCapCutVoices() {
  const dynamicVoices = loadVoiceCatalogFromJson();
  if (dynamicVoices && dynamicVoices.length > 0) {
    return dynamicVoices;
  }
  return CAPCUT_VOICES;
}

const NATIVE_BASE_URL = 'https://editor-api-sg.capcutapi.com';

const NATIVE_DEFAULT_DEVICE = {
  aid: '359289',
  app_name: 'CapCut',
  appvr: '8.7.0',
  version_name: '8.7.0',
  version_code: '8.7.0',
  channel: 'capcutpc_google',
  device_platform: 'mac',
  device_type: 'MacBookPro17,4',
  device_brand: 'MacBookPro17,4',
  os_version: '15.7.4',
  device_id: '76471456455646328721',
  iid: '76471456455646328721',
  region: 'VN',
  loc: 'VN',
  lan: 'vi-VN',
  pf: '3',
  tdid: '76471456455646328721',
};

const NATIVE_TTS_SIGN_PUBLIC_KEY_PEM = `-----BEGIN PUBLIC KEY-----
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAmTd34Lw4b7IuldSXh/zY
CMla+ITdGG5TeWz6ad+OySd4r+IrY45AoqrYUxhQ2dl+7z+i7r/5vEa8rr39BYfB
8AGMQLmZA8HmgpWBsqrn/V6daUALkKnkLb70Fn32CJigIuGXAYqxUdGuI340aC+0
v5Es3puJsHyzf01/AelE4Cdc6bZhQrASJLBh8R3BQToYClmDVSDUQk28o8sl/guA
Z4n303Vj+6Siv1HayPCdV6kpVVnMBAG4+umUbwGmn132N3fgpzLarFF3XyWmS1zh
D/J07iM/rP8GDO9IskHNHd2phrO0G6KzrcFAnTBHjVv+hCBEfzN/no3FNA9AuC36
mwIDAQAB
-----END PUBLIC KEY-----`;

const NATIVE_SPEAKER_TO_VOICE_MAP = {
  // Vietnamese
  vi_001: ['BV421_vivn_streaming', '7252594014782755330'],
  bv001_streaming: ['BV421_vivn_streaming', '7252594014782755330'],
  capcut_vi_female_1: ['BV421_vivn_streaming', '7252594014782755330'],
  capcut_bv001: ['BV421_vivn_streaming', '7252594014782755330'],

  vi_002: ['BV075_streaming', '7102355803792740865'],
  bv002_streaming: ['BV075_streaming', '7102355803792740865'],
  capcut_vi_male_1: ['BV075_streaming', '7102355803792740865'],
  capcut_bv002: ['BV075_streaming', '7102355803792740865'],

  vi_003: ['BV074_streaming_dsp', '7550087831092251920'],
  bv523_streaming: ['multi_female_tianmeijieshuo_uranus_bigtts', '7637460417295469832'],
  capcut_vi_kid_1: ['BV074_streaming_dsp', '7550087831092251920'],
  capcut_bv523: ['multi_female_tianmeijieshuo_uranus_bigtts', '7637460417295469832'],

  vi_004: ['BV074_streaming', '7102355709945188865'],
  bv524_streaming: ['multi_male_felipe_uranus_bigtts', '7637456729696996628'],
  capcut_bv524: ['multi_male_felipe_uranus_bigtts', '7637456729696996628'],

  vi_005: ['BV560_streaming', '7483736167565758992'],
  bv560_streaming: ['BV560_streaming', '7483736167565758992'],

  vi_female_cuoi: ['multi_female_tianmeijieshuo_uranus_bigtts', '7637460417295469832'],
  vi_male_khoai: ['multi_male_felipe_uranus_bigtts', '7637456729696996628'],
  vi_female_vui: ['multi_female_yangguangnv_uranus_bigtts', '7637456432522218773'],
  bv066_streaming: ['multi_female_yangguangnv_uranus_bigtts', '7637456432522218773'],
  capcut_bv066: ['multi_female_yangguangnv_uranus_bigtts', '7637456432522218773'],

  vi_male_tamsu: ['multi_female_xinwenjieshuo_uranus_bigtts', '7637455039719640327'],
  bv063_streaming: ['multi_female_xinwenjieshuo_uranus_bigtts', '7637455039719640327'],
  capcut_bv063: ['multi_female_xinwenjieshuo_uranus_bigtts', '7637455039719640327'],

  vi_female_huong: ['vi_female_huong', '7264854897953083905'],
  vi_mai: ['BV562_streaming', '7483736254694035984'],
  BV562_streaming: ['BV562_streaming', '7483736254694035984'],
  vi_review_phim: ['multi_female_richgirl_uranus_bigtts', '7637460351541447956'],
  vi_sunny_idol: ['multi_female_kiwi_uranus_bigtts', '7637457995882089749'],
  multi_female_richgirl_uranus_bigtts: ['multi_female_richgirl_uranus_bigtts', '7637460351541447956'],
  multi_female_kiwi_uranus_bigtts: ['multi_female_kiwi_uranus_bigtts', '7637457995882089749'],
  multi_female_tianmeijieshuo_uranus_bigtts: ['multi_female_tianmeijieshuo_uranus_bigtts', '7637460417295469832'],
  multi_male_felipe_uranus_bigtts: ['multi_male_felipe_uranus_bigtts', '7637456729696996628'],
  multi_female_yangguangnv_uranus_bigtts: ['multi_female_yangguangnv_uranus_bigtts', '7637456432522218773'],
  multi_female_xinwenjieshuo_uranus_bigtts: ['multi_female_xinwenjieshuo_uranus_bigtts', '7637455039719640327'],
  BV421_vivn_streaming: ['BV421_vivn_streaming', '7252594014782755330'],
  BV074_streaming_dsp: ['BV074_streaming_dsp', '7550087831092251920'],
  BV074_streaming: ['BV074_streaming', '7102355709945188865'],
  BV075_streaming: ['BV075_streaming', '7102355803792740865'],
  BV075_streaming_vibrato_dsp: ['BV075_streaming_vibrato_dsp', '7569450639810465040'],
  'vi-VN-HoaiMyNeural': ['vi-VN-HoaiMyNeural', '7371666434650280464'],
  'vi-VN-NamMinhNeural': ['vi-VN-NamMinhNeural', '7371666524727153168'],

  // English
  en_us_001: ['BV074_streaming', '7102355709945188865'],
  en_us_002: ['BV075_streaming', '7102355803792740865'],
  en_us_006: ['BV074_streaming', '7102355709945188865'],
  en_us_007: ['BV075_streaming', '7102355803792740865'],
  en_us_009: ['BV074_streaming', '7102355709945188865'],
  en_us_010: ['BV075_streaming', '7102355803792740865'],

  // Japanese
  ja_001: ['BV520_streaming', '7483735874258079760'],
  ja_003: ['BV521_streaming', '7483735957796033552'],

  // Korean
  ko_001: ['BV500_streaming', '7483735745400672272'],
  ko_002: ['BV501_streaming', '7483735824555574288'],
};

function resolveVoiceAndResourceId(speakerOrId) {
  const norm = String(speakerOrId || '').trim();
  const lower = norm.toLowerCase();

  // 1. Direct lookup in static map
  if (NATIVE_SPEAKER_TO_VOICE_MAP[norm]) {
    return NATIVE_SPEAKER_TO_VOICE_MAP[norm];
  }
  if (NATIVE_SPEAKER_TO_VOICE_MAP[lower]) {
    return NATIVE_SPEAKER_TO_VOICE_MAP[lower];
  }
  const stripped = lower.replace(/^capcut_/, '');
  if (NATIVE_SPEAKER_TO_VOICE_MAP[stripped]) {
    return NATIVE_SPEAKER_TO_VOICE_MAP[stripped];
  }

  // 2. Dynamic catalog lookup from Voice.json
  const catalog = loadVoiceCatalogFromJson() || [];
  for (const item of catalog) {
    const itemVoice = String(item.speaker || item.voice_type || '').trim();
    const itemId = String(item.id || '').trim();
    const itemDisp = String(item.name || item.display_name || '').trim();

    if (
      itemVoice.toLowerCase() === lower ||
      itemVoice.toLowerCase() === stripped ||
      itemId.toLowerCase() === lower ||
      itemId.toLowerCase() === `capcut_${lower}` ||
      itemDisp.toLowerCase() === lower
    ) {
      if (item.resource_id) {
        return [itemVoice, item.resource_id];
      }
    }
  }

  // 3. Check raw catalog file directly if needed
  const rawCatalogCandidates = [
    path.join(__dirname, 'Voice.json'),
    path.join(__dirname, '..', 'storage', 'Voice.json'),
    path.join(__dirname, '..', '..', 'tools', 'capcut-tts-api', 'Voice.json'),
  ];
  for (const p of rawCatalogCandidates) {
    try {
      if (fs.existsSync(p)) {
        const raw = JSON.parse(fs.readFileSync(p, 'utf8'));
        if (Array.isArray(raw)) {
          const match = raw.find((v) => {
            const vt = String(v.voice_type || '').trim().toLowerCase();
            const dn = String(v.display_name || '').trim().toLowerCase();
            return vt === lower || vt === stripped || dn === lower;
          });
          if (match && match.voice_type && match.resource_id) {
            return [match.voice_type, match.resource_id];
          }
        }
      }
    } catch {}
  }

  // 4. Default fallback: Vietnamese voice if looks Vietnamese, else default CapCut narrator
  if (lower.startsWith('vi') || lower.includes('viet') || lower.includes('bv001')) {
    return ['BV421_vivn_streaming', '7252594014782755330'];
  }
  return ['BV074_streaming', '7102355709945188865'];
}

function splitTextIntoChunks(text, maxChunkLen = 280) {
  const raw = String(text || '').trim();
  if (!raw) return [];
  if (raw.length <= maxChunkLen) return [raw];

  const sentenceRegex = /[^.!?\r\n]+(?:[.!?\r\n]+|$)/g;
  const rawSentences = raw.match(sentenceRegex) || [raw];
  const chunks = [];
  let currentChunk = '';

  for (const sentence of rawSentences) {
    const trimmed = sentence.trim();
    if (!trimmed) continue;

    if (trimmed.length > maxChunkLen) {
      if (currentChunk) {
        chunks.push(currentChunk.trim());
        currentChunk = '';
      }
      const words = trimmed.split(/\s+/);
      let subChunk = '';
      for (const word of words) {
        if ((subChunk + ' ' + word).trim().length <= maxChunkLen) {
          subChunk = (subChunk + ' ' + word).trim();
        } else {
          if (subChunk) chunks.push(subChunk);
          subChunk = word;
        }
      }
      if (subChunk) chunks.push(subChunk);
    } else {
      if ((currentChunk + ' ' + trimmed).trim().length <= maxChunkLen) {
        currentChunk = (currentChunk + ' ' + trimmed).trim();
      } else {
        if (currentChunk) chunks.push(currentChunk.trim());
        currentChunk = trimmed;
      }
    }
  }
  if (currentChunk) chunks.push(currentChunk.trim());
  return chunks.length ? chunks : [raw];
}

async function synthesizeNativeChunk(text, voiceType, resourceId, rate = '1.0') {
  const device = NATIVE_DEFAULT_DEVICE;
  const babi = {
    feature_entrance: 'editor',
    feature_entrance_detail: 'editor-feature-text_to_speech',
    feature_key: 'text_to_speech',
    scenario: 'video_editor',
  };

  const escapeXml = (s) =>
    String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&apos;');

  const voiceBlocks = [
    `    <voice name="${voiceType}" mock_tone_info="" platform="sami" ` +
    `resource_id="${resourceId}" emotion="" emotion_scale="0" style="" role="" ` +
    `moyin_emotion="" is_clone_tone="false" need_subtitle_timestamp="false">\n` +
    `        <prosody rate="${rate}">${escapeXml(text)}</prosody>\n` +
    `    </voice>`,
  ];
  const ssml =
    '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">\n' +
    voiceBlocks.join('\n') +
    '\n</speak>';

  const extraInfo = JSON.stringify({ benefit_info: {} });
  const ssmlMd5 = crypto.createHash('md5').update(ssml, 'utf8').digest('hex');
  const signInput = `appid:${device.aid}&did:${device.device_id}&creditDisable:false&ssml:${ssmlMd5}&extraInfo:${extraInfo}`;
  const payloadSign = crypto.publicEncrypt(
    {
      key: NATIVE_TTS_SIGN_PUBLIC_KEY_PEM,
      padding: crypto.constants.RSA_PKCS1_PADDING,
    },
    Buffer.from(signInput, 'utf8')
  ).toString('base64');

  const payload = {
    audio_format: 'mp3',
    babi_param: JSON.stringify(babi),
    credit_disable: false,
    extra_info: extraInfo,
    need_merge_voice: false,
    need_subtitle_timestamp: false,
    scene: 'text_to_speech',
    ssml,
    sign: payloadSign,
  };

  const body = {
    bind_id: crypto.randomUUID(),
    can_queue: true,
    enter_from: 'text_to_speech',
    tasks: [
      {
        context: crypto.randomUUID(),
        payload: JSON.stringify(payload),
        req_key: 'sami_text_to_speech',
        task_version: 'v3',
      },
    ],
  };

  const bodyText = JSON.stringify(body);
  const now = Math.floor(Date.now() / 1000).toString();
  const seed = crypto.randomBytes(16).toString('hex');
  const traceId = `00-${seed}-${seed.slice(0, 16)}-01`;
  const xSsStub = crypto.createHash('md5').update(bodyText, 'utf8').digest('hex');

  const pathPart = '/lv/v1/common_task/new';
  const queryObj = {
    app_name: device.app_name,
    device_type: device.device_type,
    os_version: device.os_version,
    channel: device.channel,
    version_name: device.version_name,
    device_brand: device.device_brand,
    device_id: device.device_id,
    iid: device.iid,
    version_code: device.version_code,
    device_platform: device.device_platform,
    aid: device.aid,
    region: device.region,
    babi_param: JSON.stringify(babi),
  };
  const url = `${NATIVE_BASE_URL}${pathPart}?${new URLSearchParams(queryObj).toString()}`;
  const signHeader = crypto
    .createHash('md5')
    .update(`9e2c|${pathPart.slice(-7)}|3|${device.appvr}|${now}|${device.tdid}|11ac`, 'utf8')
    .digest('hex');

  const headers = {
    'content-type': 'application/json',
    appvr: device.appvr,
    ch: device.channel,
    'device-time': now,
    lan: device.lan,
    loc: device.loc,
    pf: device.pf,
    'sign-ver': '1',
    tdid: device.tdid,
    'x-ss-stub': xSsStub,
    'x-ss-dp': device.aid,
    'x-khronos': now,
    'x-tt-trace-id': traceId,
    'user-agent': 'Cronet/TTNetVersion:1d7cc3b1 2025-07-16 QuicVersion:52c2b40d 2025-04-03',
    'accept-encoding': 'gzip, deflate',
    'store-country-code': device.loc.toLowerCase(),
    'store-country-code-src': 'did',
    'is-dispatch-us-ttp': '0',
    'is-app-region-us-ttp': '0',
    'app-sdk-version': device.appvr,
    appid: device.aid,
    sign: signHeader,
  };

  const createRes = await fetchImpl(url, {
    method: 'POST',
    headers,
    body: bodyText,
  });

  const arrayBuf = await createRes.arrayBuffer();
  let rawBuf = Buffer.from(arrayBuf);
  if (rawBuf.length >= 2 && rawBuf[0] === 0x1f && rawBuf[1] === 0x8b) {
    try { rawBuf = zlib.gunzipSync(rawBuf); } catch {}
  }
  const createData = JSON.parse(rawBuf.toString('utf8'));
  const tasks = createData?.data?.tasks || [];
  if (!tasks.length) {
    throw new Error('CapCut create task failed: ' + (createData?.errmsg || JSON.stringify(createData)));
  }

  const taskId = tasks[0].id;
  const token = tasks[0].token;

  // Polling query
  const qPath = '/lv/v1/common_task/query';
  const qQueryObj = {
    app_name: device.app_name,
    device_type: device.device_type,
    os_version: device.os_version,
    channel: device.channel,
    version_name: device.version_name,
    device_brand: device.device_brand,
    device_id: device.device_id,
    iid: device.iid,
    version_code: device.version_code,
    device_platform: device.device_platform,
    aid: device.aid,
  };
  const qUrl = `${NATIVE_BASE_URL}${qPath}?${new URLSearchParams(qQueryObj).toString()}`;
  const qBody = {
    tasks: [
      {
        bind_id: '',
        id: taskId,
        req_key: 'sami_text_to_speech',
        task_version: 'v3',
        token,
      },
    ],
  };
  const qBodyText = JSON.stringify(qBody);
  const qNow = Math.floor(Date.now() / 1000).toString();
  const qTraceId = `00-${crypto.randomBytes(16).toString('hex')}-${crypto.randomBytes(8).toString('hex')}-01`;
  const qXSsStub = crypto.createHash('md5').update(qBodyText, 'utf8').digest('hex');
  const qSignHeader = crypto
    .createHash('md5')
    .update(`9e2c|${qPath.slice(-7)}|3|${device.appvr}|${qNow}|${device.tdid}|11ac`, 'utf8')
    .digest('hex');

  const qHeaders = {
    'content-type': 'application/json',
    appvr: device.appvr,
    ch: device.channel,
    'device-time': qNow,
    lan: device.lan,
    loc: device.loc,
    pf: device.pf,
    'sign-ver': '1',
    tdid: device.tdid,
    'x-ss-stub': qXSsStub,
    'x-ss-dp': device.aid,
    'x-khronos': qNow,
    'x-tt-trace-id': qTraceId,
    'user-agent': 'Cronet/TTNetVersion:1d7cc3b1 2025-07-16 QuicVersion:52c2b40d 2025-04-03',
    'accept-encoding': 'gzip, deflate',
    'store-country-code': device.loc.toLowerCase(),
    'store-country-code-src': 'did',
    'is-dispatch-us-ttp': '0',
    'is-app-region-us-ttp': '0',
    'app-sdk-version': device.appvr,
    appid: device.aid,
    sign: qSignHeader,
  };

  for (let attempt = 0; attempt < 30; attempt++) {
    await new Promise((resolve) => setTimeout(resolve, 350));
    const pollRes = await fetchImpl(qUrl, {
      method: 'POST',
      headers: qHeaders,
      body: qBodyText,
    });
    const pollBuf = await pollRes.arrayBuffer();
    let pollRaw = Buffer.from(pollBuf);
    if (pollRaw.length >= 2 && pollRaw[0] === 0x1f && pollRaw[1] === 0x8b) {
      try { pollRaw = zlib.gunzipSync(pollRaw); } catch {}
    }
    const pollData = JSON.parse(pollRaw.toString('utf8'));
    const pTasks = pollData?.data?.tasks || [];
    if (!pTasks.length) continue;

    const status = pTasks[0].status;
    if (status === 'success' || status === 'succeed') {
      let payloadObj = pTasks[0].payload;
      if (typeof payloadObj === 'string') {
        payloadObj = JSON.parse(payloadObj);
      }
      const subtitles = payloadObj?.audio_subtitles || [];
      if (subtitles.length && subtitles[0].speech_url) {
        const audioUrl = subtitles[0].speech_url;
        const audioRes = await fetchImpl(audioUrl, {
          headers: { 'User-Agent': 'Mozilla/5.0' },
        });
        const audioBuf = await audioRes.arrayBuffer();
        return Buffer.from(audioBuf);
      }
      throw new Error('CapCut returned success but missing speech_url');
    } else if (status === 'failed') {
      throw new Error('CapCut synthesis task failed: ' + JSON.stringify(pollData));
    }
  }
  throw new Error('CapCut synthesis task timed out');
}

async function synthesizeWithNativeSignedEngine(cleanText, selectedSpeaker, rate = '1.0') {
  const [voiceType, resourceId] = resolveVoiceAndResourceId(selectedSpeaker);
  const chunks = splitTextIntoChunks(cleanText, 260);

  if (!chunks.length) {
    throw new Error('No valid text to synthesize.');
  }

  if (chunks.length === 1) {
    const audioBuffer = await synthesizeNativeChunk(chunks[0], voiceType, resourceId, rate);
    if (audioBuffer && audioBuffer.length > 512) {
      return {
        success: true,
        audioBuffer,
        format: 'mp3',
        provider: 'capcut-native-signed-engine',
        speaker: selectedSpeaker,
        voiceType,
      };
    }
  }

  // Multi-chunk sequential processing
  const audioBuffers = [];
  for (const chunk of chunks) {
    const buf = await synthesizeNativeChunk(chunk, voiceType, resourceId, rate);
    if (buf && buf.length > 512) {
      audioBuffers.push(buf);
    }
  }

  if (audioBuffers.length === 0) {
    throw new Error('CapCut Native Signed Engine did not produce audio buffers.');
  }

  const combinedBuffer = Buffer.concat(audioBuffers);
  return {
    success: true,
    audioBuffer: combinedBuffer,
    format: 'mp3',
    provider: 'capcut-native-signed-engine',
    speaker: selectedSpeaker,
    voiceType,
  };
}

async function synthesizeWithCapCutBridge(cleanText, selectedSpeaker) {
  const childProcess = require('child_process');
  const os = require('os');
  const bridgeScript = path.join(__dirname, 'capcut_bridge.py');
  
  if (!fs.existsSync(bridgeScript)) {
    return null;
  }

  const tmpHash = crypto.createHash('md5').update(`${selectedSpeaker}:${cleanText}:${Date.now()}`).digest('hex');
  const tmpOut = path.join(os.tmpdir(), `capcut_bridge_${tmpHash}.mp3`);

  return new Promise((resolve) => {
    const candidatePythons = [
      process.env.AI_VIDEO_STUDIO_PYTHON_EXE,
      process.env.LOCALAPPDATA && path.join(process.env.LOCALAPPDATA, 'AI Video Studio', 'runtime', 'vieneu-python', 'python', 'python.exe'),
      path.resolve(__dirname, '..', 'runtime-seed', 'windows-x64', 'portable-python', 'python', 'python.exe'),
      path.resolve(__dirname, '..', '..', 'backend', 'runtime-seed', 'windows-x64', 'portable-python', 'python', 'python.exe'),
    ].filter(Boolean);
    const resolvedBundledPython = candidatePythons.find((p) => {
      try { return fs.existsSync(p); } catch { return false; }
    });
    const pythonExe = resolvedBundledPython || (process.platform === 'win32' ? 'python' : 'python3');
    const proc = childProcess.spawn(pythonExe, [bridgeScript, cleanText, selectedSpeaker, tmpOut], {
      stdio: ['ignore', 'pipe', 'pipe'],
      timeout: 30000,
    });

    let stderr = '';
    proc.stderr?.on('data', (d) => (stderr += d.toString()));

    proc.on('close', (code) => {
      if (code === 0 && fs.existsSync(tmpOut)) {
        try {
          const audioBuffer = fs.readFileSync(tmpOut);
          try { fs.unlinkSync(tmpOut); } catch {}
          if (audioBuffer.length > 512) {
            return resolve({
              success: true,
              audioBuffer,
              format: 'mp3',
              provider: 'capcut-python-bridge',
              speaker: selectedSpeaker,
            });
          }
        } catch (e) {
          console.warn('[CAPCUT BRIDGE] Read error:', e.message);
        }
      }
      try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut); } catch {}
      console.warn('[CAPCUT BRIDGE] Bridge process ended with code', code, stderr.trim());
      resolve(null);
    });

    proc.on('error', (err) => {
      console.warn('[CAPCUT BRIDGE] Spawn error:', err.message);
      try { if (fs.existsSync(tmpOut)) fs.unlinkSync(tmpOut); } catch {}
      resolve(null);
    });
  });
}

async function synthesizeCapCutTTS({ text, speaker = 'vi_001', customEndpoint = '', sessionId = '', speed = 1.0 }) {
  const cleanText = String(text || '').trim();
  if (!cleanText) {
    throw new Error('Text is required for CapCut TTS synthesis.');
  }

  const selectedSpeaker = String(speaker || 'vi_001').trim();
  const cleanSessionId = String(sessionId || '').trim();
  const rateStr = Number.isFinite(Number(speed)) && Number(speed) > 0 ? Number(speed).toFixed(2) : '1.0';

  // 1. If custom endpoint is explicitly specified (e.g. local K07VN server, worker, or self-hosted API)
  if (customEndpoint && customEndpoint.trim()) {
    const rawEndpoint = customEndpoint.trim();
    const targetUrl = rawEndpoint.includes('/api/tts') || rawEndpoint.includes('/generate')
      ? rawEndpoint
      : `${rawEndpoint.replace(/\/+$/, '')}/api/tts`;

    try {
      const resp = await fetchImpl(targetUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(cleanSessionId ? { Cookie: `sessionid=${cleanSessionId}; sid_tt=${cleanSessionId}` } : {}),
        },
        body: JSON.stringify({
          text: cleanText,
          speaker: selectedSpeaker,
          voice: selectedSpeaker,
          session_id: cleanSessionId,
        }),
      });

      if (resp.ok) {
        const contentType = resp.headers.get('content-type') || '';
        if (contentType.includes('audio') || contentType.includes('octet-stream')) {
          const arrayBuf = await resp.arrayBuffer();
          return {
            success: true,
            audioBuffer: Buffer.from(arrayBuf),
            format: 'mp3',
            provider: 'capcut-custom-endpoint',
            speaker: selectedSpeaker,
          };
        }

        const payload = await resp.json().catch(() => ({}));
        const base64Data = payload?.audio || payload?.data?.v_data || payload?.audio_base64 || payload?.data;
        if (typeof base64Data === 'string' && base64Data.length > 100) {
          return {
            success: true,
            audioBuffer: Buffer.from(base64Data, 'base64'),
            format: 'mp3',
            provider: 'capcut-custom-endpoint',
            speaker: selectedSpeaker,
          };
        }
      }
    } catch (err) {
      console.warn('[CAPCUT TTS] Custom endpoint failed:', err.message);
    }
  }

  // 2. PRIMARY: CapCut Native Signed Engine (Pure Node.js RSA + Signed Request, high speed & reliable)
  try {
    const nativeResult = await synthesizeWithNativeSignedEngine(cleanText, selectedSpeaker, rateStr);
    if (nativeResult && nativeResult.audioBuffer && nativeResult.audioBuffer.length > 512) {
      return nativeResult;
    }
  } catch (err) {
    console.warn('[CAPCUT TTS] Native Signed Engine error:', err.message);
  }

  // 3. SECONDARY: CapCut Python Bridge fallback
  try {
    const bridgeResult = await synthesizeWithCapCutBridge(cleanText, selectedSpeaker);
    if (bridgeResult && bridgeResult.audioBuffer && bridgeResult.audioBuffer.length > 512) {
      return bridgeResult;
    }
  } catch (err) {
    console.warn('[CAPCUT TTS] Native bridge warning:', err.message);
  }

  // 3. Check local K07VN default servers (http://127.0.0.1:8000 or http://localhost:8080)
  const localCandidates = [
    'http://127.0.0.1:8000/api/tts',
    'http://127.0.0.1:8080/api/tts',
    'http://127.0.0.1:5000/api/tts',
  ];

  for (const localUrl of localCandidates) {
    try {
      const resp = await fetchImpl(localUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text: cleanText,
          speaker: selectedSpeaker,
          voice: selectedSpeaker,
        }),
      });

      if (resp.ok) {
        const payload = await resp.json().catch(() => ({}));
        const base64Data = payload?.audio || payload?.data?.v_data || payload?.audio_base64;
        if (typeof base64Data === 'string' && base64Data.length > 100) {
          return {
            success: true,
            audioBuffer: Buffer.from(base64Data, 'base64'),
            format: 'mp3',
            provider: 'k07vn-local-server',
            speaker: selectedSpeaker,
          };
        }
      }
    } catch {
      // Local server not running, continue
    }
  }

  // 4. Direct TikTok API endpoints with sessionId support
  const publicCandidates = [
    'https://api16-normal-c-useast1a.tiktokv.com/media/api/text/speech/invoke/',
    'https://api16-normal-useast5.us.tiktokv.com/media/api/text/speech/invoke/',
    'https://api16-core-c-alisg.tiktokv.com/media/api/text/speech/invoke/',
    'https://api22-normal-c-alisg.tiktokv.com/media/api/text/speech/invoke/',
    'https://api16-va.tiktokv.com/media/api/text/speech/invoke/',
  ];

  const headers = {
    'User-Agent': 'com.zhiliaoapp.musically/2022600030 (Linux; U; Android 7.1.2; en_US; Device)',
    'Accept-Encoding': 'gzip,deflate',
    ...(cleanSessionId
      ? {
          Cookie: `sessionid=${cleanSessionId}; sid_tt=${cleanSessionId}; sessionid_ss=${cleanSessionId}`,
        }
      : {}),
  };

  for (const endpoint of publicCandidates) {
    try {
      const params = new URLSearchParams({
        text_speaker: selectedSpeaker,
        req_text: cleanText,
        speaker_map_type: '0',
        aid: '1233',
      });

      const response = await fetchImpl(`${endpoint}?${params.toString()}`, {
        method: 'POST',
        headers,
      });

      if (response.ok) {
        const data = await response.json().catch(() => ({}));
        if (data && data.status_code === 0 && data.data && data.data.v_data) {
          const audioBuffer = Buffer.from(data.data.v_data, 'base64');
          if (audioBuffer.length > 512) {
            return {
              success: true,
              audioBuffer,
              format: 'mp3',
              provider: 'capcut-direct',
              speaker: selectedSpeaker,
            };
          }
        }
      }
    } catch (err) {
      // Continue to next mirror
    }
  }

  throw new Error(
    'CapCut Native Signed Engine không thể tạo audio lúc này. Hãy thử lại sau hoặc kiểm tra kết nối Internet.',
  );
}

const SPEAKER_ALIAS_MAP = {
  vi_001: 'bv001_streaming',
  vi_002: 'bv002_streaming',
  vi_003: 'bv523_streaming',
  vi_004: 'bv524_streaming',
};

/**
 * Resolve a capcut voice ID (e.g. 'capcut_vi_female_1') to the TikTok speaker code (e.g. 'bv001_streaming').
 */
function resolveCapcutSpeaker(voiceId = '') {
  const normalized = String(voiceId || '').trim().toLowerCase();
  const match = CAPCUT_VOICES.find(
    (v) => v.id.toLowerCase() === normalized || v.speaker.toLowerCase() === normalized,
  );
  const rawSpeaker = match ? match.speaker : normalized.replace(/^capcut_/, '');
  return SPEAKER_ALIAS_MAP[rawSpeaker] || rawSpeaker || 'bv001_streaming';
}

const CAPCUT_LANG_CODE_MAP = {
  vi: 'v',
  'en-us': 'a',
  'en-uk': 'b',
  ja: 'j',
  ko: 'ko',
  zh: 'c',
  es: 'e',
  fr: 'f',
  de: 'de',
  pt: 'p',
  id: 'd',
};

/**
 * Returns CapCut voices in the standard format expected by the frontend voice catalog system.
 * Each voice has { value, label, langCode, source, description, gender, speaker, pluginId, pluginName }.
 */
function getCapcutVoicesForCatalog() {
  return getCapCutVoices().map((voice) => {
    const cleanName = String(voice.name || '')
      .replace(/\s*\((?:CapCut|TikTok)\)/gi, '')
      .trim();
    return {
      value: voice.id,
      label: `[CapCut] ${cleanName}`,
      langCode: CAPCUT_LANG_CODE_MAP[voice.lang] || voice.lang || 'v',
      source: 'capcut-tts',
      description: voice.description,
      gender: voice.gender,
      speaker: voice.speaker,
      avatar: voice.avatar,
      pluginId: 'capcut-tts',
      pluginName: 'CapCut TTS',
    };
  });
}

module.exports = {
  CAPCUT_VOICES,
  getCapCutVoices,
  synthesizeCapCutTTS,
  resolveCapcutSpeaker,
  getCapcutVoicesForCatalog,
};
