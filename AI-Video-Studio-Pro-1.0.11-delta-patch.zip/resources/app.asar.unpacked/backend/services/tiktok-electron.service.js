const crypto = require('crypto');

const pendingRequests = new Map();
const DEFAULT_TIMEOUT_MS = 2 * 60 * 1000;
const LONG_OPERATION_TIMEOUT_MS = 12 * 60 * 1000;

function isElectronBrowserBridgeAvailable() {
  return process.env.IS_ELECTRON === 'true' && typeof process.send === 'function';
}

function normalizeBridgeError(error = {}) {
  const message = String(error?.message || error || 'TikTok browser request failed.');
  const normalized = new Error(message);
  if (error?.code) normalized.code = String(error.code);
  if (error?.needsUserAction) normalized.needsUserAction = true;
  return normalized;
}

function handleBridgeMessage(message) {
  if (!message || message.type !== 'tiktok-browser-response' || !message.id) return;
  const pending = pendingRequests.get(String(message.id));
  if (!pending) return;
  pendingRequests.delete(String(message.id));
  clearTimeout(pending.timeout);
  pending.abortSignal?.removeEventListener('abort', pending.onAbort);
  if (message.ok) pending.resolve(message.result);
  else pending.reject(normalizeBridgeError(message.error));
}

process.on('message', handleBridgeMessage);

function requestTikTokElectronBrowser(
  action,
  payload = {},
  { timeoutMs = DEFAULT_TIMEOUT_MS, abortSignal = null } = {},
) {
  if (!isElectronBrowserBridgeAvailable()) {
    return Promise.reject(
      new Error(
        'TikTok built-in browser is available only when the backend is running inside the desktop app.',
      ),
    );
  }
  if (abortSignal?.aborted) return Promise.reject(new Error('Job cancelled'));
  const id = crypto.randomUUID();
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      if (!pendingRequests.has(id)) return;
      pendingRequests.delete(id);
      clearTimeout(timeout);
      try {
        process.send?.({
          type: 'tiktok-browser-cancel',
          id: crypto.randomUUID(),
          targetId: id,
        });
      } catch {}
      reject(new Error('Job cancelled'));
    };
    const timeout = setTimeout(() => {
      pendingRequests.delete(id);
      abortSignal?.removeEventListener('abort', onAbort);
      try {
        process.send?.({
          type: 'tiktok-browser-cancel',
          id: crypto.randomUUID(),
          targetId: id,
        });
      } catch {}
      reject(new Error(`TikTok browser ${action} timed out.`));
    }, Math.max(1000, Number(timeoutMs) || DEFAULT_TIMEOUT_MS));
    pendingRequests.set(id, { resolve, reject, timeout, abortSignal, onAbort });
    abortSignal?.addEventListener('abort', onAbort, { once: true });
    try {
      process.send({ type: 'tiktok-browser-request', id, action, payload });
    } catch (error) {
      pendingRequests.delete(id);
      clearTimeout(timeout);
      abortSignal?.removeEventListener('abort', onAbort);
      reject(error);
    }
  });
}

async function getTikTokBrowserRuntimeStatus() {
  if (!isElectronBrowserBridgeAvailable()) {
    return {
      ready: false,
      managed: true,
      source: 'electron-unavailable',
      label: 'Built-in Electron Chromium',
      browserVersion: '',
      isolatedProfile: true,
      persistentPerAccount: true,
      backgroundUpload: true,
      systemFallback: false,
      incrementalBrowserBytes: 0,
      warning: 'Open this feature in the AI Video Studio Pro desktop app.',
    };
  }
  return requestTikTokElectronBrowser('runtime');
}

function getTikTokAccountsStatus() {
  return requestTikTokElectronBrowser('accounts');
}

async function getTikTokAccountStatus() {
  const status = await getTikTokAccountsStatus();
  return {
    connected: Boolean(status?.connected),
    account: status?.account || null,
    accounts: Array.isArray(status?.accounts) ? status.accounts : [],
  };
}

function selectTikTokBrowserAccount(identifier = '') {
  return requestTikTokElectronBrowser('select-account', { identifier });
}

function startTikTokLoginSession(payload = {}) {
  return requestTikTokElectronBrowser('login', payload, {
    timeoutMs: LONG_OPERATION_TIMEOUT_MS,
  });
}

function cancelTikTokLoginSession() {
  return requestTikTokElectronBrowser('cancel-login');
}

function saveTikTokSessionFromCookie(cookie, handle = '') {
  return requestTikTokElectronBrowser(
    'import-cookie',
    { cookie, handle },
    { timeoutMs: LONG_OPERATION_TIMEOUT_MS },
  );
}

function disconnectTikTokAccount(identifier = '') {
  return requestTikTokElectronBrowser('disconnect', { identifier });
}

function refreshTikTokAccountProfile(identifier = '', abortSignal = null) {
  return requestTikTokElectronBrowser(
    'refresh-profile',
    { identifier },
    { timeoutMs: LONG_OPERATION_TIMEOUT_MS, abortSignal },
  );
}

function validateTikTokBrowserSession({ abortSignal = null, accountId = '' } = {}) {
  return requestTikTokElectronBrowser(
    'validate',
    { accountId },
    { timeoutMs: LONG_OPERATION_TIMEOUT_MS, abortSignal },
  );
}

function publishTikTokVideoViaBrowser(payload = {}) {
  const { abortSignal = null, ...serializablePayload } = payload;
  return requestTikTokElectronBrowser('publish', serializablePayload, {
    timeoutMs: LONG_OPERATION_TIMEOUT_MS,
    abortSignal,
  });
}

function rejectAllPendingTikTokBrowserRequests(reason = 'Backend shutting down.') {
  for (const [id, pending] of pendingRequests) {
    pendingRequests.delete(id);
    clearTimeout(pending.timeout);
    pending.abortSignal?.removeEventListener('abort', pending.onAbort);
    pending.reject(new Error(reason));
  }
}

module.exports = {
  cancelTikTokLoginSession,
  disconnectTikTokAccount,
  getTikTokAccountStatus,
  getTikTokAccountsStatus,
  getTikTokBrowserRuntimeStatus,
  isElectronBrowserBridgeAvailable,
  publishTikTokVideoViaBrowser,
  refreshTikTokAccountProfile,
  rejectAllPendingTikTokBrowserRequests,
  requestTikTokElectronBrowser,
  saveTikTokSessionFromCookie,
  selectTikTokBrowserAccount,
  startTikTokLoginSession,
  validateTikTokBrowserSession,
};
