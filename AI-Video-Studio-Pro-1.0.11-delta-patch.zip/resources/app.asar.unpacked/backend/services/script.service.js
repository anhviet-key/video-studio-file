/**
 * Script Service
 * Handles AI script generation, topic parsing, and prompt structuring.
 */

function sanitizeTopic(topic = '') {
  return String(topic || '').trim();
}

function formatScriptPrompt({ topic, language = 'vi', style = 'default', targetWords = 200 }) {
  const cleanTopic = sanitizeTopic(topic);
  const langLabel = language === 'vi' ? 'Tiếng Việt' : 'English';
  
  return `Tạo kịch bản video bằng ${langLabel} với chủ đề "${cleanTopic}".
Phong cách: ${style}.
Độ dài khoảng ${targetWords} từ.
Kịch bản chia rõ từng cảnh (Scene 1, Scene 2...) kèm mô tả hình ảnh và lời đọc TTS.`;
}

function parseGeneratedScript(rawText = '') {
  if (!rawText) return [];
  const lines = rawText.split('\n');
  const scenes = [];
  let currentScene = null;

  for (const line of lines) {
    const trimmed = line.trim();
    if (/^Scene\s+\d+/i.test(trimmed) || /^Cảnh\s+\d+/i.test(trimmed)) {
      if (currentScene) scenes.push(currentScene);
      currentScene = { title: trimmed, text: '', visualPrompt: '' };
    } else if (currentScene) {
      if (/^(Mô tả|Visual|Image):/i.test(trimmed)) {
        currentScene.visualPrompt = trimmed.replace(/^(Mô tả|Visual|Image):/i, '').trim();
      } else {
        currentScene.text += (currentScene.text ? ' ' : '') + trimmed;
      }
    }
  }

  if (currentScene) scenes.push(currentScene);
  return scenes;
}

module.exports = {
  sanitizeTopic,
  formatScriptPrompt,
  parseGeneratedScript,
};
