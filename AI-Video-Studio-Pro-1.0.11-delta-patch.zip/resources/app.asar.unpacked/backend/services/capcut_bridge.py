import sys
import os
import json
import time
import urllib.request

script_dir = os.path.dirname(os.path.abspath(__file__))
repo_candidates = [
    os.path.join(script_dir, "capcut-tts-api"),
    os.path.abspath(os.path.join(script_dir, "..", "..", "tools", "capcut-tts-api")),
]
for repo_dir in repo_candidates:
    if os.path.isdir(os.path.join(repo_dir, "capcut_tts_api")):
        sys.path.insert(0, repo_dir)
        break

try:
    from capcut_tts_api.client import CapCutClient
except Exception as e:
    print(f"ERROR: Failed to import CapCutClient: {e}", file=sys.stderr)
    sys.exit(1)

SPEAKER_TO_VOICE = {
    # Vietnamese
    "vi_001": ("BV421_vivn_streaming", "7252594014782755330"),
    "bv001_streaming": ("BV421_vivn_streaming", "7252594014782755330"),
    "capcut_vi_female_1": ("BV421_vivn_streaming", "7252594014782755330"),
    "capcut_bv001": ("BV421_vivn_streaming", "7252594014782755330"),

    "vi_002": ("BV075_streaming", "7102355803792740865"),
    "bv002_streaming": ("BV075_streaming", "7102355803792740865"),
    "capcut_vi_male_1": ("BV075_streaming", "7102355803792740865"),
    "capcut_bv002": ("BV075_streaming", "7102355803792740865"),

    "vi_003": ("BV074_streaming_dsp", "7550087831092251920"),
    "bv523_streaming": ("multi_female_tianmeijieshuo_uranus_bigtts", "7637460417295469832"),
    "capcut_vi_kid_1": ("BV074_streaming_dsp", "7550087831092251920"),
    "capcut_bv523": ("multi_female_tianmeijieshuo_uranus_bigtts", "7637460417295469832"),

    "vi_004": ("BV074_streaming", "7102355709945188865"),
    "bv524_streaming": ("multi_male_felipe_uranus_bigtts", "7637456729696996628"),
    "capcut_bv524": ("multi_male_felipe_uranus_bigtts", "7637456729696996628"),

    "vi_005": ("BV560_streaming", "7483736167565758992"),
    "bv560_streaming": ("BV560_streaming", "7483736167565758992"),

    "vi_female_cuoi": ("multi_female_tianmeijieshuo_uranus_bigtts", "7637460417295469832"),
    "vi_male_khoai": ("multi_male_felipe_uranus_bigtts", "7637456729696996628"),
    "vi_female_vui": ("multi_female_yangguangnv_uranus_bigtts", "7637456432522218773"),
    "bv066_streaming": ("multi_female_yangguangnv_uranus_bigtts", "7637456432522218773"),
    "capcut_bv066": ("multi_female_yangguangnv_uranus_bigtts", "7637456432522218773"),

    "vi_male_tamsu": ("multi_female_xinwenjieshuo_uranus_bigtts", "7637455039719640327"),
    "bv063_streaming": ("multi_female_xinwenjieshuo_uranus_bigtts", "7637455039719640327"),
    "capcut_bv063": ("multi_female_xinwenjieshuo_uranus_bigtts", "7637455039719640327"),

    "vi_female_huong": ("vi_female_huong", "7264854897953083905"),
    "vi_mai": ("BV562_streaming", "7483736254694035984"),
    "BV562_streaming": ("BV562_streaming", "7483736254694035984"),
    "vi_review_phim": ("multi_female_richgirl_uranus_bigtts", "7637460351541447956"),
    "vi_sunny_idol": ("multi_female_kiwi_uranus_bigtts", "7637457995882089749"),
    # English
    "en_us_001": ("BV074_streaming", "7102355709945188865"),
    "en_us_002": ("BV075_streaming", "7102355803792740865"),
    "en_us_006": ("BV074_streaming", "7102355709945188865"),
    "en_us_007": ("BV075_streaming", "7102355803792740865"),
    "en_us_009": ("BV074_streaming", "7102355709945188865"),
    "en_us_010": ("BV075_streaming", "7102355803792740865"),
    # Japanese
    "ja_001": ("BV520_streaming", "7483735874258079760"),
    "ja_003": ("BV521_streaming", "7483735957796033552"),
    # Korean
    "ko_001": ("BV500_streaming", "7483735745400672272"),
    "ko_002": ("BV501_streaming", "7483735824555574288"),
}

def synthesize(text, speaker="vi_001", out_path=None):
    client = CapCutClient()
    mapping = SPEAKER_TO_VOICE.get(speaker)
    if mapping:
        voice_type, resource_id = mapping
    else:
        # Resolve catalog voice IDs to the current CapCut resource ID. This
        # keeps newly captured voices usable without credentials or hard-coded aliases.
        voice_type, resource_id = client.resolve_voice(voice=speaker)

    create_res = client.create_tts_task(texts=[text], voice=voice_type, resource_id=resource_id)
    tasks = (create_res.get("data") or {}).get("tasks") or []
    if not tasks:
        raise Exception(f"CapCut create task failed: {create_res}")
    
    task_id = tasks[0]["id"]
    token = tasks[0]["token"]
    
    for _ in range(40):
        time.sleep(0.4)
        query_res = client.query_tts_task(task_id, token)
        q_tasks = (query_res.get("data") or {}).get("tasks") or []
        if not q_tasks:
            continue
        status = q_tasks[0].get("status")
        if status in ("success", "succeed"):
            payload_str = q_tasks[0].get("payload")
            payload = json.loads(payload_str) if isinstance(payload_str, str) else payload_str
            subtitles = payload.get("audio_subtitles") or []
            if subtitles:
                audio_url = subtitles[0].get("speech_url")
                req = urllib.request.Request(audio_url, headers={"User-Agent": "Mozilla/5.0"})
                with urllib.request.urlopen(req, timeout=30) as resp:
                    audio_bytes = resp.read()
                if out_path:
                    os.makedirs(os.path.dirname(os.path.abspath(out_path)), exist_ok=True)
                    with open(out_path, "wb") as f:
                        f.write(audio_bytes)
                return len(audio_bytes)
            raise Exception("No audio url in CapCut response")
        elif status == "failed":
            raise Exception(f"CapCut synthesis failed: {query_res}")
    raise Exception("CapCut task timed out")

if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Usage: capcut_bridge.py <text> <speaker> <out_path>", file=sys.stderr)
        sys.exit(1)
    text = sys.argv[1]
    speaker = sys.argv[2]
    out_path = sys.argv[3]
    try:
        size = synthesize(text, speaker, out_path)
        print(f"SUCCESS: {size}")
    except Exception as e:
        print(f"ERROR: {e}", file=sys.stderr)
        sys.exit(1)
