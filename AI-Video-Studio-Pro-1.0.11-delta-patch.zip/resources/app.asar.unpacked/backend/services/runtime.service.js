/**
 * Runtime Service
 * Encapsulates local runtime checks (Kokoro ONNX, VieNeu TTS, Whisper, Qwen GGUF)
 * and manifest discovery.
 */
const fs = require('fs');
const path = require('path');

function checkLocalFileExists(filePath) {
  try {
    return fs.existsSync(filePath);
  } catch (e) {
    return false;
  }
}

function getRuntimeSummary(modelsDir) {
  const qwenPath = path.join(modelsDir, 'Qwen2.5-1.5B-Instruct-Q4_K_M.gguf');
  const kokoroPath = path.join(modelsDir, 'kokoro-82m-v1.0-onnx', 'onnx', 'model_q4f16.onnx');
  const vieneuPath = path.join(
    modelsDir,
    'VieNeu-TTS-v3-Turbo',
    'onnx_int8',
    'vieneu_prefill.onnx',
  );

  return {
    qwenPresent: checkLocalFileExists(qwenPath),
    kokoroPresent: checkLocalFileExists(kokoroPath),
    vieneuPresent: checkLocalFileExists(vieneuPath),
    ready: checkLocalFileExists(kokoroPath) || checkLocalFileExists(vieneuPath),
  };
}

module.exports = {
  checkLocalFileExists,
  getRuntimeSummary,
};
