const crypto = require('crypto');

const pendingRequests = new Map();
const DEFAULT_TIMEOUT_MS = 2 * 60 * 1000;
const LONG_OPERATION_TIMEOUT_MS = 15 * 60 * 1000; // 15 phút cho upload video

function isElectronBrowserBridgeAvailable() {
  return process.env.IS_ELECTRON === 'true' && typeof process.send === 'function';
}

function normalizeBridgeError(error = {}) {
  const message = String(error?.message || error || 'YouTube browser request failed.');
  const normalized = new Error(message);
  if (error?.code) normalized.code = String(error.code);
  if (error?.needsUserAction) normalized.needsUserAction = true;
  return normalized;
}

function handleBridgeMessage(message) {
  if (!message || message.type !== 'youtube-browser-response' || !message.id) return;
  const pending = pendingRequests.get(String(message.id));
  if (!pending) return;
  pendingRequests.delete(String(message.id));
  clearTimeout(pending.timeout);
  pending.abortSignal?.removeEventListener('abort', pending.onAbort);
  if (message.ok) pending.resolve(message.result);
  else pending.reject(normalizeBridgeError(message.error));
}

process.on('message', handleBridgeMessage);

function requestYouTubeElectronBrowser(
  action,
  payload = {},
  { timeoutMs = DEFAULT_TIMEOUT_MS, abortSignal = null } = {},
) {
  if (!isElectronBrowserBridgeAvailable()) {
    return Promise.reject(
      new Error(
        'YouTube Studio built-in browser is available only when running inside the desktop app.',
      ),
    );
  }
  if (abortSignal?.aborted) return Promise.reject(new Error('Job cancelled'));
  const id = crypto.randomUUID();
  return new Promise((resolve, reject) => {
    const onAbort = () => {
      if (!pendingRequests.has(id)) return;
      pendingRequests.delete(id);
      clearTimeout(timeout);
      try {
        process.send?.({
          type: 'youtube-browser-cancel',
          id: crypto.randomUUID(),
          targetId: id,
        });
      } catch {}
      reject(new Error('Job cancelled'));
    };
    const timeout = setTimeout(() => {
      pendingRequests.delete(id);
      abortSignal?.removeEventListener('abort', onAbort);
      try {
        process.send?.({
          type: 'youtube-browser-cancel',
          id: crypto.randomUUID(),
          targetId: id,
        });
      } catch {}
      reject(new Error(`YouTube browser ${action} timed out.`));
    }, Math.max(1000, Number(timeoutMs) || DEFAULT_TIMEOUT_MS));
    pendingRequests.set(id, { resolve, reject, timeout, abortSignal, onAbort });
    abortSignal?.addEventListener('abort', onAbort, { once: true });
    try {
      process.send({ type: 'youtube-browser-request', id, action, payload });
    } catch (error) {
      pendingRequests.delete(id);
      clearTimeout(timeout);
      abortSignal?.removeEventListener('abort', onAbort);
      reject(error);
    }
  });
}

async function getYouTubeBrowserRuntimeStatus() {
  if (!isElectronBrowserBridgeAvailable()) {
    return {
      ready: false,
      managed: true,
      source: 'electron-unavailable',
      label: 'YouTube Studio Built-in Browser',
      browserVersion: '',
      isolatedProfile: true,
      persistentPerAccount: true,
      backgroundUpload: true,
      systemFallback: false,
      warning: 'Open this feature in the AI Video Studio Pro desktop app.',
    };
  }
  return requestYouTubeElectronBrowser('runtime');
}

function getYouTubeAccountsStatus() {
  return requestYouTubeElectronBrowser('accounts');
}

async function getYouTubeAccountStatus() {
  const status = await getYouTubeAccountsStatus();
  return {
    connected: Boolean(status?.connected),
    account: status?.account || null,
    accounts: Array.isArray(status?.accounts) ? status.accounts : [],
  };
}

function selectYouTubeBrowserAccount(identifier = '') {
  return requestYouTubeElectronBrowser('select-account', { identifier });
}

function startYouTubeLoginSession(payload = {}) {
  return requestYouTubeElectronBrowser('login', payload, {
    timeoutMs: LONG_OPERATION_TIMEOUT_MS,
  });
}

function cancelYouTubeLoginSession() {
  return requestYouTubeElectronBrowser('cancel-login');
}

function saveYouTubeSessionFromCookie(cookie, handle = '') {
  return requestYouTubeElectronBrowser(
    'import-cookie',
    { cookie, handle },
    { timeoutMs: LONG_OPERATION_TIMEOUT_MS },
  );
}

function disconnectYouTubeAccount(identifier = '') {
  return requestYouTubeElectronBrowser('disconnect', { identifier });
}

function refreshYouTubeAccountProfile(identifier = '', abortSignal = null) {
  return requestYouTubeElectronBrowser(
    'refresh-profile',
    { identifier },
    { timeoutMs: LONG_OPERATION_TIMEOUT_MS, abortSignal },
  );
}

function validateYouTubeBrowserSession({ abortSignal = null, accountId = '' } = {}) {
  return requestYouTubeElectronBrowser(
    'validate',
    { accountId },
    { timeoutMs: LONG_OPERATION_TIMEOUT_MS, abortSignal },
  );
}

function publishYouTubeVideoViaBrowser(payload = {}) {
  const { abortSignal = null, ...serializablePayload } = payload;
  return requestYouTubeElectronBrowser('publish', serializablePayload, {
    timeoutMs: LONG_OPERATION_TIMEOUT_MS,
    abortSignal,
  });
}

function rejectAllPendingYouTubeBrowserRequests(reason = 'Backend shutting down.') {
  for (const [id, pending] of pendingRequests) {
    pendingRequests.delete(id);
    clearTimeout(pending.timeout);
    pending.abortSignal?.removeEventListener('abort', pending.onAbort);
    pending.reject(new Error(reason));
  }
}

module.exports = {
  cancelYouTubeLoginSession,
  disconnectYouTubeAccount,
  getYouTubeAccountStatus,
  getYouTubeAccountsStatus,
  getYouTubeBrowserRuntimeStatus,
  isElectronBrowserBridgeAvailable,
  publishYouTubeVideoViaBrowser,
  refreshYouTubeAccountProfile,
  rejectAllPendingYouTubeBrowserRequests,
  requestYouTubeElectronBrowser,
  saveYouTubeSessionFromCookie,
  selectYouTubeBrowserAccount,
  startYouTubeLoginSession,
  validateYouTubeBrowserSession,
};
