const TIKTOK_INIT_URL =
  'https://open.tiktokapis.com/v2/post/publish/video/init/';
const TIKTOK_STATUS_URL =
  'https://open.tiktokapis.com/v2/post/publish/status/fetch/';

function delay(ms, signal) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) return reject(new Error('Job cancelled'));
    const onAbort = () => {
      clearTimeout(timer);
      reject(new Error('Job cancelled'));
    };
    const timer = setTimeout(() => {
      signal?.removeEventListener('abort', onAbort);
      resolve();
    }, ms);
    signal?.addEventListener('abort', onAbort, { once: true });
  });
}

async function readTikTokResponse(response, operation) {
  const text = await response.text();
  let payload = {};
  try {
    payload = text ? JSON.parse(text) : {};
  } catch {
    payload = {};
  }
  const apiError = payload?.error;
  if (
    !response.ok ||
    (apiError?.code && String(apiError.code).toLowerCase() !== 'ok')
  ) {
    const detail =
      apiError?.message || apiError?.code || text || `${response.status}`;
    throw new Error(`TikTok ${operation} failed: ${detail}`);
  }
  return payload;
}

function createTikTokUploader({
  fs,
  fetchImpl = fetch,
  getTikTokAccountConfig = () => ({}),
  refreshTikTokAccessToken = null,
  publishViaBrowser = null,
  normalizeTikTokPrivacy = (val) => {
    const s = String(val || '').toLowerCase();
    if (s === 'friends' || s === 'mutual_follow_friends') return 'MUTUAL_FOLLOW_FRIENDS';
    if (s === 'private' || s === 'self_only') return 'SELF_ONLY';
    if (!s || s === 'public' || s === 'public_to_everyone') return 'PUBLIC_TO_EVERYONE';
    throw new Error('Unsupported TikTok privacy setting. Upload stopped.');
  },
  statusPollIntervalMs = 3000,
  statusPollAttempts = 20,
}) {
  return async function uploadToTikTok(
    videoPath,
    thumbPath,
    metadata = {},
    appUserId = 'default',
    currentJob = {},
    abortSignal = null,
  ) {
    const config = currentJob?.config || {};
    let accountInfo = await Promise.resolve(getTikTokAccountConfig(appUserId)) || {};
    const publishTarget = currentJob.publishTargets?.find(
      (target) => target.platform === 'tiktok',
    ) || {};
    const expectedHandle = publishTarget.accountHandle;
    const connectedHandle = String(accountInfo.handle || '').trim();
    if (
      expectedHandle &&
      connectedHandle &&
      expectedHandle.replace(/^@/, '').toLowerCase() !==
        connectedHandle.replace(/^@/, '').toLowerCase()
    ) {
      throw new Error('The connected TikTok account changed after this job was created. Upload stopped.');
    }

    if (!fs.existsSync(videoPath)) {
      throw new Error(`Video file missing at path: ${videoPath}`);
    }

    const browserUploadRequested =
      accountInfo?.uploadMode === 'electron-browser' ||
      config.tiktokUploadMode === 'electron-browser';
    if (browserUploadRequested && typeof publishViaBrowser === 'function') {
      const browserPrivacyLevel = normalizeTikTokPrivacy(
        config.tiktokPrivacy || metadata.tiktokPrivacy,
      );
      const browserPrivacy =
        browserPrivacyLevel === 'SELF_ONLY'
          ? 'private'
          : browserPrivacyLevel === 'MUTUAL_FOLLOW_FRIENDS'
            ? 'friends'
            : 'public';
      const hashtags = String(config.tiktokHashtags || '').trim();
      const titleText = String(metadata.title || 'AI Video Short').slice(0, 150);
      const descriptionText = String(metadata.description || '').trim().slice(0, 1800);
      const aiGenerated = config.tiktokAiTag ?? true;
      const caption = [titleText, descriptionText].filter(Boolean).join('\n').slice(0, 2000);
      currentJob.step = `Preparing TikTok background browser upload (${browserPrivacy})...`;
      currentJob.log =
        (currentJob.log || '') +
        `[TIKTOK] Starting built-in Chromium upload (${browserPrivacy}) for ${accountInfo.handle || 'active account'}.\n`;
      const result = await publishViaBrowser({
        accountId:
          config.tiktokBrowserAccountId ||
          publishTarget.browserAccountId ||
          accountInfo.browserAccountId ||
          '',
        videoPath,
        caption,
        hashtags,
        privacy: browserPrivacy,
        allowComments: config.tiktokAllowComments ?? true,
        allowDuet: config.tiktokAllowDuet ?? true,
        allowStitch: config.tiktokAllowStitch ?? true,
        aiTag: aiGenerated,
        abortSignal,
      });
      const publishId = String(result?.publishId || '').trim();
      if (!result?.success || !publishId) {
        throw new Error('TikTok browser upload did not return a publication confirmation.');
      }
      const rawPublishUrl = String(result.publishUrl || '').trim();
      let publishUrl = '';
      try {
        const url = new URL(rawPublishUrl);
        if (url.protocol === 'https:' && ['www.tiktok.com', 'tiktok.com'].includes(url.hostname) &&
            /\/(?:@[^/]+\/)?video\/\d+\/?$/.test(url.pathname)) publishUrl = url.href;
      } catch { /* Studio URLs and local submission IDs are not public posts. */ }
      const hasRealPostEvidence =
        /^\d{8,}$/.test(publishId) || /\/video\/\d+(?:[/?#]|$)/i.test(publishUrl);
      const status = result.status === 'published' && hasRealPostEvidence
        ? 'published'
        : 'submitted';
      const evidenceWarning = result.status === 'published' && !hasRealPostEvidence
        ? 'TikTok reported a successful browser action without a real post ID or video URL. The result remains submitted until it can be confirmed.'
        : '';
      const warning = [result.warning, evidenceWarning].filter(Boolean).join('\n');
      currentJob.tiktokPublishId = publishId;
      currentJob.tiktokPublishUrl = publishUrl;
      currentJob.tiktokPublishStatus = status.toUpperCase();
      if (status === 'submitted' || result.pendingConfirmation) {
        currentJob.uploadPendingConfirmation = true;
      }
      if (warning) {
        currentJob.warningMsg = [currentJob.warningMsg, warning]
          .filter(Boolean)
          .join('\n');
      }
      currentJob.log += status === 'submitted' || result.pendingConfirmation
        ? `[TIKTOK] Post was submitted (${publishId}); final confirmation is pending.\n`
        : `[TIKTOK] TikTok Studio confirmed publication (${publishId}).\n`;
      return {
        confirmationId: publishId,
        status,
        pendingConfirmation: status === 'submitted' || Boolean(result.pendingConfirmation),
        publishUrl,
        warning,
      };
    }

    // Auto-refresh token if expired or expiring within 5 minutes (300,000 ms)
    const expiresAt = Number(accountInfo?.expiresAt) || 0;
    const isExpiringSoon = expiresAt > 0 && expiresAt - Date.now() < 300000;
    if (isExpiringSoon && accountInfo?.refreshToken && typeof refreshTikTokAccessToken === 'function') {
      try {
        currentJob.log = (currentJob.log || '') + '[TIKTOK] Access token expiring soon, refreshing...\n';
        accountInfo = await refreshTikTokAccessToken();
      } catch (refreshErr) {
        currentJob.log = (currentJob.log || '') + `[TIKTOK] Auto-refresh warning: ${refreshErr.message}\n`;
      }
    }

    let accessToken =
      String(accountInfo?.accessToken || process.env.TIKTOK_ACCESS_TOKEN || '')
        .trim();
    if (!accessToken) {
      throw new Error(
        'TikTok account is not connected. Connect your TikTok account in the Social Upload tab.',
      );
    }
    const privacyLevel = normalizeTikTokPrivacy(
      config.tiktokPrivacy || metadata.tiktokPrivacy,
    );
    const allowedPrivacy = Array.isArray(accountInfo.privacyLevelOptions)
      ? accountInfo.privacyLevelOptions
      : [];
    if (allowedPrivacy.length > 0 && !allowedPrivacy.includes(privacyLevel)) {
      throw new Error(
        `TikTok account does not allow privacy option ${privacyLevel}. Refresh the account connection and choose an available option.`,
      );
    }

    const videoSize = fs.statSync(videoPath).size;
    const hashtags = String(config.tiktokHashtags || '').trim();
    const titleText = String(metadata.title || 'AI Video Short').slice(0, 150);
    const captionText = String(metadata.description || '').trim().slice(0, 1800);
    const aiGenerated = config.tiktokAiTag ?? true;
    const aiDisclaimer = aiGenerated
      ? 'AI-assisted content | #AIgenerated #VideoStudioPro'
      : '';
    const fullCaption = [titleText, captionText, hashtags, aiDisclaimer]
      .filter(Boolean)
      .join('\n')
      .slice(0, 2200)
      .trim();
    currentJob.step = `Preparing TikTok upload (${privacyLevel})...`;
    currentJob.log =
      (currentJob.log || '') +
      `[TIKTOK] Starting direct post (${privacyLevel}).\n`;

    const initResponse = await fetchImpl(TIKTOK_INIT_URL, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Content-Type': 'application/json; charset=UTF-8',
      },
      signal: abortSignal,
      body: JSON.stringify({
        post_info: {
          title: fullCaption,
          privacy_level: privacyLevel,
          disable_comment: !(config.tiktokAllowComments ?? true),
          disable_duet: !(config.tiktokAllowDuet ?? true),
          disable_stitch: !(config.tiktokAllowStitch ?? true),
          is_aigc: aiGenerated,
        },
        source_info: {
          source: 'FILE_UPLOAD',
          video_size: videoSize,
          chunk_size: videoSize,
          total_chunk_count: 1,
        },
      }),
    });
    const initData = await readTikTokResponse(initResponse, 'upload init');
    const uploadUrl = String(initData?.data?.upload_url || '').trim();
    const publishId = String(initData?.data?.publish_id || '').trim();
    if (!uploadUrl || !publishId) {
      throw new Error(
        'TikTok upload init did not return an upload URL and publish ID.',
      );
    }

    currentJob.step = 'Uploading video bytes to TikTok...';
    const uploadResponse = await fetchImpl(uploadUrl, {
      method: 'PUT',
      headers: {
        'Content-Type': 'video/mp4',
        'Content-Length': String(videoSize),
        'Content-Range': `bytes 0-${videoSize - 1}/${videoSize}`,
      },
      body: fs.createReadStream(videoPath),
      duplex: 'half',
      signal: abortSignal,
    });
    if (!uploadResponse.ok) {
      const detail = await uploadResponse.text();
      throw new Error(
        `TikTok video transfer failed (${uploadResponse.status}): ${detail}`,
      );
    }

    currentJob.tiktokPublishId = publishId;
    currentJob.tiktokPublishStatus = 'PROCESSING';
    currentJob.step = 'Waiting for TikTok publication confirmation...';
    for (let attempt = 0; attempt < statusPollAttempts; attempt += 1) {
      if (attempt > 0) await delay(statusPollIntervalMs, abortSignal);
      const statusResponse = await fetchImpl(TIKTOK_STATUS_URL, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json; charset=UTF-8',
        },
        signal: abortSignal,
        body: JSON.stringify({ publish_id: publishId }),
      });
      const statusData = await readTikTokResponse(
        statusResponse,
        'status check',
      );
      const status = String(statusData?.data?.status || '').trim();
      const rawPublicPostIds =
        statusData?.data?.publicaly_available_post_id ||
        statusData?.data?.publicly_available_post_id;
      const publicPostIds = Array.isArray(rawPublicPostIds)
        ? rawPublicPostIds.map(String).filter(Boolean)
        : [];
      if (status) currentJob.tiktokPublishStatus = status;
      if (publicPostIds.length > 0) {
        currentJob.tiktokPostId = publicPostIds[0];
      }
      if (status === 'PUBLISH_COMPLETE') {
        const postId = publicPostIds[0] || '';
        if (!postId) {
          const warning =
            'TikTok finished processing the submission but has not returned a public post ID yet. The result remains submitted until a real post ID or URL is available.';
          currentJob.uploadPendingConfirmation = true;
          currentJob.warningMsg = [currentJob.warningMsg, warning]
            .filter(Boolean)
            .join('\n');
          currentJob.log +=
            `[TIKTOK] Processing completed for publish ID ${publishId}, but no public post ID was returned.\n`;
          return {
            confirmationId: publishId,
            status: 'submitted',
            pendingConfirmation: true,
            publishUrl: '',
            warning,
          };
        }
        currentJob.log +=
          `[TIKTOK] Publication confirmed. Post ID: ${postId}.\n`;
        return {
          confirmationId: postId,
          status: 'published',
          pendingConfirmation: false,
          publishUrl: `https://www.tiktok.com/video/${postId}`,
          warning: '',
        };
      }
      if (status === 'FAILED') {
        const reason = statusData?.data?.fail_reason || 'Unknown TikTok error';
        throw new Error(`TikTok publication failed: ${reason}`);
      }
    }

    currentJob.uploadPendingConfirmation = true;
    currentJob.warningMsg = [
      currentJob.warningMsg,
      'TikTok accepted the video and is still processing it. Check TikTok Studio before retrying to avoid a duplicate post.',
    ].filter(Boolean).join('\n');
    currentJob.log +=
      `[TIKTOK] Upload accepted with publish ID ${publishId}; publication is still processing.\n`;
    return {
      confirmationId: publishId,
      status: 'submitted',
      pendingConfirmation: true,
      publishUrl: '',
      warning:
        'TikTok accepted the video and is still processing it. Check TikTok Studio before retrying to avoid a duplicate post.',
    };
  };
}

module.exports = {
  createTikTokUploader,
};
