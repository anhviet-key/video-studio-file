const path = require('path');
let sharp = null;
try { sharp = require('sharp'); } catch { /* optional in unit-test harness */ }

const YOUTUBE_THUMBNAIL_MAX_BYTES = 50 * 1024 * 1024;

function appendWarning(currentJob, message) {
  const warning = String(message || '').trim();
  if (!warning) return;
  const existing = String(currentJob.warningMsg || '').trim();
  const warnings = existing ? existing.split(/\n+/).map((item) => item.trim()) : [];
  if (!warnings.includes(warning)) warnings.push(warning);
  currentJob.warningMsg = warnings.filter(Boolean).join('\n');
}

async function validateYouTubeThumbnail(
  thumbPath,
  { maxBytes = YOUTUBE_THUMBNAIL_MAX_BYTES, isShorts = false } = {},
) {
  if (!thumbPath) return { ok: false, skipped: true };
  const extension = path.extname(thumbPath).toLowerCase();
  if (!['.jpg', '.jpeg', '.png'].includes(extension)) {
    throw new Error('YouTube thumbnail must be JPG or PNG. Choose a supported image.');
  }
  const stat = require('fs').statSync(thumbPath);
  if (stat.size > maxBytes) {
    throw new Error(`YouTube thumbnail is ${(stat.size / 1024 / 1024).toFixed(2)} MB; the YouTube API limit is ${maxBytes / 1024 / 1024} MB. Choose a smaller image.`);
  }
  if (sharp) {
    const metadata = await sharp(thumbPath).metadata();
    if (!['jpeg', 'png'].includes(metadata.format)) throw new Error('YouTube thumbnail must contain a valid JPG or PNG image.');
    if (!metadata.width || !metadata.height || (isShorts ? metadata.height : metadata.width) < 640) {
      throw new Error(
        isShorts
          ? 'YouTube Shorts thumbnail must be at least 640 pixels high; 9:16 is recommended.'
          : 'YouTube video thumbnail must be at least 640 pixels wide; 16:9 is recommended.',
      );
    }
    const targetRatio = isShorts ? 9 / 16 : 16 / 9;
    const actualRatio = metadata.width / metadata.height;
    const ratioWarning = Math.abs(actualRatio - targetRatio) / targetRatio > 0.08
      ? (isShorts
          ? 'YouTube Shorts thumbnails are best prepared at a 9:16 ratio.'
          : 'YouTube video thumbnails are best prepared at a 16:9 ratio.')
      : '';
    return {
      ok: true,
      bytes: stat.size,
      maxBytes,
      isShorts,
      width: metadata.width,
      height: metadata.height,
      warnings: ratioWarning ? [ratioWarning] : [],
    };
  }
  return { ok: true, bytes: stat.size, maxBytes, isShorts, warnings: [] };
}

function createYouTubeUploader({
  fs,
  // `getGoogle` is a lazy accessor: requiring googleapis costs a large module
  // graph, and the upload path is the only thing that needs it. `google` stays
  // supported so existing callers and tests can pass the client directly.
  getGoogle = null,
  google = null,
  getYouTubeUserRecordForUpload,
  getRemoteYouTubeAccessToken,
  canUploadWithChannel,
  getYouTubeAuthClient,
  normalizeYouTubePrivacyStatus,
  publishViaBrowser = null,
}) {
  const resolveGoogle = () => {
    if (typeof getGoogle === 'function') return getGoogle();
    if (google) return google;
    throw new Error('YouTube uploader requires a googleapis client or getGoogle accessor.');
  };

  return async function uploadToYouTube(
    videoPath,
    thumbPath,
    metadata,
    appUserId,
    channelId,
    currentJob,
    abortSignal,
  ) {
    const uploadMode = currentJob?.config?.youtubeUploadMode || currentJob?.config?.uploadMode;
    const isBrowserMode =
      uploadMode === 'electron-browser' ||
      (Boolean(publishViaBrowser) &&
        (!channelId ||
          channelId === 'browser' ||
          String(channelId).startsWith('persist:youtube-') ||
          String(channelId).startsWith('yt_browser_') ||
          /^[a-f0-9]{20}$/i.test(String(channelId || '')) ||
          String(channelId).startsWith('UC') ||
          String(channelId).startsWith('@')));

    if (isBrowserMode && publishViaBrowser) {
      const isShorts = String(currentJob?.config?.aspectRatio || '').trim() === '9:16';
      let thumbnailWarning = '';
      const thumbnailAdvisories = [];
      if (thumbPath && fs.existsSync(thumbPath)) {
        try {
          const validation = await validateYouTubeThumbnail(thumbPath, { isShorts });
          thumbnailAdvisories.push(...(validation.warnings || []));
        } catch (error) {
          thumbnailWarning = `Video uploaded without a custom thumbnail: ${error.message}`;
        }
      } else if (thumbPath) {
        thumbnailWarning = 'Video uploaded without a custom thumbnail because the thumbnail file was missing.';
      }
      for (const advisory of thumbnailAdvisories) {
        appendWarning(currentJob, advisory);
        currentJob.log = (currentJob.log || '') + `[YOUTUBE] Thumbnail advisory: ${advisory}\n`;
      }

      currentJob.step = 'Uploading video via YouTube Studio Browser...';
      const defaultTags = String(currentJob?.config?.youtubeTags || 'shorts')
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);
      const tags =
        Array.isArray(metadata?.tags) && metadata.tags.length > 0
          ? metadata.tags
          : defaultTags;
      const privacyStatus = normalizeYouTubePrivacyStatus
        ? normalizeYouTubePrivacyStatus(metadata?.privacyStatus || currentJob?.config?.youtubePrivacyStatus)
        : (metadata?.privacyStatus || currentJob?.config?.youtubePrivacyStatus || 'public');

      const browserResult = await publishViaBrowser({
        videoPath,
        thumbPath: thumbnailWarning ? '' : thumbPath,
        metadata: {
          title: (metadata?.title || currentJob?.config?.youtubeTitle || 'AI Video').substring(0, 100),
          description: metadata?.description || currentJob?.config?.youtubeDescription || '#shorts',
          tags,
          privacyStatus,
          madeForKids: Boolean(currentJob?.config?.youtubeMadeForKids),
          embeddable: currentJob?.config?.youtubeEmbeddable !== false,
          notifySubscribers:
            currentJob?.config?.youtubeNotifySubscribers !== false,
          containsSyntheticMedia: Boolean(currentJob?.config?.youtubeAiTag),
          isShorts,
        },
        accountId: channelId && channelId !== 'browser' ? channelId : '',
        abortSignal,
      });

      const videoId = browserResult.confirmationId;
      currentJob.youtubeVideoId = videoId;
      currentJob.youtubeVideoUrl = browserResult.publishUrl || '';
      const browserStatus = browserResult.status === 'published' ? 'published' : 'submitted';
      currentJob.log =
        (currentJob.log || '') +
        (browserStatus === 'published'
          ? `[YOUTUBE_BROWSER] Video published and confirmed: ${currentJob.youtubeVideoUrl} (${privacyStatus}).\n`
          : `[YOUTUBE_BROWSER] Upload submitted; YouTube has not returned a confirmed video ID yet (${privacyStatus}).\n`);

      if (thumbnailWarning) {
        currentJob.thumbnailUploadFailed = true;
        appendWarning(currentJob, thumbnailWarning);
      }

      return {
        confirmationId: videoId,
        status: browserStatus,
        pendingConfirmation: Boolean(browserResult.pendingConfirmation),
        publishUrl: currentJob.youtubeVideoUrl,
        warning: [thumbnailWarning, ...thumbnailAdvisories, browserResult.warning].filter(Boolean).join('\n'),
      };
    }

    const userRecord = await getYouTubeUserRecordForUpload(appUserId);
    const channel = userRecord.channels.find((item) => item.id === channelId);
    if (!channel || !canUploadWithChannel(channel)) {
      throw new Error('This channel has not been authorized yet.');
    }

    let oAuth2Client = null;
    if (channel.remoteManaged) {
      const tokenPayload = await getRemoteYouTubeAccessToken(
        appUserId,
        channelId,
      );
      if (!tokenPayload?.accessToken) {
        throw new Error(
          'The license server did not return a YouTube access token.',
        );
      }
      oAuth2Client = new (resolveGoogle().auth.OAuth2)();
      oAuth2Client.setCredentials({
        access_token: tokenPayload.accessToken,
        expiry_date: tokenPayload.expiryDate || undefined,
      });
    } else {
      oAuth2Client = getYouTubeAuthClient();
      if (!oAuth2Client) {
        throw new Error('Local YouTube OAuth client is not configured.');
      }
      oAuth2Client.setCredentials(channel.tokens);
    }

    const youtube = resolveGoogle().youtube({ version: 'v3', auth: oAuth2Client });
    const privacyStatus = normalizeYouTubePrivacyStatus(
      metadata?.privacyStatus || currentJob?.config?.youtubePrivacyStatus,
    );
    const requestOptions = abortSignal ? { signal: abortSignal } : undefined;

    const categoryId = String(
      currentJob?.config?.youtubeCategory || metadata.categoryId || '22',
    );
    const defaultTags = String(currentJob?.config?.youtubeTags || 'shorts')
      .split(',')
      .map((t) => t.trim())
      .filter(Boolean);
    const tags =
      Array.isArray(metadata.tags) && metadata.tags.length > 0
        ? metadata.tags
        : defaultTags;
    const madeForKids = Boolean(currentJob?.config?.youtubeMadeForKids);
    const notifySubscribers =
      currentJob?.config?.youtubeNotifySubscribers !== false;
    const containsSyntheticMedia = Boolean(currentJob?.config?.youtubeAiTag);

    const isShorts = String(currentJob?.config?.aspectRatio || '').trim() === '9:16';
    let thumbnailWarning = '';
    const thumbnailAdvisories = [];
    if (thumbPath && fs.existsSync(thumbPath)) {
      try {
        const validation = await validateYouTubeThumbnail(thumbPath, { isShorts });
        thumbnailAdvisories.push(...(validation.warnings || []));
      } catch (error) {
        thumbnailWarning = `Video uploaded without a custom thumbnail: ${error.message}`;
      }
    } else if (thumbPath) {
      thumbnailWarning = 'Video uploaded without a custom thumbnail because the thumbnail file was missing.';
    }
    for (const advisory of thumbnailAdvisories) {
      appendWarning(currentJob, advisory);
      currentJob.log = (currentJob.log || '') + `[YOUTUBE] Thumbnail advisory: ${advisory}\n`;
    }

    currentJob.step = `Uploading video to YouTube (${privacyStatus})...`;
    const response = await youtube.videos.insert(
      {
        part: 'snippet,status',
        notifySubscribers,
        requestBody: {
          snippet: {
            title: (metadata.title || 'AI Video').substring(0, 100),
            description: metadata.description || '#shorts',
            tags,
            categoryId,
          },
          status: {
            privacyStatus,
            madeForKids,
            selfDeclaredMadeForKids: madeForKids,
            embeddable: currentJob?.config?.youtubeEmbeddable ?? true,
            containsSyntheticMedia,
          },
        },
        media: { body: fs.createReadStream(videoPath) },
      },
      requestOptions,
    );

    const videoId = response.data.id;
    if (!videoId) {
      throw new Error(
        'YouTube did not confirm the uploaded video. No video ID was returned.',
      );
    }
    currentJob.youtubeVideoId = videoId;
    currentJob.youtubeVideoUrl = `https://www.youtube.com/watch?v=${videoId}`;
    currentJob.log =
      (currentJob.log || '') +
      `[YOUTUBE] Upload confirmed with video ID ${videoId} (${privacyStatus}).\n`;
    currentJob.step = 'Uploading thumbnail...';

    if (thumbPath && fs.existsSync(thumbPath) && !thumbnailWarning) {
      try {
        await youtube.thumbnails.set(
          {
            videoId,
            media: { body: fs.createReadStream(thumbPath) },
          },
          requestOptions,
        );
      } catch (error) {
        currentJob.thumbnailUploadFailed = true;
        thumbnailWarning = `Video uploaded, but the custom thumbnail was rejected: ${error.message}`;
        appendWarning(currentJob, thumbnailWarning);
        currentJob.log =
          (currentJob.log || '') +
          `[YOUTUBE] Thumbnail upload failed: ${error.message}\n`;
      }
    } else if (thumbnailWarning) {
      currentJob.thumbnailUploadFailed = true;
      appendWarning(currentJob, thumbnailWarning);
      currentJob.log =
        (currentJob.log || '') +
        `[YOUTUBE] ${thumbnailWarning}\n`;
    }

    return {
      confirmationId: videoId,
      status: 'published',
      pendingConfirmation: false,
      publishUrl: currentJob.youtubeVideoUrl,
      warning: [thumbnailWarning, ...thumbnailAdvisories].filter(Boolean).join('\n'),
    };
  };
}

module.exports = {
  createYouTubeUploader,
  validateYouTubeThumbnail,
  YOUTUBE_THUMBNAIL_MAX_BYTES,
};
